import { useCallback, useEffect, useRef, useState } from 'react';
import type { Trace } from '../../solver/trace';
import type { TraceEventType } from '../../solver/types';

export const SPEEDS = [1, 2, 4, 8, 16, 32, 64, 250, 1000, 5000] as const;

/**
 * Playback over a recorded trace. `index` is the event being shown;
 * -1 means "before the first event" (the starting puzzle).
 */
export function usePlayback(trace: Trace | null, resetKey: string) {
  const length = trace?.length ?? 0;
  const [index, setIndex] = useState(-1);
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState<number>(8);
  const [pauseOn, setPauseOn] = useState<ReadonlySet<TraceEventType>>(new Set());
  const indexRef = useRef(index);
  indexRef.current = index;

  useEffect(() => {
    setIndex(-1);
    setPlaying(false);
  }, [resetKey]);

  useEffect(() => {
    if (!playing || !trace) return;
    let frame = 0;
    let last = performance.now();
    let carry = 0;
    const tick = (now: number) => {
      carry += ((now - last) / 1000) * speed;
      last = now;
      const steps = Math.floor(carry);
      if (steps > 0) {
        carry -= steps;
        const from = indexRef.current;
        let to = Math.min(length - 1, from + steps);
        let stop = to >= length - 1;
        if (pauseOn.size) {
          for (let i = from + 1; i <= to; i++) {
            if (pauseOn.has(trace.events[i].type)) {
              to = i;
              stop = true;
              break;
            }
          }
        }
        indexRef.current = to;
        setIndex(to);
        if (stop) {
          setPlaying(false);
          return;
        }
      }
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [playing, speed, trace, length, pauseOn]);

  const seek = useCallback((i: number) => setIndex(Math.max(-1, Math.min(length - 1, i))), [length]);
  const step = useCallback(
    (delta: number) => {
      setPlaying(false);
      setIndex((i) => Math.max(-1, Math.min(length - 1, i + delta)));
    },
    [length],
  );
  const toggle = useCallback(() => {
    if (index >= length - 1) {
      setIndex(-1);
      setPlaying(true);
    } else setPlaying((p) => !p);
  }, [index, length]);
  const jumpTo = useCallback(
    (type: TraceEventType | 'BACKTRACK', direction: 1 | -1) => {
      if (!trace) return;
      setPlaying(false);
      const match = (e: { type: TraceEventType }) => e.type === type;
      const found = direction === 1 ? trace.findNext(index, match) : trace.findPrevious(index, match);
      if (found >= 0) setIndex(found);
    },
    [index, trace],
  );

  return { index, setIndex: seek, playing, setPlaying, toggle, step, speed, setSpeed, jumpTo, pauseOn, setPauseOn, length };
}

export type Playback = ReturnType<typeof usePlayback>;
