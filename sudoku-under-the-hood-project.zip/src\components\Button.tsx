import type { ButtonHTMLAttributes, ReactNode } from 'react';
import { Icon, type IconName } from './Icon';
import styles from './Button.module.css';

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  icon?: IconName;
  /** Visually pressed state for toggles. */
  active?: boolean;
  /** Render only the icon; `label` becomes the accessible name. */
  iconOnly?: boolean;
  label?: string;
  children?: ReactNode;
}

export function Button({ variant = 'secondary', size = 'md', icon, active, iconOnly, label, children, className, ...rest }: Props) {
  const classes = [
    styles.button,
    variant === 'primary' && styles.primary,
    variant === 'ghost' && styles.ghost,
    active && styles.active,
    size === 'sm' && styles.sm,
    size === 'lg' && styles.lg,
    iconOnly && styles.iconOnly,
    className,
  ]
    .filter(Boolean)
    .join(' ');
  return (
    <button
      type="button"
      className={classes}
      aria-label={iconOnly ? label : undefined}
      title={iconOnly ? label : rest.title}
      aria-pressed={active === undefined ? undefined : active}
      {...rest}
    >
      {icon && <Icon name={icon} size={size === 'lg' ? 22 : size === 'sm' ? 15 : 18} />}
      {!iconOnly && children}
    </button>
  );
}
