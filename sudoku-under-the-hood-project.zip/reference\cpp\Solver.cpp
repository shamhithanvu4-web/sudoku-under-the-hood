#include "Solver.hpp"

#include <algorithm>

namespace sudoku {
namespace {

bool solvePlain(SudokuBoard& board, Stats& s, int depth) {
    s.recursiveCalls++;
    s.maxDepth = std::max(s.maxDepth, depth);

    std::optional<Cell> cell = board.findEmptyCell();
    if (!cell) return board.isSolved();  // base case

    for (int digit = 1; digit <= SIZE; ++digit) {
        s.candidateAttempts++;
        s.peerScans++;
        if (board.findConflict(cell->row, cell->col, digit)) {  // rule broken
            s.rejected++;
            continue;
        }
        board.placeCandidate(cell->row, cell->col, digit);
        s.placements++;

        if (solvePlain(board, s, depth + 1)) return true;  // recursive step

        board.undoPlacement(cell->row, cell->col);  // backtrack
        s.backtracks++;
    }
    s.deadEnds++;
    return false;
}

struct Choice {
    Cell cell;
    std::vector<int> candidates;
    int examined;
};

std::optional<Choice> selectMRVCell(const SudokuBoard& board) {
    std::optional<Choice> best;
    int examined = 0;
    for (int row = 0; row < SIZE; ++row) {
        for (int col = 0; col < SIZE; ++col) {
            if (board.getCell(row, col) != EMPTY) continue;
            std::vector<int> candidates = board.getCandidates(row, col);
            examined++;
            if (!best || candidates.size() < best->candidates.size()) {
                best = Choice{{row, col}, candidates, examined};
                if (candidates.empty()) return best;
            }
        }
    }
    if (best) best->examined = examined;
    return best;
}

bool solveWithMRV(SudokuBoard& board, Stats& s, int depth) {
    s.recursiveCalls++;
    s.maxDepth = std::max(s.maxDepth, depth);

    std::optional<Choice> choice = selectMRVCell(board);
    if (!choice) return board.isSolved();  // base case
    s.peerScans += choice->examined;

    if (choice->candidates.empty()) {  // fail early
        s.deadEnds++;
        return false;
    }
    const Cell cell = choice->cell;
    for (int digit : choice->candidates) {
        s.candidateAttempts++;
        board.placeCandidate(cell.row, cell.col, digit);
        s.placements++;
        if (solveWithMRV(board, s, depth + 1)) return true;
        board.undoPlacement(cell.row, cell.col);
        s.backtracks++;
    }
    s.deadEnds++;
    return false;
}

}  // namespace

bool solveBacktracking(SudokuBoard& board, Stats& stats) { return solvePlain(board, stats, 0); }
bool solveMRV(SudokuBoard& board, Stats& stats) { return solveWithMRV(board, stats, 0); }

}  // namespace sudoku
