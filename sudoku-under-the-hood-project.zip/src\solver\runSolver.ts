/**
 * runSolver — validates a puzzle, runs one of the solvers on a private copy
 * of the board, and reports what happened.
 *
 * The caller's puzzle is never modified. Every number in the result comes
 * from this run: counters from the Recorder, time from performance.now().
 */
import { BoardError, SudokuBoard, type Grid, type PuzzleReport } from '../domain/SudokuBoard';
import { solveBacktracking } from './backtrackingSolver';
import { solveMRV } from './mrvSolver';
import { Recorder, SearchLimitError } from './recorder';
import { Trace } from './trace';
import type { SolverKind, SolverStats } from './types';

export type RunStatus = 'solved' | 'no-solution' | 'invalid-puzzle' | 'malformed' | 'limit-reached';

export interface RunOptions {
  /** Record a replayable trace (true) or only count work (false, for timing). */
  record: boolean;
  maxEvents?: number;
  maxCalls?: number;
}

export interface RunResult {
  readonly kind: SolverKind;
  readonly status: RunStatus;
  readonly message: string;
  readonly stats: SolverStats;
  /** Wall-clock time of the search itself, in milliseconds. */
  readonly durationMs: number;
  readonly solution: Grid | null;
  readonly trace: Trace | null;
  readonly report: PuzzleReport | null;
  /** Set when the puzzle was already complete before the search started. */
  readonly alreadySolved: boolean;
  readonly limit?: 'events' | 'calls';
}

export const SOLVERS: Record<SolverKind, (board: SudokuBoard, rec: Recorder) => boolean> = {
  backtracking: solveBacktracking,
  mrv: solveMRV,
};

export const SOLVER_LABEL: Record<SolverKind, string> = {
  backtracking: 'Plain backtracking',
  mrv: 'Backtracking + MRV',
};

export const DEFAULT_MAX_EVENTS = 400_000;
export const DEFAULT_MAX_CALLS = 3_000_000;

const now = (): number => (typeof performance !== 'undefined' ? performance.now() : Date.now());

export function runSolver(puzzle: Grid, kind: SolverKind, options: RunOptions): RunResult {
  const base = { kind, trace: null, solution: null, report: null, alreadySolved: false, durationMs: 0 };
  let board: SudokuBoard;
  try {
    board = new SudokuBoard(puzzle);
  } catch (error) {
    const message = error instanceof BoardError ? error.message : 'The puzzle could not be read.';
    return { ...base, status: 'malformed', message, stats: new Recorder({ record: false }).stats };
  }

  const report = board.validatePuzzle();
  if (!report.ok) {
    const first = report.conflicts[0];
    return {
      ...base,
      report,
      status: 'invalid-puzzle',
      message: `The starting clues break a rule: ${first.value} appears twice in the same ${first.kind}. No search can fix that, so the solver does not start.`,
      stats: new Recorder({ record: false }).stats,
    };
  }

  const alreadySolved = board.isSolved();
  const rec = new Recorder({
    record: options.record,
    maxEvents: options.maxEvents ?? DEFAULT_MAX_EVENTS,
    maxCalls: options.maxCalls ?? DEFAULT_MAX_CALLS,
  });

  const start = now();
  let solved = false;
  let limit: 'events' | 'calls' | undefined;
  try {
    solved = SOLVERS[kind](board, rec);
  } catch (error) {
    if (!(error instanceof SearchLimitError)) throw error;
    limit = error.limit;
  }
  const durationMs = now() - start;
  const trace = options.record ? new Trace(puzzle, rec.events) : null;

  if (limit) {
    return {
      ...base,
      report,
      trace,
      durationMs,
      stats: rec.stats,
      status: 'limit-reached',
      limit,
      message:
        limit === 'events'
          ? `Recording stopped after ${rec.events.length.toLocaleString('en-US')} events before the search finished. You can replay what was recorded, or switch to the MRV solver, which explores far fewer branches.`
          : `The search was stopped after ${rec.stats.recursiveCalls.toLocaleString('en-US')} calls to keep the page responsive.`,
    };
  }

  if (solved) {
    // Defensive check: the solver must hand back a fully valid board.
    if (!board.isSolved()) throw new Error('Solver reported success on an unsolved board.');
    return {
      ...base,
      report,
      trace,
      durationMs,
      stats: rec.stats,
      status: 'solved',
      solution: board.getSnapshot(),
      alreadySolved,
      message: alreadySolved
        ? 'The puzzle was already complete and correct; the solver only had to confirm it.'
        : 'Solved. Every row, column and box now holds 1–9 exactly once.',
    };
  }

  return {
    ...base,
    report,
    trace,
    durationMs,
    stats: rec.stats,
    status: 'no-solution',
    message:
      'No solution exists. The clues break no rule on their own, but the solver tried every possibility and each one led to a contradiction.',
  };
}
