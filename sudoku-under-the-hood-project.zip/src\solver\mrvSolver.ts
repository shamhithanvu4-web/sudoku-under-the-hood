/**
 * Backtracking with the Minimum Remaining Values (MRV) heuristic.
 *
 * Same recursion as the plain solver, with three changes:
 *   1. Choose the empty cell with the FEWEST legal candidates, not the first one.
 *   2. If some cell has no candidates, this branch is already impossible:
 *      fail immediately instead of filling other cells first.
 *   3. Try only that cell's candidates. They were computed from the current
 *      board, so none of them can break a rule when placed.
 *
 * Choosing a cell now costs a scan of every empty cell, but the search tree
 * is usually much smaller. The worst case is still exponential.
 */
import { EMPTY, SIZE, type Coord, type SudokuBoard } from '../domain/SudokuBoard';
import type { Frame, Recorder } from './recorder';

export interface MRVChoice {
  readonly cell: Coord;
  readonly candidates: number[];
  /** How many empty cells were scored before choosing. */
  readonly examined: number;
}

/** Solves `board` in place. Returns true with the board solved, or false with the board restored. */
export function solveMRV(board: SudokuBoard, rec: Recorder): boolean {
  const solved = solve(board, rec, null); // @step no-solution
  if (!solved) rec.emit('no-solution', null, 'NO_SOLUTION');
  return solved;
}

/**
 * Scores every empty cell with getCandidates() and returns the one with the
 * fewest candidates (ties go to the earliest cell in row-major order).
 * Stops as soon as it finds a cell with zero candidates. Null when the board is full.
 */
export function selectMRVCell(board: SudokuBoard): MRVChoice | null {
  let best: Coord | null = null;
  let bestCandidates: number[] = [];
  let examined = 0;
  for (let row = 0; row < SIZE; row++) {
    for (let col = 0; col < SIZE; col++) {
      if (board.getCell(row, col) !== EMPTY) continue;
      const candidates = board.getCandidates(row, col);
      examined++;
      if (best === null || candidates.length < bestCandidates.length) {
        best = { row, col };
        bestCandidates = candidates;
        if (candidates.length === 0) return { cell: best, candidates, examined };
      }
    }
  }
  return best === null ? null : { cell: best, candidates: bestCandidates, examined };
}

function solve(board: SudokuBoard, rec: Recorder, parent: Frame | null): boolean { // @step enter
  const frame = rec.enter('enter', parent);

  const choice = selectMRVCell(board); // @step select scores
  if (choice === null) {
    const solved = board.isSolved(); // @step base-case base-return
    if (solved) rec.emit('base-case', frame, 'SOLUTION_FOUND');
    return rec.exit('base-return', frame, solved);
  }
  const { cell, candidates } = choice;
  rec.emit('select', frame, 'CELL_SELECTED', { cell, op: 'getCandidates' });
  rec.emit('scores', frame, 'CANDIDATES_COMPUTED', { cell, candidates, examined: choice.examined });

  if (candidates.length === 0) { // @step fail-early fail-early-return
    rec.emit('fail-early', frame, 'DEAD_END', { cell });
    return rec.exit('fail-early-return', frame, false);
  }

  for (const digit of candidates) { // @step try
    rec.emit('try', frame, 'CANDIDATE_TRIED', { cell, digit });

    board.placeCandidate(cell.row, cell.col, digit); // @step place
    rec.emit('place', frame, 'VALUE_PLACED', { cell, digit, before: 0, after: digit });

    if (solve(board, rec, frame)) { // @step success
      return rec.exit('success', frame, true);
    }

    board.undoPlacement(cell.row, cell.col); // @step undo
    rec.emit('undo', frame, 'BACKTRACK', { cell, digit, before: digit, after: 0 });
  }

  rec.emit('exhausted', frame, 'DEAD_END', { cell });
  return rec.exit('fail', frame, false);
}
