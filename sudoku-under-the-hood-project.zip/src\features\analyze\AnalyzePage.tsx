import { useEffect, useState } from 'react';
import { useApp } from '../../app/AppState';
import { BUNDLED, countClues, DIFFICULTY_LABEL } from '../../app/puzzles';
import { Button } from '../../components/Button';
import { MessageBar } from '../../components/MessageBar';
import { PageHeader, pageStyles } from '../../components/PageHeader';
import { Panel } from '../../components/Panel';
import { Tooltip } from '../../components/Tooltip';
import { SOLVER_LABEL } from '../../solver/runSolver';
import type { SolverKind, SolverStats } from '../../solver/types';
import { PuzzlePicker } from '../board/PuzzlePicker';
import { STAT_ROWS } from '../guided/StatsPanel';
import { measure, nextFrame, type Measurement } from './measure';
import styles from './Analyze.module.css';

const fmt = (n: number) => n.toLocaleString('en-US');
const ms = (n: number) => (n < 10 ? n.toFixed(2) : n < 100 ? n.toFixed(1) : n.toFixed(0));
const KINDS: SolverKind[] = ['backtracking', 'mrv'];

interface Comparison {
  puzzleId: string;
  name: string;
  empty: number;
  repeats: number;
  runs: Record<SolverKind, Measurement>;
  at: string;
}

interface BatchRow {
  id: string;
  name: string;
  difficulty: string;
  clues: number;
  plain: Measurement;
  mrv: Measurement;
}

export function AnalyzePage() {
  const { puzzle } = useApp();
  const [repeats, setRepeats] = useState(5);
  const [busy, setBusy] = useState(false);
  const [comparison, setComparison] = useState<Comparison | null>(null);
  const [batch, setBatch] = useState<BatchRow[]>([]);
  const [batchProgress, setBatchProgress] = useState<string>('');

  const run = async () => {
    setBusy(true);
    await nextFrame();
    const runs = {} as Record<SolverKind, Measurement>;
    for (const kind of KINDS) {
      runs[kind] = measure(puzzle.grid, kind, repeats);
      await nextFrame();
    }
    setComparison({
      puzzleId: puzzle.id,
      name: puzzle.name,
      empty: puzzle.grid.flat().filter((v) => v === 0).length,
      repeats,
      runs,
      at: new Date().toLocaleTimeString(),
    });
    setBusy(false);
  };

  // Measure the selected puzzle automatically the first time it is shown.
  useEffect(() => {
    if (comparison?.puzzleId !== puzzle.id && !busy) void run();
  }, [puzzle.id]);

  const runBatch = async () => {
    setBusy(true);
    const rows: BatchRow[] = [];
    const list = BUNDLED.filter((p) => p.group !== 'lab');
    for (let i = 0; i < list.length; i++) {
      const p = list[i];
      setBatchProgress(`Measuring ${p.name} (${i + 1} of ${list.length})…`);
      await nextFrame();
      rows.push({ id: p.id, name: p.name, difficulty: p.difficulty, clues: countClues(p.grid), plain: measure(p.grid, 'backtracking', 3), mrv: measure(p.grid, 'mrv', 3) });
      setBatch([...rows]);
    }
    setBatchProgress(`Measured ${list.length} puzzles, 1 warm-up and 3 timed runs per solver, at ${new Date().toLocaleTimeString()}.`);
    setBusy(false);
  };

  const current = comparison && comparison.puzzleId === puzzle.id ? comparison : null;

  return (
    <div className={pageStyles.wrap}>
      <PageHeader label="Analyze mode" title="Measure the work, then compare it with the theory">
        Both solvers run on the same puzzle in your browser, with tracing switched off. Every number below comes from those runs.
        The complexity table at the bottom is theory and is labelled as such.
      </PageHeader>

      <div className={styles.controls}>
        <PuzzlePicker id="analyze-puzzle" />
        <label className={styles.field} htmlFor="repeats">
          <span className="label">Timing runs</span>
          <select id="repeats" className={styles.select} value={repeats} onChange={(e) => setRepeats(Number(e.target.value))}>
            {[1, 3, 5, 9].map((n) => (
              <option key={n} value={n}>
                {n} per solver
              </option>
            ))}
          </select>
        </label>
        <Button variant="primary" icon="gauge" onClick={run} disabled={busy}>
          {busy ? 'Measuring…' : 'Run both solvers'}
        </Button>
      </div>

      {current ? <Results c={current} /> : <MessageBar message={{ tone: 'info', text: 'Measuring…' }} />}

      <Panel label="Across every bundled puzzle" meta={batchProgress || '1 warm-up + 3 timed runs per solver'} flush>
        <div style={{ padding: '0.85rem', display: 'flex', gap: '0.75rem', flexWrap: 'wrap', alignItems: 'center' }}>
          <Button size="sm" icon="layers" onClick={runBatch} disabled={busy}>
            {batch.length ? 'Measure again' : 'Measure all puzzles'}
          </Button>
          <span style={{ fontSize: 'var(--t-sm)', color: 'var(--gray)' }}>
            Compare the human difficulty label with how much searching each solver needed.
          </span>
        </div>
        {batch.length > 0 && (
          <div className={styles.tableWrap}>
            <table className={styles.table}>
              <thead>
                <tr>
                  <th>Puzzle</th>
                  <th>Difficulty</th>
                  <th>Clues</th>
                  <th>Plain calls</th>
                  <th>MRV calls</th>
                  <th>Plain ms (median)</th>
                  <th>MRV ms (median)</th>
                </tr>
              </thead>
              <tbody>
                {batch.map((r) => (
                  <tr key={r.id}>
                    <td>{r.name}</td>
                    <td>{DIFFICULTY_LABEL[r.difficulty] ?? r.difficulty}</td>
                    <td className={styles.num}>{r.clues}</td>
                    <td className={styles.num}>{fmt(r.plain.result.stats.recursiveCalls)}</td>
                    <td className={styles.num}>{fmt(r.mrv.result.stats.recursiveCalls)}</td>
                    <td className={styles.num}>{ms(r.plain.median)}</td>
                    <td className={styles.num}>{ms(r.mrv.median)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>

      {!current && <Theory />}
    </div>
  );
}

function Results({ c }: { c: Comparison }) {
  const plain = c.runs.backtracking;
  const mrv = c.runs.mrv;
  const invalid = plain.result.status === 'invalid-puzzle' || plain.result.status === 'malformed';
  if (invalid) return <MessageBar message={{ tone: 'error', text: plain.result.message }} />;
  /** Plain ÷ MRV. When MRV did none of the work, a ratio means nothing: show n/a and say why. */
  const ratio = (a: number, b: number, why: string) => {
    if (b === 0 && a === 0) return '–';
    if (b === 0) return <Tooltip tip={why}>n/a</Tooltip>;
    return `${(a / b).toFixed(a / b >= 10 ? 0 : 1)}×`;
  };
  const whyZero = (key: keyof SolverStats) =>
    key === 'rejected'
      ? 'MRV only tries digits that getCandidates() has already allowed, so it never rejects one. With 0 on the MRV side, a ratio is not meaningful.'
      : 'MRV did none of this work on this puzzle (0), so a ratio is not meaningful.';
  const charted: (keyof SolverStats)[] = ['recursiveCalls', 'candidateAttempts', 'backtracks', 'peerScans'];

  return (
    <>
      <div className={styles.headline}>
        {KINDS.map((k) => {
          const m = c.runs[k];
          return (
            <div key={k} className={styles.headCell}>
              <span className="label">{SOLVER_LABEL[k]}</span>
              <strong>{fmt(m.result.stats.recursiveCalls)} calls</strong>
              <span>
                <span className={styles.pill} data-status={m.result.status}>
                  {m.result.status.replace('-', ' ')}
                </span>{' '}
                median {ms(m.median)} ms over {m.times.length} timed {m.times.length === 1 ? 'run' : 'runs'} (range {ms(m.min)}–{ms(m.max)} ms), after {m.warmUpRuns} warm-up run that is not counted
              </span>
            </div>
          );
        })}
      </div>

      <div className={styles.grid}>
        <Panel label="Measured work" meta={`${c.name} · ${c.empty} empty cells · ${c.at}`} flush>
          <div className={styles.tableWrap}>
            <table className={styles.table}>
              <thead>
                <tr>
                  <th>Counter</th>
                  <th>Plain</th>
                  <th>MRV</th>
                  <th>Plain ÷ MRV</th>
                </tr>
              </thead>
              <tbody>
                {STAT_ROWS.map((row) => (
                  <tr key={row.key}>
                    <td>{row.label}</td>
                    <td className={styles.num}>{fmt(plain.result.stats[row.key])}</td>
                    <td className={styles.num}>{fmt(mrv.result.stats[row.key])}</td>
                    <td className={`${styles.num} ${styles.ratio}`}>{ratio(plain.result.stats[row.key], mrv.result.stats[row.key], whyZero(row.key))}</td>
                  </tr>
                ))}
                <tr>
                  <td>Time, median (ms)</td>
                  <td className={styles.num}>{ms(plain.median)}</td>
                  <td className={styles.num}>{ms(mrv.median)}</td>
                  <td className={`${styles.num} ${styles.ratio}`}>{ratio(plain.median, mrv.median, "MRV finished within the browser's timer resolution (0 ms), so a ratio is not meaningful.")}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </Panel>

        <Panel label="Work compared" meta="log scale">
          <div className={styles.chart}>
            {charted.map((key) => {
              const row = STAT_ROWS.find((r) => r.key === key)!;
              const values = { backtracking: plain.result.stats[key], mrv: mrv.result.stats[key] };
              const top = Math.log10(Math.max(10, values.backtracking, values.mrv) + 1);
              return (
                <div key={key} className={styles.metric}>
                  <div className={styles.metricLabel}>
                    <span>{row.label}</span>
                  </div>
                  {KINDS.map((k) => {
                    const w = (Math.log10(values[k] + 1) / top) * 100;
                    return (
                      <div key={k} className={styles.barRow}>
                        <span>{k === 'mrv' ? 'MRV' : 'plain'}</span>
                        <div className={styles.track} style={{ ['--w' as string]: `${w}%` }}>
                          <div className={styles.fill} data-kind={k} style={{ width: `${w}%` }} />
                          <span className={styles.value} data-inside={w > 70}>
                            {fmt(values[k])}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              );
            })}
            <span className={styles.axisNote}>Bar length ∝ log₁₀(count + 1); each bar is scaled to the larger of the two.</span>
          </div>
        </Panel>
      </div>

      <div className={styles.pair}>
      <Panel label="Reading these numbers">
        <div className={styles.prose}>
          <ul>
            <li>
              Both solvers update the same counters through the same recorder, so the categories match. A{' '}
              <strong>row/col/box scan</strong> is one pass over a cell's row, column and box: one findConflict() call in the plain
              solver, one getCandidates() call per empty cell examined by MRV.
            </li>
            <li>
              MRV only tries digits that getCandidates() already allowed, so its <strong>rejected</strong> count is normally 0. The
              filtering work is counted in its scans instead.
            </li>
            <li>
              Both solvers also re-check legality inside placeCandidate() as a safety precondition. That costs the same per placement
              in both and is not counted.
            </li>
            <li>
              Each solver runs once untimed first, so the browser has compiled the code before timing starts; that warm-up run is
              not counted. Times are wall-clock milliseconds from performance.now() around the search only, on this device, in this browser tab.
              They vary between runs and machines; browsers also round timer values. Treat small differences as noise.
            </li>
            <li>
              Fewer calls does not guarantee less time: MRV spends extra work choosing each cell. Whether that pays off depends on the
              puzzle. The measurements above show which way it went this time.
            </li>
          </ul>
        </div>
      </Panel>
      <Theory />
      </div>
    </>
  );
}

function Theory() {
  return (
    <Panel label="Theory (not measured)">
      <div className={styles.prose}>
        <p>
          Let <em>m</em> be the number of empty cells at the start. These are bounds on growth, not predictions for one puzzle.
        </p>
        <div className={styles.tableWrap}>
          <table className={styles.theory}>
            <thead>
              <tr>
                <th>Quantity</th>
                <th>Plain backtracking</th>
                <th>Backtracking + MRV</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th>Worst-case time</th>
                <td>
                  Exponential; <code>O(9ᵐ)</code> is a loose upper bound on the assignments it can explore.
                </td>
                <td>
                  Still exponential, <code>O(9ᵐ)</code>. A heuristic changes the order of the search, not the worst case.
                </td>
              </tr>
              <tr>
                <th>Work per call</th>
                <td>
                  <code>findEmptyCell</code> up to 81 reads, plus up to 9 rule checks of 27 reads each.
                </td>
                <td>
                  One <code>getCandidates</code> per empty cell (up to <em>m</em> × 27 reads) to choose a cell.
                </td>
              </tr>
              <tr>
                <th>Extra space</th>
                <td>
                  <code>O(m)</code>: at most <em>m</em> + 1 stack frames and the placement trail.
                </td>
                <td>
                  <code>O(m)</code> for the stack and trail, plus the candidate list of each open frame (at most 9 digits each).
                </td>
              </tr>
              <tr>
                <th>Recorded trace</th>
                <td colSpan={2}>
                  Under the Hood stores every event (proportional to the work done) plus a copy of the 81 cells every 256 events. That
                  memory is for teaching, not part of the algorithm, and is why recording is capped.
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <p>
          Sudoku generalised to n²×n² boards is NP-complete, so no known algorithm avoids exponential worst cases. On a fixed 9×9
          board the practical cost depends on the puzzle and on the order in which cells and digits are tried.
        </p>
      </div>
    </Panel>
  );
}
