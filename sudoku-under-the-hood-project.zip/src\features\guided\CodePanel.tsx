import { useEffect, useMemo, useRef, useState } from 'react';
import { CopyButton } from '../../components/CopyButton';
import { Panel } from '../../components/Panel';
import { extractMember } from '../../explain/sourceIndex';
import { SOURCES } from '../../explain/sources';
import type { Token } from '../../explain/highlight';
import type { SolverKind, TraceEvent } from '../../solver/types';
import styles from './Guided.module.css';

type Tab = 'solver' | 'board';

/** The real source of the running solver and board ADT, with the lines behind the current step highlighted. */
export function CodePanel({ kind, event, collapsible, defaultOpen = true }: { kind: SolverKind; event: TraceEvent | null; collapsible?: boolean; defaultOpen?: boolean }) {
  const [tab, setTab] = useState<Tab>('solver');
  const solver = SOURCES[kind];
  const board = SOURCES.board;
  const member = useMemo(() => (event?.op ? extractMember(board.view, event.op) : null), [board, event?.op]);
  const effectiveTab: Tab = tab === 'board' && !member ? 'solver' : tab;

  let tokens: Token[][];
  let startLine: number;
  let active: readonly number[];
  let path: string;
  let text: string;
  if (effectiveTab === 'board' && member) {
    startLine = member.startLine;
    tokens = board.tokens.slice(member.startLine - 1, member.startLine - 1 + member.lines.length);
    active = [member.signatureLine];
    path = `${board.path} · lines ${member.startLine}–${member.startLine + member.lines.length - 1}`;
    text = member.lines.join('\n');
  } else {
    startLine = 1;
    tokens = solver.tokens;
    active = event ? (solver.view.steps.get(event.step) ?? []) : [];
    path = solver.path;
    text = solver.view.lines.join('\n');
  }

  const scrollRef = useRef<HTMLDivElement>(null);
  const preRef = useRef<HTMLPreElement>(null);
  useEffect(() => {
    const box = scrollRef.current;
    const first = box?.querySelector<HTMLElement>('[data-active="true"]');
    if (!box || !first) return;
    const top = first.offsetTop - box.clientHeight / 3;
    box.scrollTo({ top: Math.max(0, top) });
  }, [active, effectiveTab]);

  return (
    <Panel label="Source code" meta={path} collapsible={collapsible} defaultOpen={defaultOpen} flush actions={<CopyButton text={text} fallbackTarget={() => preRef.current} />}>
      <div className={styles.codeTabs} role="tablist" aria-label="Source file">
        <button type="button" role="tab" className={styles.codeTab} aria-selected={effectiveTab === 'solver'} onClick={() => setTab('solver')}>
          {kind === 'mrv' ? 'mrvSolver.ts' : 'backtrackingSolver.ts'}
        </button>
        <button type="button" role="tab" className={styles.codeTab} aria-selected={effectiveTab === 'board'} onClick={() => setTab('board')} disabled={!member}>
          {member ? `SudokuBoard.${member.name}()` : 'SudokuBoard (no board call in this step)'}
        </button>
      </div>
      <div className={styles.codeScroll} ref={scrollRef} tabIndex={0} aria-label="Source code listing">
        <pre className={styles.code} ref={preRef}>
          {tokens.map((line, i) => {
            const n = startLine + i;
            const on = active.includes(n);
            return (
              <div key={n} className={`${styles.codeLine} ${on ? styles.active : ''}`} data-active={on || undefined}>
                <span className={styles.lineNo}>{n}</span>
                <code style={{ background: 'none', padding: 0 }}>
                  {line.length === 0 ? ' ' : line.map((t, k) => <span key={k} className={styles[`tk-${t.kind}`]}>{t.text}</span>)}
                </code>
              </div>
            );
          })}
        </pre>
      </div>
      <div className={styles.codeFoot}>
        <span>TypeScript executed in this page · step marker comments hidden</span>
        <span>C++ reference: reference/cpp (not run here)</span>
      </div>
    </Panel>
  );
}
