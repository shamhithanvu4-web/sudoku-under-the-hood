import { useMemo } from 'react';
import type { Trace } from '../../solver/trace';
import type { Playback } from './usePlayback';
import styles from './Guided.module.css';

const BUCKETS = 320;

/**
 * The shape of the search: recursion depth across the whole run.
 * Climbs are placements, drops are backtracking. Red ticks mark BACKTRACK events.
 */
export function Timeline({ trace, p }: { trace: Trace; p: Playback }) {
  const { path, ticks, maxDepth } = useMemo(() => {
    const profile = trace.depthProfile(BUCKETS);
    const max = Math.max(1, ...profile);
    const n = profile.length;
    const points = profile.map((d, i) => `${((i + 0.5) / n) * 100},${100 - (d / max) * 92}`);
    const area = n ? `M0,100 L${points.join(' L')} L100,100 Z` : '';
    const tickSet = new Set<number>();
    for (const b of trace.backtracks) tickSet.add(Math.floor((b / Math.max(1, trace.length)) * 400));
    return { path: area, ticks: [...tickSet], maxDepth: max };
  }, [trace]);

  const x = trace.length > 0 ? ((Math.max(0, p.index) + 0.5) / trace.length) * 100 : 0;
  return (
    <div className={styles.timeline}>
      <div className={styles.timelineHead}>
        <span>search profile · recursion depth over time</span>
        <span>max depth {maxDepth}</span>
      </div>
      <div className={styles.timelineChart} aria-hidden="true">
        <svg viewBox="0 0 100 100" preserveAspectRatio="none">
          <path className={styles.profileArea} d={path} />
          {ticks.map((t) => (
            <line key={t} className={styles.backtrackTick} x1={t / 4} x2={t / 4} y1={100} y2={108} />
          ))}
          {p.index >= 0 && <line className={styles.playhead} x1={x} x2={x} y1={-4} y2={108} />}
        </svg>
      </div>
      <input
        className={styles.scrubber}
        type="range"
        min={-1}
        max={Math.max(0, trace.length - 1)}
        value={p.index}
        onChange={(e) => {
          p.setPlaying(false);
          p.setIndex(Number(e.target.value));
        }}
        aria-label="Position in the recorded run"
        aria-valuetext={p.index < 0 ? 'start' : `step ${p.index + 1} of ${trace.length}`}
      />
    </div>
  );
}
