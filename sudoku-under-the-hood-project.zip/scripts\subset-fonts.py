"""
Rebuilds src/assets/fonts/*.woff2 from the upstream variable fonts.

Sources: github.com/google/fonts, ofl/archivo/Archivo[wdth,wght].ttf and
ofl/jetbrainsmono/JetBrainsMono[wght].ttf (both SIL OFL 1.1).

    pip install fonttools brotli
    python scripts/subset-fonts.py path/to/google-fonts/ofl

Keeps Latin plus the arrows and math symbols the app uses, and narrows the
variation axes to the ranges the CSS uses (Archivo weight 400-800 and width
100-125; JetBrains Mono weight 400-700).
"""
import sys
from pathlib import Path

from fontTools import subset
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont

UNICODES = (
    "U+0020-007E,U+00A0-00FF,U+2010-2027,U+2032-2033,U+2190-2193,U+21D4,U+2212,"
    "U+221D,U+2248,U+2264-2265,U+230A-230B,U+232B,U+2713,U+2715,U+1D50,U+2070-2089"
)
OUT = Path(__file__).resolve().parent.parent / "src" / "assets" / "fonts"


def build(src: Path, out: Path, limits: dict) -> None:
    font = TTFont(src)
    options = subset.Options()
    options.layout_features = ["*"]
    options.name_IDs = ["*"]
    options.notdef_outline = True
    subsetter = subset.Subsetter(options)
    subsetter.populate(unicodes=subset.parse_unicodes(UNICODES))
    subsetter.subset(font)
    font = instantiateVariableFont(font, limits)
    font.flavor = "woff2"
    font.save(out)
    print(f"{out.name}: {out.stat().st_size / 1024:.1f} KB")


if __name__ == "__main__":
    ofl = Path(sys.argv[1] if len(sys.argv) > 1 else "ofl")
    build(ofl / "archivo" / "Archivo[wdth,wght].ttf", OUT / "archivo-variable.woff2", {"wght": (400, 800), "wdth": (100, 125)})
    build(ofl / "jetbrainsmono" / "JetBrainsMono[wght].ttf", OUT / "jetbrains-mono-variable.woff2", {"wght": (400, 700)})
