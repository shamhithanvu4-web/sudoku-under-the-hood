/**
 * GameSession — the rules of Play mode, independent of React.
 *
 * It owns one SudokuBoard and only ever changes it through the ADT's player
 * operation, setCell(). Undo/redo, pencil notes, checking and hints are
 * built on top. The React hook (useGameSession) just calls these methods
 * and re-renders from view().
 */
import { BoardError, SudokuBoard, SIZE, BOX, EMPTY, cellName, type Conflict, type Grid } from '../../domain/SudokuBoard';
import { runSolver } from '../../solver/runSolver';

export type Tone = 'info' | 'success' | 'warning' | 'error';
export interface Message {
  readonly tone: Tone;
  readonly text: string;
}

export type GameStatus = 'in-progress' | 'conflicts' | 'full-with-errors' | 'solved';
export type PuzzleHealth = 'ok' | 'contradictory' | 'unsolvable' | 'unknown';

interface Change {
  readonly index: number;
  readonly valueBefore: number;
  readonly valueAfter: number;
  readonly notesBefore: number;
  readonly notesAfter: number;
}
interface Move {
  readonly changes: readonly Change[];
}

export interface GameView {
  readonly values: readonly number[];
  readonly givens: readonly boolean[];
  /** Pencil marks as bitmasks: bit d set = note d. */
  readonly notes: readonly number[];
  readonly conflicts: ReadonlySet<number>;
  readonly wrong: ReadonlySet<number>;
  readonly hinted: ReadonlySet<number>;
  readonly status: GameStatus;
  readonly health: PuzzleHealth;
  readonly emptyCount: number;
  readonly canUndo: boolean;
  readonly canRedo: boolean;
}

export interface PuzzleMeta {
  readonly id: string;
  readonly name: string;
  readonly difficulty: string;
}

const rowOf = (i: number) => Math.floor(i / SIZE);
const colOf = (i: number) => i % SIZE;
const nameOf = (i: number) => cellName({ row: rowOf(i), col: colOf(i) });

function peersOf(i: number): number[] {
  const r = rowOf(i);
  const c = colOf(i);
  const out = new Set<number>();
  for (let k = 0; k < SIZE; k++) {
    out.add(r * SIZE + k);
    out.add(k * SIZE + c);
  }
  const top = r - (r % BOX);
  const left = c - (c % BOX);
  for (let y = top; y < top + BOX; y++) for (let x = left; x < left + BOX; x++) out.add(y * SIZE + x);
  out.delete(i);
  return [...out];
}

export class GameSession {
  readonly meta: PuzzleMeta;
  readonly health: PuzzleHealth;
  readonly #board: SudokuBoard;
  readonly #solution: readonly number[] | null;
  #notes: number[] = new Array(SIZE * SIZE).fill(0);
  #undo: Move[] = [];
  #redo: Move[] = [];
  #hinted = new Set<number>();
  #checked = new Set<number>();

  constructor(puzzle: Grid, meta: PuzzleMeta) {
    this.meta = meta;
    this.#board = new SudokuBoard(puzzle);
    const result = runSolver(puzzle, 'mrv', { record: false, maxCalls: 500_000 });
    this.#solution = result.solution ? result.solution.flat() : null;
    this.health =
      result.status === 'solved'
        ? 'ok'
        : result.status === 'invalid-puzzle'
          ? 'contradictory'
          : result.status === 'no-solution'
            ? 'unsolvable'
            : 'unknown';
  }

  /** The starting clues (frozen copy). */
  get original(): Grid {
    return this.#board.getOriginal();
  }

  /** The current board (frozen copy), e.g. for "solve from my board". */
  get current(): Grid {
    return this.#board.getSnapshot();
  }

  get solution(): readonly number[] | null {
    return this.#solution;
  }

  view(): GameView {
    const values = this.#board.getSnapshot().flat();
    const givens = values.map((_, i) => this.#board.isGiven(rowOf(i), colOf(i)));
    const conflicts = new Set<number>();
    for (const pair of this.#board.findAllConflicts()) {
      conflicts.add(pair.a.row * SIZE + pair.a.col);
      conflicts.add(pair.b.row * SIZE + pair.b.col);
    }
    const wrong = new Set([...this.#checked].filter((i) => this.#solution && values[i] !== EMPTY && values[i] !== this.#solution[i]));
    return {
      values,
      givens,
      notes: [...this.#notes],
      conflicts,
      wrong,
      hinted: new Set(this.#hinted),
      status: this.#status(conflicts.size),
      health: this.health,
      emptyCount: values.filter((v) => v === EMPTY).length,
      canUndo: this.#undo.length > 0,
      canRedo: this.#redo.length > 0,
    };
  }

  #status(conflictCount: number): GameStatus {
    if (this.#board.isSolved()) return 'solved';
    if (this.#board.isComplete()) return 'full-with-errors';
    return conflictCount > 0 ? 'conflicts' : 'in-progress';
  }

  /** Why `digit` cannot go in cell `index` right now (board.findConflict), or null if it fits. */
  conflictFor(index: number, digit: number): Conflict | null {
    return this.#board.findConflict(rowOf(index), colOf(index), digit);
  }

  /** Enters a digit (1–9) as the player. */
  enter(index: number, digit: number): Message | null {
    const row = rowOf(index);
    const col = colOf(index);
    const before = this.#board.getCell(row, col);
    if (before === digit && !this.#board.isGiven(row, col)) return null;
    const changes: Change[] = [];
    try {
      this.#board.setCell(row, col, digit);
    } catch (error) {
      if (error instanceof BoardError) return { tone: 'error', text: error.message };
      throw error;
    }
    changes.push({ index, valueBefore: before, valueAfter: digit, notesBefore: this.#notes[index], notesAfter: 0 });
    this.#notes[index] = 0;
    // Remove this digit from pencil notes in the same row, column and box.
    for (const p of peersOf(index)) {
      const bit = 1 << digit;
      if (this.#notes[p] & bit) {
        changes.push({ index: p, valueBefore: this.#board.getCell(rowOf(p), colOf(p)), valueAfter: this.#board.getCell(rowOf(p), colOf(p)), notesBefore: this.#notes[p], notesAfter: this.#notes[p] & ~bit });
        this.#notes[p] &= ~bit;
      }
    }
    this.#checked.delete(index);
    this.#hinted.delete(index);
    this.#commit({ changes });
    return this.#afterEntry(row, col, digit);
  }

  #afterEntry(row: number, col: number, digit: number): Message | null {
    if (this.#board.isSolved()) {
      return { tone: 'success', text: 'Solved! Every row, column and box holds 1–9 exactly once.' };
    }
    const conflict = this.#board.findConflict(row, col, digit);
    if (conflict) {
      return {
        tone: 'warning',
        text: `${digit} already appears in the same ${conflict.kind} at ${cellName(conflict.at)}.`,
      };
    }
    if (this.#board.isComplete()) {
      const n = new Set(this.#board.findAllConflicts().flatMap((p) => [`${p.a.row},${p.a.col}`, `${p.b.row},${p.b.col}`])).size;
      return { tone: 'warning', text: `All 81 cells are filled, but ${n} cells break a rule, so the puzzle is not solved yet.` };
    }
    return null;
  }

  erase(index: number): Message | null {
    const row = rowOf(index);
    const col = colOf(index);
    if (this.#board.isGiven(row, col)) {
      return { tone: 'error', text: `${nameOf(index)} is a starting clue and cannot be changed.` };
    }
    const before = this.#board.getCell(row, col);
    if (before === EMPTY && this.#notes[index] === 0) return null;
    this.#board.setCell(row, col, EMPTY);
    this.#commit({ changes: [{ index, valueBefore: before, valueAfter: EMPTY, notesBefore: this.#notes[index], notesAfter: 0 }] });
    this.#notes[index] = 0;
    this.#checked.delete(index);
    this.#hinted.delete(index);
    return null;
  }

  toggleNote(index: number, digit: number): Message | null {
    const row = rowOf(index);
    const col = colOf(index);
    if (this.#board.isGiven(row, col)) return { tone: 'error', text: `${nameOf(index)} is a starting clue.` };
    if (this.#board.getCell(row, col) !== EMPTY) return { tone: 'info', text: 'Notes go in empty cells. Erase the digit first.' };
    const before = this.#notes[index];
    const after = before ^ (1 << digit);
    this.#notes[index] = after;
    this.#commit({ changes: [{ index, valueBefore: EMPTY, valueAfter: EMPTY, notesBefore: before, notesAfter: after }] });
    return null;
  }

  #commit(move: Move): void {
    this.#undo.push(move);
    this.#redo = [];
  }

  #apply(move: Move, forward: boolean): void {
    const changes = forward ? move.changes : [...move.changes].reverse();
    for (const ch of changes) {
      const value = forward ? ch.valueAfter : ch.valueBefore;
      if (this.#board.getCell(rowOf(ch.index), colOf(ch.index)) !== value) {
        this.#board.setCell(rowOf(ch.index), colOf(ch.index), value);
      }
      this.#notes[ch.index] = forward ? ch.notesAfter : ch.notesBefore;
      this.#checked.delete(ch.index);
    }
  }

  undo(): boolean {
    const move = this.#undo.pop();
    if (!move) return false;
    this.#apply(move, false);
    this.#redo.push(move);
    return true;
  }

  redo(): boolean {
    const move = this.#redo.pop();
    if (!move) return false;
    this.#apply(move, true);
    this.#undo.push(move);
    return true;
  }

  reset(): void {
    this.#board.reset();
    this.#notes = new Array(SIZE * SIZE).fill(0);
    this.#undo = [];
    this.#redo = [];
    this.#hinted.clear();
    this.#checked.clear();
  }

  /** Compares the player's digits with the solution and marks the wrong ones. */
  check(): Message {
    if (!this.#solution) return this.#healthMessage();
    const values = this.#board.getSnapshot().flat();
    let correct = 0;
    let wrong = 0;
    let empty = 0;
    this.#checked.clear();
    values.forEach((v, i) => {
      if (this.#board.isGiven(rowOf(i), colOf(i))) return;
      if (v === EMPTY) empty++;
      else if (v === this.#solution![i]) correct++;
      else {
        wrong++;
        this.#checked.add(i);
      }
    });
    if (this.#board.isSolved()) return { tone: 'success', text: 'Solved! Every row, column and box holds 1–9 exactly once.' };
    if (wrong > 0) {
      return { tone: 'warning', text: `${wrong} ${wrong === 1 ? 'entry does' : 'entries do'} not match the solution (marked). ${correct} correct, ${empty} still empty.` };
    }
    return { tone: 'info', text: `No mistakes so far: ${correct} correct, ${empty} still empty.` };
  }

  #healthMessage(): Message {
    if (this.health === 'contradictory') return { tone: 'error', text: 'The starting clues break a rule, so this puzzle has no solution.' };
    if (this.health === 'unsolvable') return { tone: 'error', text: 'This puzzle has no solution: the solver tried every possibility.' };
    return { tone: 'error', text: 'The solution could not be computed for this puzzle.' };
  }

  /**
   * Gives one hint and fills it in. In order of preference:
   *   1. a digit that does not match the solution (pointed out, not changed);
   *   2. a naked single (a cell with one candidate), preferring `selected`;
   *   3. a hidden single (the only place for a digit in a row, column or box);
   *   4. the solution digit for the selected (or first empty) cell.
   */
  hint(selected: number | null): { message: Message; index: number | null } {
    if (!this.#solution) return { message: this.#healthMessage(), index: null };
    const values = this.#board.getSnapshot().flat();
    const wrongIndex = values.findIndex((v, i) => v !== EMPTY && v !== this.#solution![i]);
    if (wrongIndex !== -1) {
      this.#checked.add(wrongIndex);
      return {
        index: wrongIndex,
        message: { tone: 'warning', text: `${nameOf(wrongIndex)} does not match the solution. Fix it first; hints build on a correct board.` },
      };
    }
    if (this.#board.isSolved()) return { index: null, message: { tone: 'success', text: 'The puzzle is already solved.' } };

    const empties = values.map((v, i) => (v === EMPTY ? i : -1)).filter((i) => i >= 0);
    const candidates = (i: number) => this.#board.getCandidates(rowOf(i), colOf(i));

    const order = selected !== null && values[selected] === EMPTY ? [selected, ...empties.filter((i) => i !== selected)] : empties;
    const single = order.find((i) => candidates(i).length === 1);
    if (single !== undefined) {
      const digit = candidates(single)[0];
      return this.#give(single, digit, `${nameOf(single)} can only be ${digit}: every other digit already appears in its row, column or box.`);
    }

    for (const unit of units()) {
      for (let digit = 1; digit <= SIZE; digit++) {
        if (unit.cells.some((i) => values[i] === digit)) continue;
        const spots = unit.cells.filter((i) => values[i] === EMPTY && candidates(i).includes(digit));
        if (spots.length === 1) {
          return this.#give(spots[0], digit, `In ${unit.name}, ${digit} fits only at ${nameOf(spots[0])}.`);
        }
      }
    }

    const target = order[0];
    return this.#give(target, this.#solution[target], `No single-step deduction is available here, so this digit comes from the solver's solution.`);
  }

  #give(index: number, digit: number, reason: string): { message: Message; index: number } {
    this.enter(index, digit);
    this.#hinted.add(index);
    return { index, message: { tone: 'info', text: `Hint: ${reason}` } };
  }
}

function units(): { name: string; cells: number[] }[] {
  const out: { name: string; cells: number[] }[] = [];
  for (let i = 0; i < SIZE; i++) {
    out.push({ name: `row ${i + 1}`, cells: Array.from({ length: SIZE }, (_, k) => i * SIZE + k) });
    out.push({ name: `column ${i + 1}`, cells: Array.from({ length: SIZE }, (_, k) => k * SIZE + i) });
    const top = BOX * Math.floor(i / BOX);
    const left = BOX * (i % BOX);
    out.push({
      name: `box ${i + 1}`,
      cells: Array.from({ length: SIZE }, (_, k) => (top + Math.floor(k / BOX)) * SIZE + left + (k % BOX)),
    });
  }
  return out;
}
