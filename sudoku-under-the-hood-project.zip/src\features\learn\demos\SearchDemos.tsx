import { useMemo, useState } from 'react';
import { useApp } from '../../../app/AppState';
import { LESSON_PUZZLES } from '../../../app/puzzles';
import { Button } from '../../../components/Button';
import { cellName } from '../../../domain/SudokuBoard';
import { explainEvent } from '../../../explain/explain';
import { runSolver } from '../../../solver/runSolver';
import { measure, type Measurement } from '../../analyze/measure';
import { PuzzlePicker } from '../../board/PuzzlePicker';
import { SudokuGrid } from '../../board/SudokuGrid';
import { buildBoardView } from '../../guided/boardView';
import { usePlayback } from '../../guided/usePlayback';
import styles from '../Learn.module.css';

/** A compact replay of a real recorded run on a tiny lesson board. */
function MiniTrace({ puzzleId, jumpLabel }: { puzzleId: string; jumpLabel?: string }) {
  const puzzle = LESSON_PUZZLES[puzzleId];
  const run = useMemo(() => runSolver(puzzle.grid, 'backtracking', { record: true }), [puzzle]);
  const trace = run.trace!;
  const p = usePlayback(trace, puzzleId);
  const view = buildBoardView(trace, p.index, { depthLabels: true, candidateCounts: false });
  const stack = p.index >= 0 ? trace.stackAt(p.index) : [];
  const x = p.index >= 0 ? explainEvent(trace, p.index, 'backtracking') : null;
  const backtracks = trace.backtracks.length;
  return (
    <div className={styles.demo}>
      <div className={styles.demoBoard}>
        <SudokuGrid
          label="Lesson board"
          values={view.values}
          givens={view.givens}
          marks={view.marks}
          focusCell={view.focusCell}
          units={view.units}
          link={view.link}
          animKey={p.index}
        />
      </div>
      <div className={styles.demoSide}>
        <div className={styles.controls}>
          <Button size="sm" iconOnly icon="toStart" label="Back to the start" onClick={() => p.setIndex(-1)} />
          <Button size="sm" iconOnly icon="stepBack" label="Previous step" onClick={() => p.step(-1)} />
          <Button size="sm" variant="primary" icon={p.playing ? 'pause' : 'play'} onClick={p.toggle}>
            {p.playing ? 'Pause' : 'Play'}
          </Button>
          <Button size="sm" iconOnly icon="stepForward" label="Next step" onClick={() => p.step(1)} />
          {jumpLabel && (
            <Button size="sm" onClick={() => p.jumpTo('BACKTRACK', 1)} disabled={trace.findNext(p.index, (e) => e.type === 'BACKTRACK') < 0}>
              {jumpLabel}
            </Button>
          )}
          <span className="label">
            step {Math.max(0, p.index + 1)}/{trace.length} · {backtracks} backtracks in this run
          </span>
        </div>
        <p className={styles.eventLine} aria-live="polite">
          {x ? (
            <>
              <strong>{x.title}.</strong> {x.concise}
            </>
          ) : (
            `${puzzle.grid.flat().filter((v) => v === 0).length} empty cells. Press Play or step forward.`
          )}
        </p>
        <div>
          <span className="label">Call stack ({stack.length} {stack.length === 1 ? 'frame' : 'frames'}, newest on top)</span>
          <ol className={styles.miniStack} style={{ marginTop: 6 }}>
            {stack.map((f) => (
              <li key={f.id}>
                depth {f.depth} · solve() {f.cell ? `filling ${cellName(f.cell)}` : 'board full: base case'}
              </li>
            ))}
          </ol>
        </div>
      </div>
    </div>
  );
}

export const RecursionDemo = () => <MiniTrace puzzleId="mini-recursion" />;
export const BacktrackingDemo = () => <MiniTrace puzzleId="mini-backtracking" jumpLabel="Next backtrack" />;

const pow10 = (m: number) => m * Math.log10(9);
const sci = (exp: number) => {
  const e = Math.floor(exp);
  const mant = 10 ** (exp - e);
  return e < 6 ? Math.round(10 ** exp).toLocaleString('en-US') : `${mant.toFixed(1)} × 10^${e}`;
};

/** Lesson 9: the O(9^m) bound next to work measured on a real puzzle. */
export function ComplexityDemo() {
  const { puzzle } = useApp();
  const empties = puzzle.grid.flat().filter((v) => v === 0).length;
  const [m, setM] = useState(empties);
  const [measured, setMeasured] = useState<{ id: string; plain: Measurement; mrv: Measurement } | null>(null);
  const current = measured && measured.id === puzzle.id ? measured : null;
  const runMeasurement = () => {
    const plain = measure(puzzle.grid, 'backtracking', 1);
    const mrv = measure(puzzle.grid, 'mrv', 1);
    setMeasured({ id: puzzle.id, plain, mrv });
    setM(empties);
  };
  const boundExp = pow10(m);
  const rows: { label: string; exp: number; text: string; kind: string }[] = [
    { label: `Bound 9^${m}`, exp: boundExp, text: sci(boundExp), kind: 'bound' },
  ];
  if (current) {
    const add = (label: string, n: number, kind: string) => rows.push({ label, exp: Math.log10(Math.max(1, n)), text: n.toLocaleString('en-US'), kind });
    add('Plain: recursive calls', current.plain.result.stats.recursiveCalls, 'plain');
    add('Plain: digits tried', current.plain.result.stats.candidateAttempts, 'plain');
    add('MRV: recursive calls', current.mrv.result.stats.recursiveCalls, 'mrv');
    add('MRV: digits tried', current.mrv.result.stats.candidateAttempts, 'mrv');
  }
  const maxExp = Math.max(...rows.map((r) => r.exp), 1);
  return (
    <div className={styles.demoSide}>
      <div className={styles.controls} style={{ alignItems: 'flex-end', gap: '1rem' }}>
        <PuzzlePicker id="complexity-puzzle" />
        <Button variant="primary" size="sm" icon="gauge" onClick={runMeasurement}>
          Measure this puzzle
        </Button>
      </div>
      <label className={styles.controls} htmlFor="m-slider">
        <span className="label">m = {m} empty cells</span>
        <input id="m-slider" type="range" min={1} max={81} value={m} onChange={(e) => setM(Number(e.target.value))} style={{ flex: 1, minWidth: 120, accentColor: 'var(--olive)' }} />
      </label>
      <div className={styles.bars} role="img" aria-label="Bar chart on a logarithmic scale comparing the 9 to the m bound with measured solver work">
        {rows.map((r) => (
          <div key={r.label} className={styles.bar}>
            <span>{r.label}</span>
            <div className={styles.barTrack}>
              <div className={styles.barFill} data-kind={r.kind} style={{ width: `${Math.max(1.5, (r.exp / maxExp) * 100)}%` }} />
              <span className={styles.barValue}>{r.text}</span>
            </div>
          </div>
        ))}
      </div>
      <p className={styles.caption} style={{ margin: 0 }}>
        Bars use a logarithmic scale: each bar's length is proportional to its number of digits.{' '}
        {current
          ? `Measured just now on "${puzzle.name}" (${empties} empty cells): plain ${current.plain.median.toFixed(1)} ms, MRV ${current.mrv.median.toFixed(1)} ms in this browser. One timed run each after an uncounted warm-up run; Analyze repeats the timed runs and reports the median.`
          : 'Press Measure to run both solvers on this puzzle and add their real counts.'}
      </p>
    </div>
  );
}
