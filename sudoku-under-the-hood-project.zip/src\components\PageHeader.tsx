import type { ReactNode } from 'react';
import styles from './Page.module.css';

export function PageHeader({ label, title, children, tools }: { label: string; title: string; children?: ReactNode; tools?: ReactNode }) {
  return (
    <header className={styles.header}>
      <div className={styles.intro}>
        <span className="label">{label}</span>
        <h1>{title}</h1>
        {children && <p>{children}</p>}
      </div>
      {tools && <div className={styles.headerTools}>{tools}</div>}
    </header>
  );
}

export const pageStyles = styles;
