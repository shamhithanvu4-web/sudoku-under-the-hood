/** Bundled puzzles (src/data/puzzles.json) as ready-to-use grids. */
import data from '../data/puzzles.json';
import { gridFromString } from '../domain/puzzleFormat';
import type { Grid } from '../domain/SudokuBoard';

export type PuzzleGroup = 'demo' | 'puzzle' | 'lab' | 'custom' | 'lesson';

export interface PuzzleDef {
  readonly id: string;
  readonly name: string;
  readonly difficulty: string;
  readonly grid: Grid;
  readonly group: PuzzleGroup;
  readonly description?: string;
}

interface RawPuzzle {
  id: string;
  name: string;
  difficulty: string;
  givens: string;
  description?: string;
}

const toDef = (p: RawPuzzle, group: PuzzleGroup): PuzzleDef => ({
  id: p.id,
  name: p.name,
  difficulty: p.difficulty,
  grid: gridFromString(p.givens),
  group,
  description: p.description,
});

export const DEMO_ID: string = data.demoId;

export const BUNDLED: readonly PuzzleDef[] = [
  ...(data.puzzles as RawPuzzle[]).map((p) => toDef(p, p.id === data.demoId ? 'demo' : 'puzzle')),
  ...(data.lab as RawPuzzle[]).map((p) => toDef(p, 'lab')),
];

export const LESSON_PUZZLES: Record<string, PuzzleDef> = Object.fromEntries(
  (data.lessons as RawPuzzle[]).map((p) => [p.id, toDef(p, 'lesson')]),
);

export const DIFFICULTY_LABEL: Record<string, string> = {
  easy: 'Easy',
  medium: 'Medium',
  hard: 'Hard',
  expert: 'Expert',
};

export const DIFFICULTY_NOTE: Record<string, string> = {
  easy: 'Solvable with naked singles only (cells with one possible digit).',
  medium: 'Also needs hidden singles (the only place a digit fits in a row, column or box).',
  hard: 'Also needs candidate eliminations such as pointing pairs or naked pairs.',
  expert: 'Those techniques get stuck; finishing needs trial and error.',
};

export const countClues = (grid: Grid): number => grid.flat().filter((v) => v !== 0).length;
