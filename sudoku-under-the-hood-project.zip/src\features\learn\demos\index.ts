import type { ComponentType } from 'react';
import { AdtDemo, EncapsulationDemo, RepresentationsDemo } from './AdtDemos';
import { CandidatesDemo, ConstraintsDemo, IndexingDemo, MrvDemo } from './BoardDemos';
import { BacktrackingDemo, ComplexityDemo, RecursionDemo } from './SearchDemos';

export const DEMOS: Record<string, ComponentType> = {
  adt: AdtDemo,
  representations: RepresentationsDemo,
  encapsulation: EncapsulationDemo,
  indexing: IndexingDemo,
  constraints: ConstraintsDemo,
  recursion: RecursionDemo,
  backtracking: BacktrackingDemo,
  candidates: CandidatesDemo,
  complexity: ComplexityDemo,
  mrv: MrvDemo,
};
