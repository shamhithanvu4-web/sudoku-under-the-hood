import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import lessons from '../../src/data/lessons.json';
import guide from '../../src/data/presenterGuide.json';
import { extractMember, indexSource } from '../../src/explain/sourceIndex';
import { runSolver } from '../../src/solver/runSolver';
import { puzzle } from './helpers';

const FILES: Record<string, string> = {
  board: 'domain/SudokuBoard.ts',
  counter: 'domain/solutionCounter.ts',
  backtracking: 'solver/backtrackingSolver.ts',
  mrv: 'solver/mrvSolver.ts',
};
const DEMOS = ['adt', 'representations', 'encapsulation', 'indexing', 'constraints', 'recursion', 'backtracking', 'candidates', 'complexity', 'optimization', 'mrv'];

describe('lesson content', () => {
  test('there are ten lessons, each complete', () => {
    assert.equal(lessons.length, 10);
    for (const l of lessons) {
      assert.ok(l.title.length > 3, `${l.id}.title`);
      for (const field of ['definition', 'example', 'demoCaption', 'implementation'] as const) assert.ok(l[field].length > 40, `${l.id}.${field}`);
      assert.ok(DEMOS.includes(l.demo), `${l.id} demo`);
      assert.ok(l.quiz.answer >= 0 && l.quiz.answer < l.quiz.options.length, `${l.id} quiz answer`);
    }
  });

  test('every lesson points at real source code', () => {
    for (const l of lessons) {
      const view = indexSource(readFileSync(new URL(`../../src/${FILES[l.code.file]}`, import.meta.url), 'utf8'));
      if ('member' in l.code && l.code.member) assert.ok(extractMember(view, l.code.member), `${l.id}: ${l.code.member}`);
      if ('step' in l.code && l.code.step) assert.ok(view.steps.get(l.code.step)?.length, `${l.id}: step ${l.code.step}`);
    }
  });

  test('claims made about the lesson boards are true', () => {
    const recursion = runSolver(puzzle('mini-recursion'), 'backtracking', { record: true });
    assert.equal(puzzle('mini-recursion').flat().filter((v) => v === 0).length, 7);
    assert.equal(recursion.stats.backtracks, 0);
    assert.equal(recursion.stats.maxDepth + 1, 8); // frames at the deepest point, the quiz answer
    const backtracking = runSolver(puzzle('mini-backtracking'), 'backtracking', { record: true });
    assert.ok(backtracking.stats.backtracks >= 1);
  });

  test('the 2D-array quiz arithmetic is right', () => {
    const q = lessons.find((l) => l.id === 'arrays-2d')!.quiz;
    assert.equal(q.options[q.answer], String(5 * 9 + 2));
  });

  test('the classroom demo reaches a real backtrack early', () => {
    const run = runSolver(puzzle('demo'), 'backtracking', { record: true });
    assert.ok(run.trace!.backtracks[0] < 250);
    assert.ok(run.trace!.findNext(-1, (e) => e.type === 'VALIDATION_FAILED') >= 0);
  });

  test('presenter guide has ten optional steps', () => {
    assert.equal(guide.length, 10);
  });
});
