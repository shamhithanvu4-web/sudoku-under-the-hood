import type { ReactNode } from 'react';
import { Icon } from './Icon';
import styles from './Panel.module.css';

interface Props {
  label: string;
  meta?: ReactNode;
  actions?: ReactNode;
  children: ReactNode;
  /** Render as a disclosure the user can open and close. */
  collapsible?: boolean;
  defaultOpen?: boolean;
  flush?: boolean;
  className?: string;
  id?: string;
}

/** A labelled readout: mono label strip on top, content below. */
export function Panel({ label, meta, actions, children, collapsible, defaultOpen = true, flush, className, id }: Props) {
  const head = (
    <>
      <div className={styles.title}>
        <span className="label">{label}</span>
        {meta && <span className={styles.meta}>{meta}</span>}
      </div>
      {actions && (
        <div className={styles.actions} onClick={(e) => collapsible && e.stopPropagation()}>
          {actions}
        </div>
      )}
      {collapsible && (
        <span className={styles.chevron} aria-hidden="true">
          <Icon name="chevron" size={16} />
        </span>
      )}
    </>
  );
  const body = <div className={`${styles.body} ${flush ? styles.flush : ''}`}>{children}</div>;
  if (collapsible) {
    return (
      <details className={`${styles.panel} ${className ?? ''}`} open={defaultOpen} id={id}>
        <summary className={styles.head}>{head}</summary>
        {body}
      </details>
    );
  }
  return (
    <section className={`${styles.panel} ${className ?? ''}`} aria-label={label} id={id}>
      <header className={styles.head}>{head}</header>
      {body}
    </section>
  );
}
