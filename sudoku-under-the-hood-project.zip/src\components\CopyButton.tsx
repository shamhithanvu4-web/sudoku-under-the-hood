import { useState } from 'react';
import { Button } from './Button';

/** Copies text to the clipboard; falls back to selecting `fallbackTarget` when the clipboard is unavailable. */
export function CopyButton({ text, fallbackTarget, label = 'Copy' }: { text: string; fallbackTarget?: () => HTMLElement | null; label?: string }) {
  const [state, setState] = useState<'idle' | 'copied' | 'selected'>('idle');
  const onClick = () => {
    const done = (s: 'copied' | 'selected') => {
      setState(s);
      window.setTimeout(() => setState('idle'), 1600);
    };
    const select = () => {
      const el = fallbackTarget?.();
      if (!el) return;
      const range = document.createRange();
      range.selectNodeContents(el);
      const sel = window.getSelection();
      sel?.removeAllRanges();
      sel?.addRange(range);
      done('selected');
    };
    try {
      navigator.clipboard.writeText(text).then(() => done('copied'), select);
    } catch {
      select();
    }
  };
  return (
    <Button size="sm" variant="ghost" icon={state === 'copied' ? 'check' : 'copy'} onClick={onClick} aria-live="polite">
      {state === 'copied' ? 'Copied' : state === 'selected' ? 'Selected, press Ctrl+C' : label}
    </Button>
  );
}
