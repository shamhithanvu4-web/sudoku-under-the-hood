/**
 * Maps solver step ids and board operations to lines of the real source files.
 *
 * The app bundles the exact text of src/solver/*.ts and src/domain/SudokuBoard.ts
 * (see sources.ts). A step id is found two ways:
 *   - as the first argument of a recorder call:   rec.emit('place', …)
 *   - in a marker comment on an operation line:   board.placeCandidate(…); // @step place
 * Marker comments are removed for display; line numbers stay the same as the file.
 */

export interface SourceView {
  /** Lines as displayed (marker comments removed). Index 0 is line 1. */
  readonly lines: readonly string[];
  /** Step id → 1-based line numbers to highlight. */
  readonly steps: ReadonlyMap<string, readonly number[]>;
}

const MARKER = /\s*\/\/ @step ([a-z][a-z- ]*)$/;
const ANCHOR = /rec\.(?:emit|enter|exit)\('([a-z-]+)'/;

export function indexSource(text: string): SourceView {
  const raw = text.replace(/\r\n/g, '\n').replace(/\n$/, '').split('\n');
  const steps = new Map<string, number[]>();
  const add = (step: string, line: number) => {
    const list = steps.get(step) ?? [];
    if (!list.includes(line)) list.push(line);
    steps.set(step, list);
  };
  const lines = raw.map((line, i) => {
    const marker = line.match(MARKER);
    if (marker) marker[1].trim().split(/\s+/).forEach((step) => add(step, i + 1));
    const anchor = line.match(ANCHOR);
    if (anchor) add(anchor[1], i + 1);
    return marker ? line.slice(0, marker.index) : line;
  });
  for (const list of steps.values()) list.sort((a, b) => a - b);
  return { lines, steps };
}

export interface MethodSource {
  readonly name: string;
  /** 1-based line where the excerpt (including its doc comment) starts. */
  readonly startLine: number;
  readonly lines: readonly string[];
  /** 1-based line of the signature. */
  readonly signatureLine: number;
}

/**
 * Extracts a class method or top-level function, with the doc comment above it.
 * Matches `  name(` (method) or `function name(` / `export function name(`.
 */
export function extractMember(view: SourceView, name: string): MethodSource | null {
  const { lines } = view;
  const signature = new RegExp(`^(?:\\s{2}(?:static\\s+)?|(?:export\\s+)?function\\s+)${name}\\(`);
  const at = lines.findIndex((line) => signature.test(line));
  if (at === -1) return null;

  let start = at;
  if (lines[at - 1]?.trim().endsWith('*/')) {
    start = at - 1;
    while (start > 0 && !lines[start].trim().startsWith('/**')) start--;
  }

  let depth = 0;
  let end = at;
  let opened = false;
  for (let i = at; i < lines.length; i++) {
    for (const ch of lines[i]) {
      if (ch === '{') {
        depth++;
        opened = true;
      } else if (ch === '}') {
        depth--;
      }
    }
    if (opened && depth === 0) {
      end = i;
      break;
    }
  }
  return { name, startLine: start + 1, signatureLine: at + 1, lines: lines.slice(start, end + 1) };
}

/** Public method signatures of a class, in source order (for the ADT lesson). */
export function publicSignatures(view: SourceView): string[] {
  return view.lines
    .filter((line) => /^ {2}(?!#|\/|\*|readonly|constructor|private|get |set )[a-zA-Z]+\(.*\).*\{$/.test(line))
    .map((line) => line.trim().replace(/\s*\{$/, ''));
}
