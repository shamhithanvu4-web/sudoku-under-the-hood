/**
 * The one-line note shown under a puzzle. For the classroom demo the step
 * counts are measured by recording a real run of the plain solver, once per
 * page load, so the text always matches what Under the Hood replays.
 */
import { DEMO_ID, type PuzzleDef } from '../../app/puzzles';
import { runSolver } from '../../solver/runSolver';

const cache = new Map<string, string>();
const fmt = (n: number) => n.toLocaleString('en-US');

export function puzzleNote(puzzle: PuzzleDef): string | null {
  if (puzzle.id !== DEMO_ID) return puzzle.description ?? null;
  const cached = cache.get(puzzle.id);
  if (cached) return cached;
  const run = runSolver(puzzle.grid, 'backtracking', { record: true });
  const trace = run.trace;
  let note = puzzle.description ?? '';
  if (trace && run.status === 'solved') {
    const first = trace.backtracks[0];
    note += ` Measured in this browser: the plain solver's recorded run has ${fmt(trace.length)} steps`;
    note += first === undefined ? ' and no backtracks.' : `, and its first backtrack is step ${fmt(first + 1)}.`;
  }
  cache.set(puzzle.id, note.trim());
  return note.trim();
}
