import { cellName } from '../../domain/SudokuBoard';
import styles from './Guided.module.css';

/**
 * The same 81 cells laid out the way memory holds them: row after row (row-major order).
 * `detailed` shows the 0-based array indices; otherwise positions are counted from 1.
 */
export function MemoryStrip({ values, givens, focus, detailed = true }: { values: ArrayLike<number>; givens: readonly boolean[]; focus: number | null; detailed?: boolean }) {
  const cells = Array.from({ length: 81 }, (_, i) => (i === focus ? 'focus' : givens[i] ? 'given' : values[i] ? 'solver' : 'empty'));
  return (
    <div className={styles.memory}>
      <div className={styles.memoryStrip} aria-hidden="true">
        {cells.map((v, i) => (
          <span key={i} data-v={v} />
        ))}
      </div>
      <div className={styles.memoryCaption}>
        <span>{detailed ? 'row-major: index = row × 9 + col' : 'memory order: row after row'}</span>
        <span>
          {focus === null
            ? '81 cells'
            : detailed
              ? `cells[${focus}] ⇔ grid[${Math.floor(focus / 9)}][${focus % 9}]`
              : `${cellName({ row: Math.floor(focus / 9), col: focus % 9 })} is cell ${focus + 1} of 81`}
        </span>
      </div>
    </div>
  );
}
