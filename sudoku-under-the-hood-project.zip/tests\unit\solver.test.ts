import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { SudokuBoard, type Grid } from '../../src/domain/SudokuBoard';
import { gridFromString } from '../../src/domain/puzzleFormat';
import { countSolutions } from '../../src/domain/solutionCounter';
import { ratePuzzle } from '../../src/domain/difficulty';
import { Recorder } from '../../src/solver/recorder';
import { selectMRVCell } from '../../src/solver/mrvSolver';
import { runSolver, SOLVERS } from '../../src/solver/runSolver';
import type { SolverKind } from '../../src/solver/types';
import { CLASSIC, CLASSIC_SOLUTION, data, isValidSolution, keepsClues, puzzle, copy } from './helpers';

const KINDS: SolverKind[] = ['backtracking', 'mrv'];

describe('bundled puzzle data', () => {
  for (const p of data.puzzles) {
    test(`${p.id} has one solution and the label "${p.difficulty}"`, () => {
      const grid = gridFromString(p.givens);
      assert.equal(countSolutions(grid, 2), 1);
      assert.equal(ratePuzzle(grid).difficulty, p.difficulty);
    });
  }
  test('lesson boards have one solution each', () => {
    for (const p of data.lessons) assert.equal(countSolutions(gridFromString(p.givens), 2), 1);
  });
});

describe('solving valid puzzles', () => {
  test('the independent checker accepts the known solution', () => {
    assert.ok(isValidSolution(CLASSIC_SOLUTION));
  });

  for (const kind of KINDS) {
    test(`${kind}: every bundled puzzle is solved correctly`, () => {
      for (const p of [...data.puzzles, ...data.lessons]) {
        const grid = gridFromString(p.givens);
        const result = runSolver(grid, kind, { record: false });
        assert.equal(result.status, 'solved', p.id);
        assert.ok(result.solution && isValidSolution(result.solution), `${p.id} solution breaks a rule`);
        assert.ok(keepsClues(grid, result.solution!), `${p.id} changed a clue`);
      }
    });

    test(`${kind}: finds the known solution of the classic puzzle`, () => {
      const result = runSolver(CLASSIC, kind, { record: true });
      assert.deepEqual(result.solution, CLASSIC_SOLUTION);
    });

    test(`${kind}: does not modify the caller's puzzle`, () => {
      const grid = copy(CLASSIC);
      runSolver(grid, kind, { record: false });
      assert.deepEqual(grid, CLASSIC);
    });
  }
});

describe('special cases', () => {
  for (const kind of KINDS) {
    test(`${kind}: an already solved grid is confirmed in one call`, () => {
      const result = runSolver(CLASSIC_SOLUTION, kind, { record: true });
      assert.equal(result.status, 'solved');
      assert.equal(result.alreadySolved, true);
      assert.equal(result.stats.recursiveCalls, 1);
      assert.equal(result.stats.placements, 0);
    });

    test(`${kind}: contradictory clues are refused before searching`, () => {
      const result = runSolver(puzzle('lab-contradictory'), kind, { record: true });
      assert.equal(result.status, 'invalid-puzzle');
      assert.equal(result.stats.recursiveCalls, 0);
      assert.equal(result.trace, null);
    });

    test(`${kind}: an unsolvable puzzle ends with NO_SOLUTION`, () => {
      const grid = puzzle('lab-unsolvable');
      assert.equal(new SudokuBoard(grid).validatePuzzle().ok, true);
      assert.equal(countSolutions(grid, 1), 0);
      const result = runSolver(grid, kind, { record: true });
      assert.equal(result.status, 'no-solution');
      assert.equal(result.solution, null);
      assert.equal(result.trace!.events.at(-1)!.type, 'NO_SOLUTION');
    });

    test(`${kind}: a failed search restores the board exactly`, () => {
      const grid = puzzle('lab-unsolvable');
      const board = new SudokuBoard(grid);
      const solved = SOLVERS[kind](board, new Recorder({ record: false }));
      assert.equal(solved, false);
      assert.deepEqual(board.getSnapshot(), grid);
      assert.equal(board.placementCount(), 0);
    });

    test(`${kind}: malformed input is reported, not thrown`, () => {
      const result = runSolver(CLASSIC.slice(0, 5), kind, { record: true });
      assert.equal(result.status, 'malformed');
    });
  }

  test('an unsolvable cell with no candidates is caught early by MRV', () => {
    // r1 holds 1..8, and column 9 already has a 9, so r1c9 has no candidates.
    const grid = copy(gridFromString('.'.repeat(81)));
    grid[0] = [1, 2, 3, 4, 5, 6, 7, 8, 0];
    grid[5][8] = 9;
    const mrv = runSolver(grid, 'mrv', { record: true });
    assert.equal(mrv.status, 'no-solution');
    assert.equal(mrv.stats.recursiveCalls, 1);
    assert.equal(mrv.stats.placements, 0);
    const deadEnd = mrv.trace!.events.find((e) => e.type === 'DEAD_END')!;
    assert.equal(deadEnd.step, 'fail-early');
    assert.deepEqual(deadEnd.cell, { row: 0, col: 8 });
  });
});

describe('MRV cell selection', () => {
  test('picks the empty cell with the fewest candidates, earliest on ties', () => {
    for (const p of [...data.puzzles.slice(0, 6), ...data.lessons]) {
      const board = new SudokuBoard(gridFromString(p.givens));
      let best: { row: number; col: number; n: number } | null = null;
      for (let row = 0; row < 9; row++) {
        for (let col = 0; col < 9; col++) {
          if (board.getCell(row, col) !== 0) continue;
          const n = board.getCandidates(row, col).length;
          if (!best || n < best.n) best = { row, col, n };
        }
      }
      const choice = selectMRVCell(board)!;
      assert.deepEqual(choice.cell, { row: best!.row, col: best!.col }, p.id);
      assert.deepEqual(choice.candidates, board.getCandidates(best!.row, best!.col));
    }
  });

  test('returns null for a full board and stops at a zero-candidate cell', () => {
    assert.equal(selectMRVCell(new SudokuBoard(CLASSIC_SOLUTION)), null);
    const grid = copy(gridFromString('.'.repeat(81)));
    grid[0] = [1, 2, 3, 4, 5, 6, 7, 8, 0];
    grid[5][8] = 9;
    const choice = selectMRVCell(new SudokuBoard(grid))!;
    assert.deepEqual(choice.cell, { row: 0, col: 8 });
    assert.deepEqual(choice.candidates, []);
  });
});

describe('trace consistency', () => {
  for (const kind of KINDS) {
    for (const id of ['demo', 'mini-backtracking', 'lab-unsolvable']) {
      test(`${kind} on ${id}: replay matches the run`, () => {
        const grid = puzzle(id);
        const run = runSolver(grid, kind, { record: true });
        const trace = run.trace!;
        const last = trace.length - 1;

        // Counters rebuilt from the trace equal the live counters, and an untraced run counts the same work.
        assert.deepEqual(trace.statsAt(last), run.stats);
        assert.deepEqual(runSolver(grid, kind, { record: false }).stats, run.stats);

        // Final board matches the result.
        const final = Array.from(trace.boardAt(last));
        assert.deepEqual(final, run.solution ? run.solution.flat() : grid.flat());

        // Calls open and close in pairs, and the stack is empty at the end.
        const entered = trace.events.filter((e) => e.type === 'RECURSION_ENTERED').length;
        const returned = trace.events.filter((e) => e.type === 'RECURSION_RETURNED').length;
        assert.equal(entered, returned);
        assert.equal(entered, run.stats.recursiveCalls);
        assert.ok(trace.calls.every((c) => c.exitIndex !== null && c.result !== null));

        // Event-level invariants, checked against the replayed board.
        let board = Array.from(trace.boardAt(-1));
        const candidatesByCall = new Map<number, readonly number[]>();
        for (const e of trace.events) {
          const before = board.slice();
          if (e.type === 'VALUE_PLACED' || e.type === 'BACKTRACK') board[e.cell!.row * 9 + e.cell!.col] = e.after!;
          assert.deepEqual(Array.from(trace.boardAt(e.index)), board, `board at ${e.index}`);

          if (e.type === 'VALIDATION_FAILED') {
            // The reported clash really is on the board.
            const at = e.conflict!.at;
            assert.equal(before[at.row * 9 + at.col], e.digit);
          }
          if (e.type === 'VALUE_PLACED') {
            assert.equal(before[e.cell!.row * 9 + e.cell!.col], 0);
            const prev = trace.events[e.index - 1];
            if (kind === 'backtracking') assert.equal(prev.type, 'VALIDATION_PASSED');
            else assert.ok(candidatesByCall.get(e.callId)!.includes(e.digit!));
          }
          if (e.type === 'CANDIDATES_COMPUTED') candidatesByCall.set(e.callId, e.candidates!);
          if (e.type === 'BACKTRACK') {
            // Restored to empty, right after its branch returned false.
            assert.equal(board[e.cell!.row * 9 + e.cell!.col], 0);
            const prev = trace.events[e.index - 1];
            assert.equal(prev.type, 'RECURSION_RETURNED');
            assert.equal(prev.result, false);
          }
          if (e.type === 'DEAD_END' && e.step === 'exhausted' && kind === 'backtracking') {
            // All nine digits were tried for this cell in this call.
            const tried = trace.events.filter(
              (x) => x.callId === e.callId && x.type === 'CANDIDATE_TRIED',
            ).length;
            assert.equal(tried, 9);
          }
          if (e.callId >= 0) assert.equal(trace.stackAt(e.index).length, e.depth + 1);
        }
      });
    }
  }

  test('stepping backwards and forwards gives the same boards', () => {
    const trace = runSolver(puzzle('demo'), 'backtracking', { record: true }).trace!;
    const forward = Array.from({ length: trace.length }, (_, i) => trace.boardAt(i).join(''));
    for (let i = trace.length - 1; i >= 0; i -= 7) assert.equal(trace.boardAt(i).join(''), forward[i]);
    for (let i = 0; i < trace.length; i += 13) assert.equal(trace.boardAt(i).join(''), forward[i]);
  });

  test('a trace limit stops recording honestly', () => {
    const run = runSolver(puzzle('demo'), 'backtracking', { record: true, maxEvents: 500 });
    assert.equal(run.status, 'limit-reached');
    assert.equal(run.limit, 'events');
    assert.equal(run.trace!.length, 500);
    assert.deepEqual(run.trace!.statsAt(499), run.stats);
  });

  test('a call limit stops the search', () => {
    const run = runSolver(puzzle('demo'), 'backtracking', { record: false, maxCalls: 50 });
    assert.equal(run.status, 'limit-reached');
    assert.equal(run.limit, 'calls');
    assert.equal(run.stats.recursiveCalls, 50);
  });
});

describe('termination', () => {
  test('recursion depth never exceeds the number of empty cells', () => {
    for (const kind of KINDS) {
      for (const p of data.puzzles.slice(0, 7)) {
        const grid: Grid = gridFromString(p.givens);
        const empty = grid.flat().filter((v) => v === 0).length;
        const run = runSolver(grid, kind, { record: false });
        assert.equal(run.stats.maxDepth, empty);
      }
    }
  });
});
