import { useApp } from '../../app/AppState';
import { countClues, DIFFICULTY_NOTE } from '../../app/puzzles';
import { Button } from '../../components/Button';
import { MessageBar } from '../../components/MessageBar';
import { PageHeader, pageStyles } from '../../components/PageHeader';
import { Panel } from '../../components/Panel';
import { DifficultyChip, PuzzlePicker } from '../board/PuzzlePicker';
import { SudokuGrid } from '../board/SudokuGrid';
import { puzzleNote } from '../board/puzzleNote';
import { CustomPuzzleForm } from './CustomPuzzleForm';
import { KeyboardHelp, NumberPad, PlayTools } from './PlayControls';
import { usePlayController } from './usePlayController';
import { useIsNarrow } from '../../hooks/useMediaQuery';
import type { GameStatus } from './gameSession';
import styles from './PlayPage.module.css';

const STATUS: Record<GameStatus, { label: string; tone: string }> = {
  'in-progress': { label: 'In progress', tone: 'neutral' },
  conflicts: { label: 'Rule conflict', tone: 'warning' },
  'full-with-errors': { label: 'Full, not solved', tone: 'warning' },
  solved: { label: 'Solved', tone: 'success' },
};

export function PlayPage() {
  const { puzzle, navigate } = useApp();
  const c = usePlayController();
  const narrow = useIsNarrow();
  const { view } = c;
  const filled = 81 - view.emptyCount;
  const clues = countClues(puzzle.grid);
  const status = STATUS[view.status];
  const note = puzzleNote(puzzle);
  const intro =
    'Fill every row, column and 3×3 box with the digits 1 to 9. Pay attention to how you decide: which cell you look at, how you rule digits out, and what you do when you get stuck. The solver makes the same kinds of decisions.';

  return (
    <div className={pageStyles.wrap}>
      {/* On phones the board comes first; the picker and introduction follow it. */}
      <PageHeader label="Play mode" title="Solve it yourself first" tools={narrow ? undefined : <PuzzlePicker />}>
        {narrow ? undefined : intro}
      </PageHeader>

      {view.health === 'contradictory' && (
        <MessageBar message={{ tone: 'error', text: 'The starting clues of this puzzle break a rule (highlighted in red), so it has no solution. The solver will refuse to start on it.' }} />
      )}
      {view.health === 'unsolvable' && (
        <MessageBar message={{ tone: 'error', text: 'This puzzle has no solution, even though no two clues clash. Try it, then open Under the Hood to watch the solver prove it.' }} />
      )}

      <div className={styles.layout}>
        <div className={styles.boardCol}>
          <div className={styles.meta}>
            <DifficultyChip puzzle={puzzle} />
            <span className={styles.metaItem}>{clues} clues</span>
            <span className={styles.metaItem}>
              {filled}/81 filled
            </span>
            <span className={styles.status} data-tone={status.tone}>
              {status.label}
            </span>
          </div>
          <SudokuGrid
            label={`${puzzle.name} Sudoku board`}
            values={view.values}
            givens={view.givens}
            notes={view.notes}
            marks={c.marks}
            selected={c.selected}
            onSelect={c.setSelected}
            onKey={c.onKey}
            showPeers
            coords="sudoku"
          />
          {narrow && (
            <>
              <NumberPad c={c} />
              <MessageBar message={c.message} placeholder="Tap a cell, then a digit." />
            </>
          )}
          <div className={styles.progress} aria-hidden="true">
            <div style={{ width: `${(filled / 81) * 100}%` }} />
          </div>
          {note && <p className={styles.note}>{note}</p>}
          {DIFFICULTY_NOTE[puzzle.difficulty] && <p className={styles.note}>Difficulty: {DIFFICULTY_NOTE[puzzle.difficulty]}</p>}
        </div>

        <div className={styles.side}>
          {narrow && (
            <>
              <PuzzlePicker />
              <p className={styles.formLabel}>{intro}</p>
            </>
          )}
          {!narrow && <MessageBar message={c.message} placeholder="Select a cell, then type a digit or use the keypad." />}
          <Panel label={narrow ? 'Tools' : 'Input'} meta={c.notesMode ? 'pencil notes' : 'digits'}>
            <div className={styles.stack}>
              {!narrow && <NumberPad c={c} />}
              <PlayTools c={c} />
              <KeyboardHelp />
            </div>
          </Panel>
          <Panel label="Next">
            <div className={styles.stack}>
              <p>
                When you have tried for a while, watch a recursive backtracking solver work on this same puzzle. Every step it
                takes is recorded, explained and linked to its source code.
              </p>
              <div className={styles.row}>
                <Button variant="primary" icon="arrowRight" onClick={() => navigate('solve')}>
                  See how the computer solves it
                </Button>
              </div>
            </div>
          </Panel>
          <Panel label="Load your own puzzle" collapsible defaultOpen={false}>
            <CustomPuzzleForm />
          </Panel>
        </div>
      </div>
    </div>
  );
}
