/**
 * The exact source text of the modules the app executes, bundled at build time
 * (see the `?raw` plugin in scripts/shared.mjs). The code panel shows these files.
 */
import backtrackingText from '../solver/backtrackingSolver.ts?raw';
import mrvText from '../solver/mrvSolver.ts?raw';
import boardText from '../domain/SudokuBoard.ts?raw';
import counterText from '../domain/solutionCounter.ts?raw';
import { highlight, type Token } from './highlight';
import { indexSource, type SourceView } from './sourceIndex';

export interface SourceFile {
  readonly path: string;
  readonly view: SourceView;
  readonly tokens: Token[][];
}

function load(path: string, text: string): SourceFile {
  const view = indexSource(text);
  return { path, view, tokens: highlight(view.lines.join('\n')) };
}

export const SOURCES = {
  backtracking: load('src/solver/backtrackingSolver.ts', backtrackingText),
  mrv: load('src/solver/mrvSolver.ts', mrvText),
  board: load('src/domain/SudokuBoard.ts', boardText),
  counter: load('src/domain/solutionCounter.ts', counterText),
} as const;
