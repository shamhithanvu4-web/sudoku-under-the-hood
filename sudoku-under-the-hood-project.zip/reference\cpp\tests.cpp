// Assertion-based tests for the C++ reference implementation.
// The expected counts for the classic puzzle are the ones the TypeScript
// solvers produce, so passing shows both implementations do the same work.
#include <cassert>
#include <iostream>

#include "Solver.hpp"

using namespace sudoku;

static int failures = 0;
#define CHECK(cond)                                                              \
    do {                                                                         \
        if (!(cond)) {                                                           \
            std::cerr << __FILE__ << ':' << __LINE__ << " failed: " #cond "\n"; \
            ++failures;                                                          \
        }                                                                        \
    } while (0)

static std::string code(void (*fn)()) {
    try {
        fn();
    } catch (const BoardError& e) {
        return e.code();
    }
    return "NO_ERROR";
}

static const char* CLASSIC = "53..7....6..195....98....6.8...6...34..8.3..17...2...6.6....28....419..5....8..79";
static const char* CLASSIC_SOLUTION = "534678912672195348198342567859761423426853791713924856961537284287419635345286179";
static const char* DEMO = ".7.95.3..6..3..7.21...42.....1..8.74..6.....1.421.79...1....46..6....5...25..9...";
static const char* EXPERT = "7...3..1...9.....4.....89.74.6.9..2..3.72.....51.....3.....634.....5..8..2.3..1..";
static const char* UNSOLVABLE = ".1.3..2..85..7..43..3864....9.5...17.8.64..2...7..198..3..8..5..2..1....76...5139";
static const char* CONTRADICTORY = "4.....4978.....562.79.62.3....3.1.7..98....5.1.......6.347...2.6...38........6...";

static bool keepsClues(const Grid& puzzle, const Grid& solution) {
    for (int r = 0; r < SIZE; ++r)
        for (int c = 0; c < SIZE; ++c)
            if (puzzle[r][c] && puzzle[r][c] != solution[r][c]) return false;
    return true;
}

int main() {
    const Grid classic = SudokuBoard::parse(CLASSIC);

    // Access, validation and clue protection.
    {
        SudokuBoard b(classic);
        CHECK(b.getCell(0, 0) == 5 && b.getCell(0, 2) == 0);
        CHECK(b.isGiven(0, 0) && !b.isGiven(0, 2));
        CHECK(b.findEmptyCell() == std::optional<Cell>(Cell{0, 2}));
        CHECK(b.findConflict(0, 2, 5)->kind == Unit::Row);
        CHECK(b.findConflict(0, 2, 8)->kind == Unit::Column);
        CHECK(b.findConflict(0, 2, 9)->kind == Unit::Box);
        CHECK(b.isValid(0, 2, 4));
        CHECK((b.getCandidates(0, 2) == std::vector<int>{1, 2, 4}));
    }
    CHECK(code([] { SudokuBoard(SudokuBoard::parse(CLASSIC)).setCell(0, 0, 1); }) == "GIVEN_CELL");
    CHECK(code([] { SudokuBoard(SudokuBoard::parse(CLASSIC)).getCell(9, 0); }) == "INDEX_OUT_OF_RANGE");
    CHECK(code([] { SudokuBoard(SudokuBoard::parse(CLASSIC)).setCell(0, 2, 10); }) == "VALUE_OUT_OF_RANGE");
    CHECK(code([] { SudokuBoard(SudokuBoard::parse(CLASSIC)).placeCandidate(0, 2, 5); }) == "ILLEGAL_PLACEMENT");
    CHECK(code([] {
              SudokuBoard b(SudokuBoard::parse(CLASSIC));
              b.placeCandidate(0, 2, 4);
              b.placeCandidate(0, 3, 6);
              b.undoPlacement(0, 2);
          }) == "UNDO_ORDER");
    CHECK(code([] { SudokuBoard::parse("123"); }) == "MALFORMED");

    // A full board with a mistake is complete but not solved.
    {
        Grid wrong = SudokuBoard::parse(CLASSIC_SOLUTION);
        std::swap(wrong[0][0], wrong[0][1]);
        SudokuBoard b(wrong);
        CHECK(b.isComplete() && !b.isSolved());
        CHECK(SudokuBoard(SudokuBoard::parse(CLASSIC_SOLUTION)).isSolved());
    }

    // Both solvers find correct solutions that keep the clues.
    for (const char* text : {CLASSIC, DEMO, EXPERT}) {
        const Grid p = SudokuBoard::parse(text);
        for (int kind = 0; kind < 2; ++kind) {
            SudokuBoard b(p);
            Stats s;
            bool ok = kind == 0 ? solveBacktracking(b, s) : solveMRV(b, s);
            CHECK(ok && b.isSolved() && keepsClues(p, b.getSnapshot()));
        }
    }

    // Same work as the TypeScript implementation on the classic puzzle.
    {
        SudokuBoard b(classic);
        Stats s;
        solveBacktracking(b, s);
        CHECK(s.recursiveCalls == 4209 && s.candidateAttempts == 37652 && s.rejected == 33444);
        CHECK(s.placements == 4208 && s.backtracks == 4157 && s.maxDepth == 51);
        SudokuBoard m(classic);
        Stats t;
        solveMRV(m, t);
        CHECK(t.recursiveCalls == 52 && t.placements == 51 && t.backtracks == 0 && t.peerScans == 1326);
    }

    // Unsolvable and contradictory puzzles; failed searches restore the board.
    {
        const Grid p = SudokuBoard::parse(UNSOLVABLE);
        CHECK(SudokuBoard(p).validatePuzzle());
        for (int kind = 0; kind < 2; ++kind) {
            SudokuBoard b(p);
            Stats s;
            bool ok = kind == 0 ? solveBacktracking(b, s) : solveMRV(b, s);
            CHECK(!ok && b.getSnapshot() == p && b.placementCount() == 0);
        }
        CHECK(!SudokuBoard(SudokuBoard::parse(CONTRADICTORY)).validatePuzzle());
    }

    // Already solved: one call, no placements.
    {
        SudokuBoard b(SudokuBoard::parse(CLASSIC_SOLUTION));
        Stats s;
        CHECK(solveBacktracking(b, s) && s.recursiveCalls == 1 && s.placements == 0);
    }

    if (failures) {
        std::cerr << failures << " check(s) failed\n";
        return 1;
    }
    std::cout << "All C++ reference tests passed.\n";
    return 0;
}
