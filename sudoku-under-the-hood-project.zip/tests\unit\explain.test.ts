import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { explainEvent, explanationKey } from '../../src/explain/explain';
import { indexSource, extractMember, publicSignatures } from '../../src/explain/sourceIndex';
import { highlight } from '../../src/explain/highlight';
import texts from '../../src/data/explanations.json';
import { runSolver } from '../../src/solver/runSolver';
import type { SolverKind } from '../../src/solver/types';
import { puzzle } from './helpers';

const read = (path: string) => readFileSync(new URL(`../../src/${path}`, import.meta.url), 'utf8');
const SOURCES: Record<SolverKind, string> = {
  backtracking: read('solver/backtrackingSolver.ts'),
  mrv: read('solver/mrvSolver.ts'),
};
const BOARD = indexSource(read('domain/SudokuBoard.ts'));

const traces = (['backtracking', 'mrv'] as SolverKind[]).flatMap((kind) =>
  ['demo', 'lab-unsolvable', 'lab-solved'].map((id) => ({ kind, id, trace: runSolver(puzzle(id), kind, { record: true }).trace! })),
);

describe('explanations', () => {
  test('every recorded event has a complete explanation', () => {
    const used = new Set<string>();
    for (const { kind, trace } of traces) {
      for (let i = 0; i < trace.length; i++) {
        const x = explainEvent(trace, i, kind);
        used.add(x.key);
        for (const text of [x.title, x.concise, x.detailed]) {
          assert.ok(!/\{\w+\}/.test(text), `${x.key}: unfilled placeholder in "${text}"`);
          assert.ok(!/ (at|in) \.|  /.test(text), `${x.key}: missing value in "${text}"`);
        }
        assert.ok(x.call.length > 0);
      }
    }
    // The traces above exercise almost every explanation entry.
    const unused = Object.keys(texts).filter((k) => !used.has(k));
    assert.deepEqual(unused.sort(), ['RECURSION_RETURNED.base-false']);
  });

  test('explanations quote the real conflict', () => {
    const { trace } = traces[0];
    const i = trace.findNext(-1, (e) => e.type === 'VALIDATION_FAILED');
    const e = trace.events[i];
    const text = explainEvent(trace, i, 'backtracking').concise;
    assert.ok(text.includes(`${e.digit} cannot go at r${e.cell!.row + 1}c${e.cell!.col + 1}`));
    assert.ok(text.includes(`r${e.conflict!.at.row + 1}c${e.conflict!.at.col + 1}`));
  });

  test('keys depend on the solver where the code differs', () => {
    const { trace } = traces[0];
    const i = trace.findNext(-1, (e) => e.type === 'CELL_SELECTED');
    assert.equal(explanationKey(trace.events[i], 'backtracking'), 'CELL_SELECTED.backtracking');
    assert.equal(explanationKey(trace.events[i], 'mrv'), 'CELL_SELECTED.mrv');
  });
});

describe('source mapping', () => {
  for (const kind of ['backtracking', 'mrv'] as SolverKind[]) {
    test(`${kind}: every step id in a trace highlights real lines`, () => {
      const view = indexSource(SOURCES[kind]);
      const steps = new Set(traces.filter((t) => t.kind === kind).flatMap((t) => t.trace.events.map((e) => e.step)));
      for (const step of steps) {
        const lines = view.steps.get(step);
        assert.ok(lines && lines.length > 0, `step "${step}" not found in ${kind} source`);
        // One of the highlighted lines is the recorder call that emitted the event.
        assert.ok(lines!.some((n) => view.lines[n - 1].includes(`('${step}'`)), `no recorder call for ${step}`);
      }
      // Marker comments are hidden but line numbers are unchanged.
      assert.equal(view.lines.length, SOURCES[kind].trimEnd().split('\n').length);
      assert.ok(view.lines.every((line) => !line.includes('@step')));
    });
  }

  test('every board operation named in events exists in the ADT source', () => {
    const ops = new Set(traces.flatMap((t) => t.trace.events.map((e) => e.op).filter(Boolean)));
    for (const op of ops) {
      const member = extractMember(BOARD, op!);
      assert.ok(member, `${op} not found`);
      assert.ok(member!.lines.some((l) => l.includes(`${op}(`)));
      assert.ok(member!.lines.at(-1)!.trim() === '}', `${op} excerpt should end at its closing brace`);
    }
  });

  test('public signatures list the ADT interface', () => {
    const names = publicSignatures(BOARD).map((s) => s.split('(')[0]);
    for (const op of ['initialize', 'getCell', 'setCell', 'findEmptyCell', 'isValid', 'getCandidates', 'isComplete', 'isSolved', 'validatePuzzle', 'reset', 'getSnapshot', 'placeCandidate', 'undoPlacement']) {
      assert.ok(names.includes(op), `${op} missing from ${names.join(', ')}`);
    }
    assert.ok(!names.some((n) => n.startsWith('#')));
  });

  test('highlighting keeps every character and line', () => {
    const text = SOURCES.backtracking;
    const lines = highlight(text);
    assert.equal(lines.length, text.split('\n').length);
    assert.equal(lines.map((l) => l.map((t) => t.text).join('')).join('\n'), text);
  });
});
