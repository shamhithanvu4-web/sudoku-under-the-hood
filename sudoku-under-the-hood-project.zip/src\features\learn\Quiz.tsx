import { useState } from 'react';
import { Button } from '../../components/Button';
import styles from './Learn.module.css';

export interface QuizData {
  question: string;
  options: string[];
  answer: number;
  explanation: string;
}

export function Quiz({ id, quiz, onCorrect }: { id: string; quiz: QuizData; onCorrect: () => void }) {
  const [choice, setChoice] = useState<number | null>(null);
  const [checked, setChecked] = useState(false);
  const right = checked && choice === quiz.answer;
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (choice === null) return;
        setChecked(true);
        if (choice === quiz.answer) onCorrect();
      }}
    >
      <fieldset className={styles.quiz}>
        <legend>{quiz.question}</legend>
        {quiz.options.map((o, i) => {
          const state = checked ? (i === quiz.answer ? 'right' : i === choice ? 'wrong' : undefined) : undefined;
          return (
            <label key={i} className={styles.option} data-state={state} htmlFor={`${id}-q${i}`}>
              <input
                id={`${id}-q${i}`}
                type="radio"
                name={`${id}-quiz`}
                checked={choice === i}
                onChange={() => {
                  setChoice(i);
                  setChecked(false);
                }}
              />
              <span>{o}</span>
            </label>
          );
        })}
        <div className={styles.quizActions}>
          <Button type="submit" size="sm" variant="primary" disabled={choice === null}>
            Check answer
          </Button>
          <span role="status" aria-live="polite" style={{ fontSize: 'var(--t-sm)' }}>
            {checked && (right ? <strong style={{ color: 'var(--olive-ink)' }}>Correct. </strong> : <strong style={{ color: 'var(--red-ink)' }}>Not quite. </strong>)}
            {checked && quiz.explanation}
          </span>
        </div>
      </fieldset>
    </form>
  );
}
