import { useState } from 'react';
import { useApp } from '../../app/AppState';
import { Button } from '../../components/Button';
import { PageHeader, pageStyles } from '../../components/PageHeader';
import { Panel } from '../../components/Panel';
import lessonsData from '../../data/lessons.json';
import { CodeExcerpt, type CodeRef } from './CodeExcerpt';
import { DEMOS } from './demos';
import { Quiz, type QuizData } from './Quiz';
import styles from './Learn.module.css';

interface Lesson {
  id: string;
  title: string;
  summary: string;
  definition: string;
  example: string;
  demo: string;
  demoCaption: string;
  code: CodeRef;
  implementation: string;
  quiz: QuizData;
}

export const LESSONS = lessonsData as Lesson[];

export function LearnPage() {
  const { detail, navigate } = useApp();
  const index = Math.max(0, LESSONS.findIndex((l) => l.id === detail));
  const lesson = LESSONS[index];
  const [done, setDone] = useState<Set<string>>(new Set());
  const Demo = DEMOS[lesson.demo];
  const go = (i: number) => navigate('learn', LESSONS[i].id);

  return (
    <div className={pageStyles.wrap}>
      <PageHeader label="Learn mode" title="The ideas behind the solver">
        Ten short lessons. Each one has a definition, a Sudoku example, a live demonstration on the real board code, the actual
        source it refers to, and one question to check your understanding.
      </PageHeader>
      <div className={styles.layout}>
        <nav className={styles.toc} aria-label="Lessons">
          <span className="label">Lessons · {done.size}/{LESSONS.length} checked</span>
          <ol className={styles.tocList}>
            {LESSONS.map((l, i) => (
              <li key={l.id}>
                <button type="button" className={styles.tocItem} aria-current={i === index} onClick={() => go(i)}>
                  <span className={`${styles.tocNo} ${done.has(l.id) ? styles.tocDone : ''}`}>{done.has(l.id) ? '✓' : String(i + 1).padStart(2, '0')}</span>
                  <span>{l.title}</span>
                </button>
              </li>
            ))}
          </ol>
        </nav>

        <article className={styles.article} key={lesson.id} aria-labelledby="lesson-title">
          <header className={styles.lessonHead}>
            <span className="label">
              Lesson {index + 1} of {LESSONS.length}
            </span>
            <h2 id="lesson-title">{lesson.title}</h2>
            <p className={styles.definition}>{lesson.definition}</p>
          </header>

          <div className={styles.example}>
            <span className="label">In Sudoku</span>
            <p>{lesson.example}</p>
          </div>

          <Panel label="Try it">
            <p className={styles.caption}>{lesson.demoCaption}</p>
            {Demo && <Demo />}
          </Panel>

          <Panel label="In the code" flush>
            <CodeExcerpt code={lesson.code} />
            <p className={styles.implNote}>{lesson.implementation}</p>
          </Panel>

          <Panel label="Knowledge check">
            <Quiz key={lesson.id} id={lesson.id} quiz={lesson.quiz} onCorrect={() => setDone((s) => new Set(s).add(lesson.id))} />
          </Panel>

          <div className={styles.pager}>
            <Button icon="stepBack" onClick={() => go(index - 1)} disabled={index === 0}>
              {index > 0 ? LESSONS[index - 1].title : 'Previous'}
            </Button>
            {index < LESSONS.length - 1 ? (
              <Button variant="primary" onClick={() => go(index + 1)}>
                Next: {LESSONS[index + 1].title}
              </Button>
            ) : (
              <Button variant="primary" icon="gauge" onClick={() => navigate('analyze')}>
                Measure it in Analyze
              </Button>
            )}
          </div>
        </article>
      </div>
    </div>
  );
}
