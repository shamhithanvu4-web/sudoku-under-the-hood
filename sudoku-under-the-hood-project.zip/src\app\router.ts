/**
 * Hash routing with plain tokens (#play, #solve, #learn.recursion …),
 * so links to a page or lesson survive being shared.
 */
export type Route = 'home' | 'play' | 'solve' | 'learn' | 'analyze' | 'present';

export const ROUTES: readonly Route[] = ['home', 'play', 'solve', 'learn', 'analyze', 'present'];

export interface Location {
  route: Route;
  /** Optional detail, e.g. a lesson id. */
  detail: string | null;
}

export function parseHash(hash: string): Location {
  const token = hash.replace(/^#/, '');
  const [head, ...rest] = token.split('.');
  const route = (ROUTES as readonly string[]).includes(head) ? (head as Route) : 'home';
  return { route, detail: rest.length ? rest.join('.') : null };
}

export function toHash(route: Route, detail?: string | null): string {
  if (route === 'home') return '';
  return detail ? `${route}.${detail}` : route;
}

export function readLocation(): Location {
  try {
    return parseHash(window.location.hash);
  } catch {
    return { route: 'home', detail: null };
  }
}

export function writeLocation(route: Route, detail?: string | null): void {
  try {
    const hash = toHash(route, detail);
    if (window.location.hash.replace(/^#/, '') !== hash) {
      window.history.pushState(null, '', hash ? `#${hash}` : window.location.pathname + window.location.search);
    }
  } catch {
    /* Navigation still works from in-memory state. */
  }
}
