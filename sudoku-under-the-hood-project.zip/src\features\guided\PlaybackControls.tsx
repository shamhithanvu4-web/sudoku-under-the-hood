import { useState } from 'react';
import { Button } from '../../components/Button';
import type { TraceEventType } from '../../solver/types';
import { JUMP_TARGETS } from './eventStyle';
import { SPEEDS, type Playback } from './usePlayback';
import styles from './Guided.module.css';

const fmt = (n: number) => n.toLocaleString('en-US');

export function PlaybackControls({ p, size = 'md', part = 'all' }: { p: Playback; size?: 'md' | 'lg'; part?: 'all' | 'transport' | 'options' }) {
  const [target, setTarget] = useState<TraceEventType>('BACKTRACK');
  const atEnd = p.index >= p.length - 1;
  const atStart = p.index <= -1;
  const disabled = p.length === 0;
  return (
    <div className={styles.playback}>
      {part !== 'options' && (
      <div className={styles.transport} role="group" aria-label="Playback">
        <Button size={size === 'lg' ? 'lg' : 'md'} iconOnly icon="toStart" label="Back to the start (Home)" onClick={() => p.setIndex(-1)} disabled={disabled || atStart} />
        <Button size={size === 'lg' ? 'lg' : 'md'} iconOnly icon="stepBack" label="Previous step (←)" onClick={() => p.step(-1)} disabled={disabled || atStart} />
        <Button
          className={styles.playButton}
          size={size === 'lg' ? 'lg' : 'md'}
          variant="primary"
          icon={p.playing ? 'pause' : atEnd && p.length ? 'reset' : 'play'}
          onClick={p.toggle}
          disabled={disabled}
          title="Play or pause (Space)"
        >
          {p.playing ? 'Pause' : atEnd && p.length ? 'Replay' : p.index < 0 ? 'Start' : 'Resume'}
        </Button>
        <Button size={size === 'lg' ? 'lg' : 'md'} iconOnly icon="stepForward" label="Next step (→)" onClick={() => p.step(1)} disabled={disabled || atEnd} />
        <Button size={size === 'lg' ? 'lg' : 'md'} iconOnly icon="toEnd" label="Jump to the end (End)" onClick={() => p.setIndex(p.length - 1)} disabled={disabled || atEnd} />
        <span className={styles.counter} aria-live="off">
          {p.index < 0 ? 'start' : `step ${fmt(p.index + 1)}`} / {fmt(p.length)}
        </span>
      </div>
      )}
      {part !== 'transport' && (
        <div className={styles.playOptions}>
          <label className={styles.inlineField} htmlFor="speed">
            Speed
            <select id="speed" className={styles.smallSelect} value={p.speed} onChange={(e) => p.setSpeed(Number(e.target.value))}>
              {SPEEDS.map((s) => (
                <option key={s} value={s}>
                  {fmt(s)} steps/s
                </option>
              ))}
            </select>
          </label>
          <span className={styles.inlineField}>
            <label htmlFor="jump-target">Jump to</label>
            <select id="jump-target" className={styles.smallSelect} value={target} onChange={(e) => setTarget(e.target.value as TraceEventType)}>
              {JUMP_TARGETS.map((t) => (
                <option key={t.type} value={t.type}>
                  {t.label}
                </option>
              ))}
            </select>
            <Button size="sm" iconOnly icon="stepBack" label="Previous match" onClick={() => p.jumpTo(target, -1)} disabled={disabled} />
            <Button size="sm" iconOnly icon="stepForward" label="Next match" onClick={() => p.jumpTo(target, 1)} disabled={disabled} />
          </span>
          <label className={styles.check}>
            <input
              type="checkbox"
              checked={p.pauseOn.has('BACKTRACK')}
              onChange={(e) => {
                const next = new Set(p.pauseOn);
                if (e.target.checked) next.add('BACKTRACK');
                else next.delete('BACKTRACK');
                p.setPauseOn(next);
              }}
            />
            Pause at each backtrack
          </label>
        </div>
      )}
    </div>
  );
}

/**
 * Phone playback bar: previous / play / next and the step count, pinned to the
 * bottom of the screen while the page scrolls (position: sticky).
 */
export function StickyPlayback({ p }: { p: Playback }) {
  const atEnd = p.index >= p.length - 1;
  const atStart = p.index <= -1;
  return (
    <div className={styles.stickyBar} role="group" aria-label="Playback">
      <Button iconOnly icon="stepBack" label="Previous step" onClick={() => p.step(-1)} disabled={atStart} />
      <Button
        className={styles.playButton}
        variant="primary"
        icon={p.playing ? 'pause' : atEnd && p.length ? 'reset' : 'play'}
        onClick={p.toggle}
        disabled={p.length === 0}
      >
        {p.playing ? 'Pause' : atEnd && p.length ? 'Replay' : p.index < 0 ? 'Start' : 'Resume'}
      </Button>
      <Button iconOnly icon="stepForward" label="Next step" onClick={() => p.step(1)} disabled={atEnd} />
      <span className={styles.counter}>
        {p.index < 0 ? 'start' : `step ${fmt(p.index + 1)}`} / {fmt(p.length)}
      </span>
    </div>
  );
}
