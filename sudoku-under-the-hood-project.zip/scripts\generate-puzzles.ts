/**
 * Generates src/data/puzzles.json.
 *
 *   npm run generate:puzzles
 *
 * Every puzzle is built from a random complete grid by removing clues one at
 * a time while (a) the solution stays unique and (b) the difficulty rating
 * stays at or below the target. A puzzle is kept only if its final rating
 * equals the target. The seed makes the output reproducible.
 *
 * Solver statistics are used here only to *choose* puzzles (for example a
 * classroom demo whose first backtrack arrives early). They are not written
 * to the JSON: the app measures everything itself at run time.
 */
import { writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { ratePuzzle, type Difficulty } from '../src/domain/difficulty';
import { countSolutions } from '../src/domain/solutionCounter';
import { SudokuBoard, SIZE, EMPTY, type Grid } from '../src/domain/SudokuBoard';
import { gridToString, toGrid } from '../src/domain/puzzleFormat';
import { runSolver } from '../src/solver/runSolver';

let seed = 20261014;
function random(): number {
  // mulberry32
  seed |= 0;
  seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}
function shuffle<T>(items: T[]): T[] {
  const a = [...items];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function randomSolvedGrid(): number[] {
  const board = new SudokuBoard(toGrid(new Array(81).fill(0)));
  const fill = (): boolean => {
    const cell = board.findEmptyCell();
    if (!cell) return true;
    for (const digit of shuffle([1, 2, 3, 4, 5, 6, 7, 8, 9])) {
      if (!board.isValid(cell.row, cell.col, digit)) continue;
      board.placeCandidate(cell.row, cell.col, digit);
      if (fill()) return true;
      board.undoPlacement(cell.row, cell.col);
    }
    return false;
  };
  fill();
  return board.getSnapshot().flat();
}

const ORDER: Difficulty[] = ['easy', 'medium', 'hard', 'expert'];

/** Friendlier starting boards for the easier levels; hard and expert are carved to minimal. */
const MIN_CLUES: Record<Difficulty, number> = { easy: 34, medium: 28, hard: 17, expert: 17 };

function carve(solution: number[], target: Difficulty, minClues = MIN_CLUES[target]): number[] | null {
  const cells = [...solution];
  for (const i of shuffle([...Array(81).keys()])) {
    if (cells.filter((v) => v !== EMPTY).length <= minClues) break;
    const keep = cells[i];
    cells[i] = EMPTY;
    const grid = toGrid(cells);
    const unique = countSolutions(grid, 2) === 1;
    const ok = unique && ORDER.indexOf(ratePuzzle(grid).difficulty) <= ORDER.indexOf(target);
    if (!ok) cells[i] = keep;
  }
  return ratePuzzle(toGrid(cells)).difficulty === target ? cells : null;
}

interface PuzzleEntry {
  id: string;
  name: string;
  difficulty: Difficulty;
  givens: string;
  description?: string;
}

const plainCalls = (cells: number[], record = false) =>
  runSolver(toGrid(cells), 'backtracking', { record, maxCalls: 2_000_000 });

const puzzles: PuzzleEntry[] = [];
const names: Record<Difficulty, string> = { easy: 'Easy', medium: 'Medium', hard: 'Hard', expert: 'Expert' };
const want: Record<Difficulty, number> = { easy: 3, medium: 3, hard: 3, expert: 3 };

for (const difficulty of ORDER) {
  let made = 0;
  let attempts = 0;
  while (made < want[difficulty] && attempts < 4000) {
    attempts++;
    const solution = randomSolvedGrid();
    const cells = carve(solution, difficulty);
    if (!cells) continue;
    const run = plainCalls(cells);
    if (run.status !== 'solved') continue; // keep only puzzles the plain solver finishes within the limit
    if (difficulty === 'expert' && run.stats.recursiveCalls > 1_500_000) continue;
    made++;
    puzzles.push({
      id: `${difficulty}-${made}`,
      name: `${names[difficulty]} ${made}`,
      difficulty,
      givens: gridToString(toGrid(cells)),
    });
    console.log(difficulty, made, 'clues', cells.filter(Boolean).length, 'plain calls', run.stats.recursiveCalls, 'attempts', attempts);
  }
}

// Classroom demo: a unique puzzle whose plain-backtracking trace is short enough
// to watch, with a genuine backtrack early on.
let demo: PuzzleEntry | null = null;
for (let attempt = 0; attempt < 3000 && !demo; attempt++) {
  const cells = carve(randomSolvedGrid(), 'medium', 30);
  if (!cells) continue;
  const run = plainCalls(cells, true);
  if (run.status !== 'solved' || !run.trace) continue;
  const firstBacktrack = run.trace.backtracks[0] ?? Infinity;
  if (run.trace.length < 1500 || run.trace.length > 12000 || firstBacktrack > 220 || run.trace.backtracks.length < 8) continue;
  demo = {
    id: 'demo',
    name: 'Classroom demo',
    difficulty: ratePuzzle(toGrid(cells)).difficulty,
    givens: gridToString(toGrid(cells)),
    // Step counts are measured by the app at run time (src/features/board/puzzleNote.ts), not stored here.
    description: 'Chosen so the plain solver reaches a genuine backtrack early.',
  };
  console.log('demo', demo.difficulty, 'events', run.trace.length, 'first backtrack', firstBacktrack, 'backtracks', run.trace.backtracks.length);
}
if (!demo) throw new Error('No demo puzzle found');

// Lesson puzzles: nearly finished boards with a tiny, complete search.
const minis: PuzzleEntry[] = [];
for (let attempt = 0; attempt < 20000 && minis.length < 2; attempt++) {
  const solution = randomSolvedGrid();
  const cells = [...solution];
  const holes = 6 + Math.floor(random() * 6);
  for (const i of shuffle([...Array(81).keys()]).slice(0, holes)) cells[i] = EMPTY;
  if (countSolutions(toGrid(cells), 2) !== 1) continue;
  const run = plainCalls(cells, true);
  if (run.status !== 'solved' || !run.trace) continue;
  const bt = run.trace.backtracks.length;
  const wantBacktracks = minis.length === 0 ? [0, 0] : [2, 4];
  if (bt < wantBacktracks[0] || bt > wantBacktracks[1] || run.trace.length > 450) continue;
  if (minis.length === 0 && holes > 7) continue;
  minis.push({
    id: minis.length === 0 ? 'mini-recursion' : 'mini-backtracking',
    name: minis.length === 0 ? 'Recursion lesson board' : 'Backtracking lesson board',
    difficulty: 'easy',
    givens: gridToString(toGrid(cells)),
  });
  console.log('mini', minis.length, 'holes', holes, 'events', run.trace.length, 'backtracks', bt);
}
if (minis.length < 2) throw new Error('Mini puzzles not found');

// Lab puzzles that demonstrate error handling.
const base = puzzles.find((p) => p.id === 'medium-1')!;
const baseCells = base.givens.split('').map((ch) => (ch === '.' ? 0 : Number(ch)));
const baseSolution = runSolver(toGrid(baseCells), 'mrv', { record: false }).solution!.flat();

// Contradictory: copy a clue into an empty cell of the same row.
const contradictory = [...baseCells];
for (let i = 0; i < 81; i++) {
  if (contradictory[i] !== EMPTY) continue;
  const row = Math.floor(i / SIZE);
  const clue = contradictory.slice(row * SIZE, row * SIZE + SIZE).find((v) => v !== EMPTY);
  if (clue) {
    contradictory[i] = clue;
    break;
  }
}

// Unsolvable: add one wrong digit that breaks no rule directly.
let unsolvable: number[] | null = null;
let bestEvents = Infinity;
for (const source of puzzles.filter((p) => p.id === 'medium-2' || p.id === 'easy-1')) {
  const cells = source.givens.split('').map((ch) => (ch === '.' ? 0 : Number(ch)));
  const solution = runSolver(toGrid(cells), 'mrv', { record: false }).solution!.flat();
  const board = new SudokuBoard(toGrid(cells));
  for (let i = 0; i < 81; i++) {
    if (cells[i] !== EMPTY) continue;
    const row = Math.floor(i / SIZE);
    const col = i % SIZE;
    for (const digit of board.getCandidates(row, col)) {
      if (digit === solution[i]) continue;
      const trial = [...cells];
      trial[i] = digit;
      const run = plainCalls(trial, true);
      if (run.status !== 'no-solution' || !run.trace) continue;
      // Prefer a contradiction the plain solver needs real work to find, but can still finish recording.
      if (run.trace.length > 3000 && run.trace.length < 60000 && run.trace.length < bestEvents) {
        bestEvents = run.trace.length;
        unsolvable = trial;
      }
    }
  }
}
if (!unsolvable) throw new Error('No unsolvable puzzle found');
console.log('unsolvable events (plain)', bestEvents);

const lab: PuzzleEntry[] = [
  {
    id: 'lab-unsolvable',
    name: 'Lab: no solution',
    difficulty: 'medium',
    givens: gridToString(toGrid(unsolvable)),
    description: 'Every clue obeys the rules, but one of them is wrong, so no solution exists. Only a complete search can prove it.',
  },
  {
    id: 'lab-contradictory',
    name: 'Lab: contradictory clues',
    difficulty: 'medium',
    givens: gridToString(toGrid(contradictory)),
    description: 'Two clues share a row and a digit. validatePuzzle() rejects it before any search starts.',
  },
  {
    id: 'lab-solved',
    name: 'Lab: already solved',
    difficulty: 'easy',
    givens: gridToString(toGrid(baseSolution)),
    description: 'A complete, correct grid. The solver confirms it in a single call.',
  },
];

const out = {
  note: 'Generated by scripts/generate-puzzles.ts. Difficulty = hardest human technique needed (see src/domain/difficulty.ts). No solver statistics are stored here; the app measures them at run time.',
  demoId: 'demo',
  puzzles: [demo, ...puzzles],
  lessons: minis,
  lab,
};
const target = fileURLToPath(new URL('../src/data/puzzles.json', import.meta.url));
writeFileSync(target, JSON.stringify(out, null, 2) + '\n');
console.log('wrote', target);

export type { Grid };
