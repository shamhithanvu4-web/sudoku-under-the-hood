import { useCallback, useEffect, useMemo, useState, type KeyboardEvent } from 'react';
import { useApp } from '../../app/AppState';
import type { CellMark } from '../board/SudokuGrid';
import type { GameSession, GameView, Message } from './gameSession';

/**
 * Connects a GameSession to the UI: selection, notes mode, messages, keyboard.
 * By default it uses the selected puzzle's shared session; pass `own` for a
 * private board (Present mode starts each visit on a fresh one).
 */
export function usePlayController(own?: GameSession) {
  const app = useApp();
  const [ownVersion, setOwnVersion] = useState(0);
  const session = own ?? app.session;
  const version = own ? ownVersion : app.version;
  const appTouch = app.touch;
  const touch = useCallback(() => (own ? setOwnVersion((v) => v + 1) : appTouch()), [own, appTouch]);
  const puzzle = { id: session.meta.id };
  const [selected, setSelected] = useState<number | null>(null);
  const [notesMode, setNotesMode] = useState(false);
  const [message, setMessage] = useState<Message | null>(null);

  // A different puzzle starts with a clean slate.
  useEffect(() => {
    setSelected(null);
    setMessage(null);
  }, [puzzle.id]);

  const view: GameView = useMemo(() => session.view(), [session, version]);

  const run = useCallback(
    (fn: () => Message | null | void) => {
      const result = fn();
      setMessage(result ?? null);
      touch();
    },
    [touch],
  );

  const input = useCallback(
    (digit: number) => {
      if (selected === null) {
        setMessage({ tone: 'info', text: 'Select a cell first: click it or use the arrow keys.' });
        return;
      }
      run(() => (notesMode ? session.toggleNote(selected, digit) : session.enter(selected, digit)));
    },
    [notesMode, run, selected, session],
  );

  const erase = useCallback(() => {
    if (selected !== null) run(() => session.erase(selected));
  }, [run, selected, session]);

  const undo = useCallback(() => run(() => (session.undo() ? null : { tone: 'info', text: 'Nothing to undo.' })), [run, session]);
  const redo = useCallback(() => run(() => (session.redo() ? null : { tone: 'info', text: 'Nothing to redo.' })), [run, session]);
  const check = useCallback(() => run(() => session.check()), [run, session]);
  const hint = useCallback(() => {
    const result = session.hint(selected);
    if (result.index !== null) setSelected(result.index);
    setMessage(result.message);
    touch();
  }, [selected, session, touch]);
  const reset = useCallback(() => {
    session.reset();
    setMessage({ tone: 'info', text: 'Puzzle reset to its starting clues.' });
    touch();
  }, [session, touch]);

  const onKey = useCallback(
    (e: KeyboardEvent<HTMLDivElement>, _index: number): boolean => {
      if (e.ctrlKey || e.metaKey || e.altKey) return false;
      if (/^[1-9]$/.test(e.key)) {
        input(Number(e.key));
        return true;
      }
      if (e.key === 'Backspace' || e.key === 'Delete' || e.key === '0') {
        erase();
        return true;
      }
      if (e.key === 'n' || e.key === 'N') {
        setNotesMode((v) => !v);
        return true;
      }
      return false;
    },
    [erase, input],
  );

  // Undo / redo shortcuts anywhere on the page (outside text fields).
  useEffect(() => {
    const handler = (e: globalThis.KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target && /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName)) return;
      if (!(e.ctrlKey || e.metaKey)) return;
      const key = e.key.toLowerCase();
      if (key === 'z' && !e.shiftKey) {
        e.preventDefault();
        undo();
      } else if (key === 'y' || (key === 'z' && e.shiftKey)) {
        e.preventDefault();
        redo();
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [redo, undo]);

  const marks = useMemo(() => {
    const map = new Map<number, CellMark>();
    view.values.forEach((v, i) => {
      if (view.status === 'solved' && !view.givens[i]) map.set(i, { tone: 'solved' });
      else if (view.wrong.has(i)) map.set(i, { tone: 'wrong' });
      else if (view.conflicts.has(i)) map.set(i, { tone: 'conflict' });
      else if (view.hinted.has(i) && v !== 0) map.set(i, { tone: 'hint' });
    });
    return map;
  }, [view]);

  return { view, marks, selected, setSelected, notesMode, setNotesMode, message, setMessage, input, erase, undo, redo, check, hint, reset, onKey, session };
}

export type PlayController = ReturnType<typeof usePlayController>;
