import { useId, useRef, useState, type ReactNode } from 'react';
import styles from './Tooltip.module.css';

/**
 * Accessible tooltip: the trigger is focusable and points at the text with
 * aria-describedby; it opens on hover and on keyboard focus, and closes on
 * Escape. Positioned with `fixed` so table scroll containers cannot clip it.
 */
export function Tooltip({ children, tip }: { children: ReactNode; tip: string }) {
  const id = useId();
  const ref = useRef<HTMLSpanElement>(null);
  const [pos, setPos] = useState<{ left: number; top: number } | null>(null);
  const open = () => {
    const r = ref.current?.getBoundingClientRect();
    if (!r) return;
    const width = Math.min(280, window.innerWidth - 32);
    const left = Math.max(16, Math.min(r.right - width, window.innerWidth - width - 16));
    const top = r.bottom + 8 + 120 > window.innerHeight ? Math.max(8, r.top - 8 - 120) : r.bottom + 8;
    setPos({ left, top });
  };
  const close = () => setPos(null);
  return (
    <>
      <span
        ref={ref}
        className={styles.trigger}
        tabIndex={0}
        aria-describedby={id}
        onMouseEnter={open}
        onMouseLeave={close}
        onFocus={open}
        onBlur={close}
        onKeyDown={(e) => e.key === 'Escape' && close()}
      >
        {children}
      </span>
      <span role="tooltip" id={id} className={styles.tip} hidden={!pos} style={pos ? { left: pos.left, top: pos.top } : undefined}>
        {tip}
      </span>
    </>
  );
}
