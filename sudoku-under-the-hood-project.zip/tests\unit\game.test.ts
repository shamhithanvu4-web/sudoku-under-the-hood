import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { GameSession } from '../../src/features/play/gameSession';
import { CLASSIC, CLASSIC_SOLUTION, puzzle } from './helpers';

const meta = { id: 'classic', name: 'Classic', difficulty: 'easy' };
const idx = (row: number, col: number) => row * 9 + col;

describe('manual play', () => {
  test('entering and erasing digits', () => {
    const game = new GameSession(CLASSIC, meta);
    assert.equal(game.enter(idx(0, 2), 4), null);
    assert.equal(game.view().values[idx(0, 2)], 4);
    game.erase(idx(0, 2));
    assert.equal(game.view().values[idx(0, 2)], 0);
  });

  test('clues cannot be changed', () => {
    const game = new GameSession(CLASSIC, meta);
    const message = game.enter(idx(0, 0), 1);
    assert.equal(message?.tone, 'error');
    assert.match(message!.text, /starting clue/);
    assert.equal(game.view().values[idx(0, 0)], 5);
    assert.equal(game.erase(idx(0, 0))?.tone, 'error');
    assert.equal(game.view().canUndo, false);
  });

  test('a rule conflict is reported and highlighted', () => {
    const game = new GameSession(CLASSIC, meta);
    const message = game.enter(idx(0, 2), 5);
    assert.equal(message?.tone, 'warning');
    assert.match(message!.text, /5 already appears in the same row at r1c1/);
    const view = game.view();
    assert.ok(view.conflicts.has(idx(0, 2)) && view.conflicts.has(idx(0, 0)));
    assert.equal(view.status, 'conflicts');
  });

  test('undo and redo restore values and notes', () => {
    const game = new GameSession(CLASSIC, meta);
    game.toggleNote(idx(0, 3), 6);
    game.toggleNote(idx(0, 2), 6);
    game.enter(idx(0, 2), 4);
    game.enter(idx(0, 3), 6);
    assert.equal(game.view().values[idx(0, 3)], 6);
    game.undo();
    assert.equal(game.view().values[idx(0, 3)], 0);
    assert.equal(game.view().notes[idx(0, 3)], 1 << 6);
    game.undo();
    assert.equal(game.view().values[idx(0, 2)], 0);
    assert.equal(game.view().notes[idx(0, 2)], 1 << 6);
    game.redo();
    game.redo();
    assert.equal(game.view().values[idx(0, 2)], 4);
    assert.equal(game.view().values[idx(0, 3)], 6);
    assert.equal(game.view().canRedo, false);
  });

  test('a new move clears the redo history', () => {
    const game = new GameSession(CLASSIC, meta);
    game.enter(idx(0, 2), 4);
    game.undo();
    game.enter(idx(0, 2), 1);
    assert.equal(game.redo(), false);
  });

  test('entering a digit removes it from notes in the same row, column and box', () => {
    const game = new GameSession(CLASSIC, meta);
    game.toggleNote(idx(0, 3), 4);
    game.toggleNote(idx(8, 2), 4);
    game.toggleNote(idx(4, 4), 4);
    game.enter(idx(0, 2), 4);
    const notes = game.view().notes;
    assert.equal(notes[idx(0, 3)], 0);
    assert.equal(notes[idx(8, 2)], 0);
    assert.equal(notes[idx(4, 4)], 1 << 4);
  });

  test('reset restores the starting puzzle', () => {
    const game = new GameSession(CLASSIC, meta);
    game.enter(idx(0, 2), 4);
    game.toggleNote(idx(0, 3), 2);
    game.reset();
    const view = game.view();
    assert.deepEqual(view.values, CLASSIC.flat());
    assert.ok(view.notes.every((n) => n === 0));
    assert.equal(view.canUndo, false);
  });
});

describe('completion detection', () => {
  test('filling the solution is detected as solved', () => {
    const game = new GameSession(CLASSIC, meta);
    let last = null;
    CLASSIC.flat().forEach((v, i) => {
      if (v === 0) last = game.enter(i, CLASSIC_SOLUTION.flat()[i]);
    });
    assert.equal(game.view().status, 'solved');
    assert.equal(last!.tone, 'success');
  });

  test('a full board with mistakes is not reported as solved', () => {
    const game = new GameSession(CLASSIC, meta);
    const solution = CLASSIC_SOLUTION.flat();
    const empties = CLASSIC.flat().map((v, i) => (v === 0 ? i : -1)).filter((i) => i >= 0);
    // Swap the digits of two empty cells in the same row: the board is full but wrong.
    const [a, b] = [idx(0, 2), idx(0, 3)];
    let last = null;
    for (const i of empties) {
      const digit = i === a ? solution[b] : i === b ? solution[a] : solution[i];
      last = game.enter(i, digit);
    }
    const view = game.view();
    assert.equal(view.emptyCount, 0);
    assert.equal(view.status, 'full-with-errors');
    assert.equal(last!.tone, 'warning');
  });
});

describe('check and hint', () => {
  test('check marks entries that differ from the solution', () => {
    const game = new GameSession(CLASSIC, meta);
    game.enter(idx(0, 2), 4); // correct
    game.enter(idx(0, 3), 2); // wrong (solution is 6), but breaks no rule
    const message = game.check();
    assert.equal(message.tone, 'warning');
    assert.deepEqual([...game.view().wrong], [idx(0, 3)]);
  });

  test('hint fills a forced digit and explains why', () => {
    const game = new GameSession(CLASSIC, meta);
    const { message, index } = game.hint(null);
    assert.ok(index !== null);
    assert.equal(game.view().values[index!], CLASSIC_SOLUTION.flat()[index!]);
    assert.match(message.text, /^Hint:/);
    assert.ok(game.view().hinted.has(index!));
  });

  test('hint points out a wrong entry before giving new digits', () => {
    const game = new GameSession(CLASSIC, meta);
    game.enter(idx(0, 3), 2);
    const { message, index } = game.hint(null);
    assert.equal(index, idx(0, 3));
    assert.equal(message.tone, 'warning');
    assert.equal(game.view().values[idx(0, 3)], 2);
  });

  test('puzzles without a solution are reported, not hinted', () => {
    const contradictory = new GameSession(puzzle('lab-contradictory'), meta);
    assert.equal(contradictory.health, 'contradictory');
    assert.equal(contradictory.hint(null).message.tone, 'error');
    const unsolvable = new GameSession(puzzle('lab-unsolvable'), meta);
    assert.equal(unsolvable.health, 'unsolvable');
    assert.match(unsolvable.check().text, /no solution/);
  });
});
