/**
 * Counts solutions of a puzzle, stopping at `limit`.
 *
 * This is a fast, uninstrumented helper used to check that a puzzle has a
 * unique solution (puzzle generation, tests, custom-puzzle checks). It is
 * deliberately written differently from the teaching solvers — bitmasks
 * instead of the board ADT — so tests can use it as an independent check.
 */
import { SIZE, BOX, EMPTY, type Grid } from './SudokuBoard';

const ALL = 0b1111111110; // bits 1..9

function boxOf(row: number, col: number): number {
  return Math.floor(row / BOX) * BOX + Math.floor(col / BOX);
}

function popcount(mask: number): number {
  let n = 0;
  while (mask) {
    mask &= mask - 1;
    n++;
  }
  return n;
}

export function countSolutions(grid: Grid, limit = 2): number {
  const cells = grid.flat();
  const rows = new Array<number>(SIZE).fill(0);
  const cols = new Array<number>(SIZE).fill(0);
  const boxes = new Array<number>(SIZE).fill(0);
  for (let i = 0; i < cells.length; i++) {
    const value = cells[i];
    if (value === EMPTY) continue;
    const row = Math.floor(i / SIZE);
    const col = i % SIZE;
    const bit = 1 << value;
    const b = boxOf(row, col);
    if (rows[row] & bit || cols[col] & bit || boxes[b] & bit) return 0;
    rows[row] |= bit;
    cols[col] |= bit;
    boxes[b] |= bit;
  }

  let found = 0;
  const search = (): boolean => {
    let best = -1;
    let bestMask = 0;
    let bestCount = 10;
    for (let i = 0; i < cells.length; i++) {
      if (cells[i] !== EMPTY) continue;
      const row = Math.floor(i / SIZE);
      const col = i % SIZE;
      const mask = ALL & ~(rows[row] | cols[col] | boxes[boxOf(row, col)]);
      const count = popcount(mask);
      if (count < bestCount) {
        best = i;
        bestMask = mask;
        bestCount = count;
        if (count <= 1) break;
      }
    }
    if (best === -1) {
      found++;
      return found >= limit;
    }
    if (bestCount === 0) return false;
    const row = Math.floor(best / SIZE);
    const col = best % SIZE;
    const b = boxOf(row, col);
    for (let digit = 1; digit <= SIZE; digit++) {
      const bit = 1 << digit;
      if (!(bestMask & bit)) continue;
      cells[best] = digit;
      rows[row] |= bit;
      cols[col] |= bit;
      boxes[b] |= bit;
      const stop = search();
      cells[best] = EMPTY;
      rows[row] &= ~bit;
      cols[col] &= ~bit;
      boxes[b] &= ~bit;
      if (stop) return true;
    }
    return false;
  };
  search();
  return found;
}
