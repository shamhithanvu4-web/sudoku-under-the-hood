import { useEffect, useState } from 'react';
import { Button } from '../../components/Button';
import { cellName } from '../../domain/SudokuBoard';
import type { PlayController } from './usePlayController';
import styles from './PlayControls.module.css';

/** Digit keys 1–9 with remaining counts and per-digit conflict hints for the selected cell. */
export function NumberPad({ c, size = 'md' }: { c: PlayController; size?: 'md' | 'lg' }) {
  const { view, selected, session, notesMode } = c;
  const counts = new Array(10).fill(0);
  view.values.forEach((v) => counts[v]++);
  const selectedEmpty = selected !== null && view.values[selected] === 0 && !view.givens[selected];
  const [explain, setExplain] = useState<string>('');

  return (
    <div>
      <div className={`${styles.pad} ${notesMode ? styles.notesOn : ''}`} role="group" aria-label={notesMode ? 'Pencil notes' : 'Enter a digit'} style={size === 'lg' ? { gap: 10 } : undefined}>
        {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((d) => {
          const conflict = selectedEmpty ? session.conflictFor(selected!, d) : null;
          const why = conflict ? `${d} is already in this ${conflict.kind} (${cellName(conflict.at)})` : '';
          return (
            <button
              key={d}
              type="button"
              className={`${styles.key} ${conflict ? styles.blocked : ''}`}
              onClick={() => c.input(d)}
              onMouseEnter={() => setExplain(why)}
              onFocus={() => setExplain(why)}
              onMouseLeave={() => setExplain('')}
              aria-label={`${notesMode ? 'Note' : 'Enter'} ${d}${why ? `. ${why}` : ''}. ${9 - counts[d]} left`}
              title={why || undefined}
            >
              {d}
              <span className={styles.count} aria-hidden="true">
                {Math.max(0, 9 - counts[d])}
              </span>
            </button>
          );
        })}
      </div>
      <p className={styles.hintLine} aria-hidden="true">
        {explain || (selectedEmpty ? 'Crossed-out digits break a rule in this cell. Small numbers show how many of each digit are left.' : '')}
      </p>
    </div>
  );
}

export function PlayTools({ c, compact }: { c: PlayController; compact?: boolean }) {
  const [confirming, setConfirming] = useState(false);
  useEffect(() => {
    if (!confirming) return;
    const t = window.setTimeout(() => setConfirming(false), 5000);
    return () => window.clearTimeout(t);
  }, [confirming]);
  const size = compact ? 'sm' : 'md';
  return (
    <div className={styles.tools}>
      <Button size={size} icon="pencil" active={c.notesMode} onClick={() => c.setNotesMode(!c.notesMode)} title="Pencil notes (N)">
        Notes {c.notesMode ? 'on' : 'off'}
      </Button>
      <Button size={size} icon="erase" onClick={c.erase} disabled={c.selected === null} title="Erase (Backspace)">
        Erase
      </Button>
      <Button size={size} icon="undo" onClick={c.undo} disabled={!c.view.canUndo} title="Undo (Ctrl+Z)">
        Undo
      </Button>
      <Button size={size} icon="redo" onClick={c.redo} disabled={!c.view.canRedo} title="Redo (Ctrl+Y)">
        Redo
      </Button>
      <Button size={size} icon="bulb" onClick={c.hint}>
        Hint
      </Button>
      <Button size={size} icon="check" onClick={c.check}>
        Check
      </Button>
      {confirming ? (
        <span className={styles.confirm}>
          <Button
            size={size}
            variant="primary"
            onClick={() => {
              c.reset();
              setConfirming(false);
            }}
          >
            Clear all my entries
          </Button>
          <Button size={size} variant="ghost" onClick={() => setConfirming(false)}>
            Keep
          </Button>
        </span>
      ) : (
        <Button size={size} icon="reset" onClick={() => setConfirming(true)}>
          Reset
        </Button>
      )}
    </div>
  );
}

export function KeyboardHelp() {
  return (
    <div className={styles.keys}>
      <span>
        <kbd>←</kbd> <kbd>→</kbd> <kbd>↑</kbd> <kbd>↓</kbd> move
      </span>
      <span>
        <kbd>1</kbd>–<kbd>9</kbd> enter
      </span>
      <span>
        <kbd>⌫</kbd> erase
      </span>
      <span>
        <kbd>N</kbd> notes
      </span>
      <span>
        <kbd>Ctrl</kbd>+<kbd>Z</kbd> / <kbd>Y</kbd> undo, redo
      </span>
    </div>
  );
}
