import { useState } from 'react';
import { useApp } from '../../app/AppState';
import { gridToString, parsePuzzle } from '../../domain/puzzleFormat';
import { SudokuBoard } from '../../domain/SudokuBoard';
import { countSolutions } from '../../domain/solutionCounter';
import { ratePuzzle } from '../../domain/difficulty';
import { DIFFICULTY_LABEL } from '../../app/puzzles';
import { Button } from '../../components/Button';
import { MessageBar } from '../../components/MessageBar';
import type { Message } from './gameSession';
import styles from './PlayPage.module.css';

/** Paste or type 81 cells; the puzzle is checked before it is loaded. */
export function CustomPuzzleForm() {
  const { addCustomPuzzle, puzzles } = useApp();
  const [text, setText] = useState('');
  const [message, setMessage] = useState<Message | null>(null);

  const load = () => {
    const parsed = parsePuzzle(text);
    if (!parsed.ok) {
      setMessage({ tone: 'error', text: parsed.error });
      return;
    }
    const report = new SudokuBoard(parsed.grid).validatePuzzle();
    addCustomPuzzle(parsed.grid);
    if (!report.ok) {
      const c = report.conflicts[0];
      setMessage({ tone: 'error', text: `Loaded, but the starting clues break a rule: ${c.value} appears twice in the same ${c.kind}. It cannot be solved.` });
      return;
    }
    const solutions = countSolutions(parsed.grid, 2);
    if (solutions === 0) {
      setMessage({ tone: 'error', text: 'Loaded. The clues break no rule directly, but the puzzle has no solution. Open Under the Hood to watch the solver prove it.' });
    } else if (solutions > 1) {
      setMessage({ tone: 'warning', text: 'Loaded. This puzzle has more than one solution, so the solver will find one of them and Check compares against that one.' });
    } else {
      const rating = ratePuzzle(parsed.grid).difficulty;
      setMessage({ tone: 'success', text: `Loaded. It has exactly one solution and rates as ${DIFFICULTY_LABEL[rating]}.` });
    }
  };

  return (
    <div className={styles.form}>
      <label htmlFor="custom-puzzle" className={styles.formLabel}>
        81 cells, row by row. Use 1–9 for clues and 0 or . for empty cells. Spaces, line breaks and | are ignored.
      </label>
      <textarea
        id="custom-puzzle"
        className={styles.textarea}
        rows={4}
        spellCheck={false}
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="53..7....6..195....98....6.8...6...34..8.3..17...2...6.6....28....419..5....8..79"
      />
      <div className={styles.formActions}>
        <Button variant="primary" size="sm" onClick={load} disabled={!text.trim()}>
          Check and load
        </Button>
        <Button size="sm" variant="ghost" onClick={() => setText(gridToString(puzzles[1].grid))}>
          Paste an example
        </Button>
      </div>
      {message && <MessageBar message={message} />}
    </div>
  );
}
