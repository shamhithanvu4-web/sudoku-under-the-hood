/**
 * Plain recursive backtracking.
 *
 * solve(board):
 *   pick the first empty cell (row-major order)
 *   if there is none, the board is full: report whether it is solved
 *   for each digit 1..9:
 *     if the digit breaks no rule: place it, then solve the rest recursively
 *     if the recursive call succeeds: done
 *     otherwise: undo the digit (backtrack) and try the next one
 *   if every digit failed: return false so the caller changes its choice
 *
 * The board is only touched through its ADT operations. Each `rec.*` call
 * records what just happened; its first argument is a step id. The code
 * panel finds that id (and matching marker comments on operation lines, hidden
 * in the app) to highlight the lines that produced each event.
 */
import type { SudokuBoard } from '../domain/SudokuBoard';
import type { Frame, Recorder } from './recorder';

/** Solves `board` in place. Returns true with the board solved, or false with the board restored. */
export function solveBacktracking(board: SudokuBoard, rec: Recorder): boolean {
  const solved = solve(board, rec, null); // @step no-solution
  if (!solved) rec.emit('no-solution', null, 'NO_SOLUTION');
  return solved;
}

function solve(board: SudokuBoard, rec: Recorder, parent: Frame | null): boolean { // @step enter
  const frame = rec.enter('enter', parent);

  const cell = board.findEmptyCell(); // @step select
  if (cell === null) {
    const solved = board.isSolved(); // @step base-case base-return
    if (solved) rec.emit('base-case', frame, 'SOLUTION_FOUND');
    return rec.exit('base-return', frame, solved);
  }
  rec.emit('select', frame, 'CELL_SELECTED', { cell });

  for (let digit = 1; digit <= 9; digit++) { // @step try
    rec.emit('try', frame, 'CANDIDATE_TRIED', { cell, digit });

    const conflict = board.findConflict(cell.row, cell.col, digit); // @step reject accept
    if (conflict !== null) {
      rec.emit('reject', frame, 'VALIDATION_FAILED', { cell, digit, conflict });
      continue;
    }
    rec.emit('accept', frame, 'VALIDATION_PASSED', { cell, digit });

    board.placeCandidate(cell.row, cell.col, digit); // @step place
    rec.emit('place', frame, 'VALUE_PLACED', { cell, digit, before: 0, after: digit });

    if (solve(board, rec, frame)) { // @step success
      return rec.exit('success', frame, true);
    }

    board.undoPlacement(cell.row, cell.col); // @step undo
    rec.emit('undo', frame, 'BACKTRACK', { cell, digit, before: digit, after: 0 });
  }

  rec.emit('exhausted', frame, 'DEAD_END', { cell });
  return rec.exit('fail', frame, false);
}
