/**
 * Explanation engine: turns one recorded event into teaching text.
 *
 * The wording lives in data/explanations.json. This module only chooses the
 * right entry for the event and fills in values taken from the event itself
 * (or from the call that emitted it). Nothing here guesses what the solver did.
 */
import texts from '../data/explanations.json';
import { cellName, type Coord } from '../domain/SudokuBoard';
import type { Trace } from '../solver/trace';
import type { SolverKind, TraceEvent } from '../solver/types';

interface Entry {
  title: string;
  concise: string;
  detailed: string;
  concept: string;
  lesson: string;
}

const TEXTS = texts as Record<string, Entry>;

export interface Explanation {
  readonly key: string;
  readonly title: string;
  readonly concise: string;
  readonly detailed: string;
  readonly concept: string;
  readonly lesson: string;
  /** The operation as a call expression with the actual arguments. */
  readonly call: string;
  /** What that operation returned or changed. */
  readonly outcome: string;
  /** The operation's name without arguments (for concise mode, which avoids 0-based indices). */
  readonly name: string;
}

export const arrayIndex = (c: Coord): string => `grid[${c.row}][${c.col}]`;
const coordLiteral = (c: Coord): string => `{ row: ${c.row}, col: ${c.col} }`;
const list = (digits: readonly number[]): string => `[${digits.join(', ')}]`;

/** The explanations.json key used for an event. */
export function explanationKey(e: TraceEvent, kind: SolverKind): string {
  switch (e.type) {
    case 'RECURSION_ENTERED':
      return e.via ? 'RECURSION_ENTERED.child' : 'RECURSION_ENTERED.root';
    case 'CELL_SELECTED':
      return `CELL_SELECTED.${kind}`;
    case 'CANDIDATES_COMPUTED': {
      const n = e.candidates?.length ?? 0;
      return n === 0 ? 'CANDIDATES_COMPUTED.zero' : n === 1 ? 'CANDIDATES_COMPUTED.one' : 'CANDIDATES_COMPUTED.many';
    }
    case 'CANDIDATE_TRIED':
      return `CANDIDATE_TRIED.${kind}`;
    case 'RECURSION_RETURNED':
      if (e.step === 'base-return') return e.result ? 'RECURSION_RETURNED.base-true' : 'RECURSION_RETURNED.base-false';
      if (e.step === 'fail-early-return') return 'RECURSION_RETURNED.fail-early-return';
      return e.result ? 'RECURSION_RETURNED.success' : 'RECURSION_RETURNED.fail';
    case 'DEAD_END':
      return e.step === 'fail-early' ? 'DEAD_END.fail-early' : `DEAD_END.exhausted.${kind}`;
    default:
      return e.type;
  }
}

/** Candidates computed earlier in the same call (MRV), if any. */
function candidatesOfCall(trace: Trace, e: TraceEvent): readonly number[] | undefined {
  if (e.type === 'CANDIDATES_COMPUTED') return e.candidates;
  const i = trace.findPrevious(e.index, (x) => x.callId === e.callId && x.type === 'CANDIDATES_COMPUTED');
  return i >= 0 ? trace.events[i].candidates : undefined;
}

export function explainEvent(trace: Trace, index: number, kind: SolverKind): Explanation {
  const e = trace.events[index];
  const key = explanationKey(e, kind);
  const entry = TEXTS[key];
  if (!entry) throw new Error(`No explanation for ${key}`);

  const call = e.callId >= 0 ? trace.calls[e.callId] : undefined;
  const cell = e.cell ?? call?.cell ?? undefined;
  const candidates = candidatesOfCall(trace, e);
  const values: Record<string, string> = {
    cell: cell ? cellName(cell) : 'the cell',
    index: cell ? arrayIndex(cell) : '',
    row: cell ? String(cell.row) : '',
    col: cell ? String(cell.col) : '',
    digit: e.digit !== undefined ? String(e.digit) : '',
    depth: String(e.depth),
    parentDepth: String(Math.max(0, e.depth - 1)),
    candidates: candidates ? list(candidates) : '',
    count: candidates ? String(candidates.length) : '',
    examined: e.examined !== undefined ? String(e.examined) : '',
    conflictKind: e.conflict?.kind ?? '',
    conflictCell: e.conflict ? cellName(e.conflict.at) : '',
  };
  const fill = (template: string) => template.replace(/\{(\w+)\}/g, (_, name: string) => values[name] ?? '');

  const { call: callText, outcome } = describeOperation(e, kind, cell);
  const name = /^[\w.]+\(/.test(callText) ? callText.replace(/\(.*\)$/, '()') : callText.startsWith('for') ? 'digit loop' : callText;
  return {
    key,
    title: fill(entry.title),
    concise: fill(entry.concise),
    detailed: fill(entry.detailed),
    concept: entry.concept,
    lesson: entry.lesson,
    call: callText,
    outcome,
    name,
  };
}

function describeOperation(e: TraceEvent, kind: SolverKind, cell: Coord | undefined): { call: string; outcome: string } {
  const rc = cell ? `${cell.row}, ${cell.col}` : '';
  switch (e.type) {
    case 'RECURSION_ENTERED':
      return {
        call: e.depth === 0 ? 'solve(board, rec, null)' : 'solve(board, rec, frame)',
        outcome: `new frame #${e.callId} at depth ${e.depth}`,
      };
    case 'CELL_SELECTED':
      return kind === 'mrv'
        ? { call: 'selectMRVCell(board)', outcome: `cell = ${coordLiteral(cell!)}` }
        : { call: 'board.findEmptyCell()', outcome: `returned ${coordLiteral(cell!)}` };
    case 'CANDIDATES_COMPUTED':
      return { call: `board.getCandidates(${rc})`, outcome: `returned [${(e.candidates ?? []).join(', ')}]` };
    case 'CANDIDATE_TRIED':
      return { call: kind === 'mrv' ? 'for (const digit of candidates)' : 'for (let digit = 1; digit <= 9; digit++)', outcome: `digit = ${e.digit}` };
    case 'VALIDATION_FAILED':
      return {
        call: `board.findConflict(${rc}, ${e.digit})`,
        outcome: `returned { kind: '${e.conflict!.kind}', at: ${coordLiteral(e.conflict!.at)} }`,
      };
    case 'VALIDATION_PASSED':
      return { call: `board.findConflict(${rc}, ${e.digit})`, outcome: 'returned null' };
    case 'VALUE_PLACED':
      return { call: `board.placeCandidate(${rc}, ${e.digit})`, outcome: `${arrayIndex(cell!)}: ${e.before} → ${e.after}` };
    case 'BACKTRACK':
      return { call: `board.undoPlacement(${rc})`, outcome: `${arrayIndex(cell!)}: ${e.before} → ${e.after}` };
    case 'RECURSION_RETURNED':
      return { call: `return ${e.result}`, outcome: `frame #${e.callId} removed from the stack` };
    case 'DEAD_END':
      return { call: 'loop finished', outcome: 'no digit worked' };
    case 'SOLUTION_FOUND':
      return { call: 'board.isSolved()', outcome: 'returned true' };
    case 'NO_SOLUTION':
      return { call: kind === 'mrv' ? 'solveMRV(board, rec)' : 'solveBacktracking(board, rec)', outcome: 'returned false' };
    default:
      return { call: '', outcome: '' };
  }
}

/** Short one-line label for trace lists. */
export function eventSummary(e: TraceEvent): string {
  const c = e.cell ? cellName(e.cell) : '';
  switch (e.type) {
    case 'RECURSION_ENTERED':
      return e.via ? `call depth ${e.depth}` : 'first call';
    case 'CELL_SELECTED':
      return `select ${c}`;
    case 'CANDIDATES_COMPUTED':
      return `${c} → ${list(e.candidates ?? [])}`;
    case 'CANDIDATE_TRIED':
      return `try ${e.digit} at ${c}`;
    case 'VALIDATION_FAILED':
      return `${e.digit} clashes (${e.conflict?.kind})`;
    case 'VALIDATION_PASSED':
      return `${e.digit} fits`;
    case 'VALUE_PLACED':
      return `place ${e.digit} at ${c}`;
    case 'RECURSION_RETURNED':
      return `return ${e.result}`;
    case 'BACKTRACK':
      return `undo ${e.digit} at ${c}`;
    case 'DEAD_END':
      return `dead end at ${c}`;
    case 'SOLUTION_FOUND':
      return 'solved';
    case 'NO_SOLUTION':
      return 'no solution';
    default:
      return '';
  }
}
