// Command-line demo: solves a puzzle with both solvers and prints the work done.
//   ./sudoku                      (classroom demo puzzle)
//   ./sudoku "53..7....6..195..." (any 81-character puzzle)
#include <chrono>
#include <iostream>

#include "Solver.hpp"

using namespace sudoku;

static void print(const Grid& g) {
    for (int r = 0; r < SIZE; ++r) {
        if (r % 3 == 0 && r) std::cout << "------+-------+------\n";
        for (int c = 0; c < SIZE; ++c) {
            if (c % 3 == 0 && c) std::cout << "| ";
            std::cout << (g[r][c] ? char('0' + g[r][c]) : '.') << ' ';
        }
        std::cout << '\n';
    }
}

int main(int argc, char** argv) {
    const std::string text = argc > 1 ? argv[1] : ".7.95.3..6..3..7.21...42.....1..8.74..6.....1.421.79...1....46..6....5...25..9...";
    try {
        const Grid puzzle = SudokuBoard::parse(text);
        if (!SudokuBoard(puzzle).validatePuzzle()) {
            std::cout << "The starting clues break a rule; the solver does not start.\n";
            return 2;
        }
        print(puzzle);
        for (int kind = 0; kind < 2; ++kind) {
            SudokuBoard board(puzzle);
            Stats s;
            auto start = std::chrono::steady_clock::now();
            bool solved = kind == 0 ? solveBacktracking(board, s) : solveMRV(board, s);
            double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
            std::cout << '\n' << (kind == 0 ? "Plain backtracking" : "Backtracking + MRV") << ": "
                      << (solved ? "solved" : "no solution") << " in " << ms << " ms\n"
                      << "  recursive calls " << s.recursiveCalls << ", digits tried " << s.candidateAttempts
                      << ", rejected " << s.rejected << ", placements " << s.placements << ", backtracks " << s.backtracks
                      << ", dead ends " << s.deadEnds << ", max depth " << s.maxDepth << ", scans " << s.peerScans << '\n';
            if (solved && kind == 1) print(board.getSnapshot());
        }
    } catch (const BoardError& e) {
        std::cerr << e.code() << ": " << e.what() << '\n';
        return 1;
    }
    return 0;
}
