/**
 * Trace — a recorded solver run that can be replayed in both directions.
 *
 * Going backwards through recursion is not something the solver can do, so
 * the trace stores what is needed to rebuild any moment instead:
 *   - every event that changed a cell records the cell's value before and after;
 *   - every CHECKPOINT_EVERY events, a copy of the 81 cells and the counters.
 * To show event i, start from the nearest checkpoint at or before i and
 * re-apply the recorded changes up to i. That is at most CHECKPOINT_EVERY
 * small steps, whichever direction the user moves.
 */
import { SIZE, type Coord, type Grid } from '../domain/SudokuBoard';
import { countEvent } from './recorder';
import { emptyStats, type Placement, type SolverStats, type TraceEvent } from './types';

export const CHECKPOINT_EVERY = 256;

export type CallStatus = 'active' | 'solved' | 'failed';

/** One recursive call of solve(), reconstructed from its events. */
export interface CallRecord {
  readonly id: number;
  readonly parentId: number | null;
  readonly depth: number;
  /** The placement made by the parent just before this call. Null for the root. */
  readonly via: Placement | null;
  readonly enterIndex: number;
  /** Index of this call's RECURSION_RETURNED event, or null if the trace ends first. */
  exitIndex: number | null;
  result: boolean | null;
  /** The empty cell this call chose to fill (null when it found the board full). */
  cell: Coord | null;
  readonly children: number[];
  /** Largest call id inside this call's subtree; ids are given out in depth-first order. */
  lastDescendant: number;
}

export class Trace {
  readonly events: readonly TraceEvent[];
  readonly initial: Uint8Array;
  readonly calls: readonly CallRecord[];
  /** Indexes of BACKTRACK events, for timeline markers and "next backtrack". */
  readonly backtracks: readonly number[];
  readonly #boards: Uint8Array[] = [];
  readonly #stats: SolverStats[] = [];

  constructor(initial: Grid, events: readonly TraceEvent[]) {
    this.events = events;
    this.initial = Uint8Array.from(initial.flat());

    const calls: CallRecord[] = [];
    const backtracks: number[] = [];
    const open: CallRecord[] = [];
    const board = Uint8Array.from(this.initial);
    const stats = emptyStats();

    for (let i = 0; i < events.length; i++) {
      if (i % CHECKPOINT_EVERY === 0) {
        this.#boards.push(Uint8Array.from(board));
        this.#stats.push({ ...stats });
      }
      const e = events[i];
      applyEvent(board, e);
      countEvent(stats, e.type, e.depth, e.examined);

      if (e.type === 'RECURSION_ENTERED') {
        const record: CallRecord = {
          id: e.callId,
          parentId: open.length ? open[open.length - 1].id : null,
          depth: e.depth,
          via: e.via ?? null,
          enterIndex: i,
          exitIndex: null,
          result: null,
          cell: null,
          children: [],
          lastDescendant: e.callId,
        };
        if (record.parentId !== null) calls[record.parentId].children.push(record.id);
        calls[record.id] = record;
        open.push(record);
        for (const ancestor of open) ancestor.lastDescendant = record.id;
      } else if (e.type === 'CELL_SELECTED') {
        calls[e.callId].cell = e.cell ?? null;
      } else if (e.type === 'RECURSION_RETURNED') {
        const record = open.pop();
        if (record) {
          record.exitIndex = i;
          record.result = e.result ?? null;
        }
      } else if (e.type === 'BACKTRACK') {
        backtracks.push(i);
      }
    }
    this.calls = calls;
    this.backtracks = backtracks;
  }

  get length(): number {
    return this.events.length;
  }

  /** The 81 cell values after event `index` has happened (index -1 = before the first event). */
  boardAt(index: number): Uint8Array {
    if (index < 0) return Uint8Array.from(this.initial);
    const last = Math.min(index, this.events.length - 1);
    const k = Math.floor(last / CHECKPOINT_EVERY);
    const board = Uint8Array.from(this.#boards[k]);
    for (let i = k * CHECKPOINT_EVERY; i <= last; i++) applyEvent(board, this.events[i]);
    return board;
  }

  /** Work counters after event `index`, computed the same way as during the run. */
  statsAt(index: number): SolverStats {
    if (index < 0 || this.events.length === 0) return emptyStats();
    const last = Math.min(index, this.events.length - 1);
    const k = Math.floor(last / CHECKPOINT_EVERY);
    const stats = { ...this.#stats[k] };
    for (let i = k * CHECKPOINT_EVERY; i <= last; i++) {
      const e = this.events[i];
      countEvent(stats, e.type, e.depth, e.examined);
    }
    return stats;
  }

  /** The chain of calls that are open at event `index`, root first. */
  stackAt(index: number): CallRecord[] {
    const event = this.events[index];
    if (!event || event.callId < 0) return [];
    const stack: CallRecord[] = [];
    let call: CallRecord | undefined = this.calls[event.callId];
    while (call) {
      stack.unshift(call);
      call = call.parentId === null ? undefined : this.calls[call.parentId];
    }
    return stack;
  }

  /** A call's status as of event `index`. */
  statusAt(call: CallRecord, index: number): CallStatus {
    if (call.exitIndex === null || call.exitIndex > index) return 'active';
    return call.result ? 'solved' : 'failed';
  }

  /** Children of a call that have started by event `index`. */
  childrenAt(call: CallRecord, index: number): CallRecord[] {
    return call.children.map((id) => this.calls[id]).filter((child) => child.enterIndex <= index);
  }

  /** Number of calls in a call's subtree (including itself). */
  subtreeSize(call: CallRecord): number {
    return call.lastDescendant - call.id + 1;
  }

  /** First index after `from` whose event matches, or -1. */
  findNext(from: number, match: (e: TraceEvent) => boolean): number {
    for (let i = Math.max(0, from + 1); i < this.events.length; i++) if (match(this.events[i])) return i;
    return -1;
  }

  /** Last index before `from` whose event matches, or -1. */
  findPrevious(from: number, match: (e: TraceEvent) => boolean): number {
    for (let i = Math.min(this.events.length, from) - 1; i >= 0; i--) if (match(this.events[i])) return i;
    return -1;
  }

  /** Maximum depth reached in each of `buckets` equal slices of the trace (for the search profile). */
  depthProfile(buckets: number): number[] {
    const n = this.events.length;
    if (n === 0) return [];
    const count = Math.min(buckets, n);
    const out = new Array<number>(count).fill(0);
    for (let i = 0; i < n; i++) {
      const b = Math.min(count - 1, Math.floor((i / n) * count));
      if (this.events[i].depth > out[b]) out[b] = this.events[i].depth;
    }
    return out;
  }
}

function applyEvent(board: Uint8Array, e: TraceEvent): void {
  if ((e.type === 'VALUE_PLACED' || e.type === 'BACKTRACK') && e.cell && e.after !== undefined) {
    board[e.cell.row * SIZE + e.cell.col] = e.after;
  }
}
