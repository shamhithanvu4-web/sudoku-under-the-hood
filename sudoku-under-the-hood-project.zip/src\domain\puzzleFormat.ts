/**
 * Converting puzzles between text and grids.
 *
 * Text format: 81 characters read row by row. Digits 1–9 are clues;
 * 0 or '.' is an empty cell. Whitespace and the separators | - + are ignored,
 * so a hand-typed layout like "53..7.... |6..195..." also works.
 */
import { SIZE, EMPTY, type Grid } from './SudokuBoard';

export type ParseResult =
  | { readonly ok: true; readonly grid: Grid }
  | { readonly ok: false; readonly error: string };

const IGNORED = /[\s|+\-]/g;

export function parsePuzzle(text: string): ParseResult {
  const compact = text.replace(IGNORED, '');
  const bad = compact.match(/[^0-9.]/);
  if (bad) {
    return { ok: false, error: `Unexpected character "${bad[0]}". Use digits 1–9 for clues and 0 or . for empty cells.` };
  }
  if (compact.length !== SIZE * SIZE) {
    return {
      ok: false,
      error: `A puzzle needs exactly 81 cells; this one has ${compact.length}.`,
    };
  }
  const grid: number[][] = [];
  for (let row = 0; row < SIZE; row++) {
    const values: number[] = [];
    for (let col = 0; col < SIZE; col++) {
      const ch = compact[row * SIZE + col];
      values.push(ch === '.' ? EMPTY : Number(ch));
    }
    grid.push(values);
  }
  return { ok: true, grid };
}

/** Parses a string that is known to be well formed (bundled puzzle data). */
export function gridFromString(text: string): Grid {
  const result = parsePuzzle(text);
  if (!result.ok) throw new Error(result.error);
  return result.grid;
}

export function gridToString(grid: Grid, empty = '.'): string {
  return grid.map((row) => row.map((value) => (value === EMPTY ? empty : String(value))).join('')).join('');
}

/** Flattens a grid into 81 values in row-major order: index = row * 9 + col. */
export function flatten(grid: Grid): number[] {
  return grid.flat();
}

export function toGrid(cells: ArrayLike<number>): Grid {
  const grid: number[][] = [];
  for (let row = 0; row < SIZE; row++) {
    grid.push(Array.from({ length: SIZE }, (_, col) => cells[row * SIZE + col]));
  }
  return grid;
}
