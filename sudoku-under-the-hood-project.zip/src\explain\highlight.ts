/**
 * A small TypeScript syntax highlighter for the code panel.
 * Produces tokens per line so the panel can mark active lines.
 */

export type TokenKind = 'plain' | 'keyword' | 'string' | 'comment' | 'number' | 'type' | 'fn' | 'punct';

export interface Token {
  readonly kind: TokenKind;
  readonly text: string;
}

const KEYWORDS = new Set([
  'const', 'let', 'var', 'function', 'return', 'if', 'else', 'for', 'of', 'in', 'while', 'continue', 'break',
  'export', 'import', 'from', 'type', 'interface', 'class', 'new', 'this', 'throw', 'true', 'false', 'null',
  'undefined', 'readonly', 'static', 'extends', 'implements', 'void', 'number', 'boolean', 'string', 'switch',
  'case', 'default', 'typeof', 'instanceof', 'as', 'private', 'public',
]);

const PATTERN =
  /(\/\*[\s\S]*?\*\/|\/\/[^\n]*)|('(?:[^'\\\n]|\\.)*'|"(?:[^"\\\n]|\\.)*"|`(?:[^`\\]|\\.)*`)|(\b\d[\d_]*(?:\.\d+)?\b)|(#?[A-Za-z_$][\w$]*)|(\s+)|([^\sA-Za-z_$\d'"`/#]+|[\s\S])/g;

export function highlight(source: string): Token[][] {
  const lines: Token[][] = [[]];
  const push = (kind: TokenKind, text: string) => {
    const parts = text.split('\n');
    parts.forEach((part, i) => {
      if (i > 0) lines.push([]);
      if (part) lines[lines.length - 1].push({ kind, text: part });
    });
  };
  for (const m of source.matchAll(PATTERN)) {
    const [text, comment, str, num, ident, space] = m;
    if (comment) push('comment', text);
    else if (str) push('string', text);
    else if (num) push('number', text);
    else if (ident) {
      const next = source[(m.index ?? 0) + text.length];
      if (KEYWORDS.has(ident)) push('keyword', text);
      else if (/^[A-Z]/.test(ident)) push('type', text);
      else if (next === '(') push('fn', text);
      else push('plain', text);
    } else if (space) push('plain', text);
    else push('punct', text);
  }
  return lines;
}
