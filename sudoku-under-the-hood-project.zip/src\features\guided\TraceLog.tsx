import { Panel } from '../../components/Panel';
import { eventSummary } from '../../explain/explain';
import type { Trace } from '../../solver/trace';
import { CATEGORY } from './eventStyle';
import styles from './Guided.module.css';

const BEFORE = 14;
const AFTER = 4;

/** Recorded events around the current step. Upcoming events are greyed out. */
export function TraceLog({ trace, index, onSeek, collapsible, defaultOpen = true }: { trace: Trace; index: number; onSeek: (i: number) => void; collapsible?: boolean; defaultOpen?: boolean }) {
  const from = Math.max(0, index - BEFORE);
  const to = Math.min(trace.length - 1, Math.max(index, 0) + AFTER);
  const rows = [];
  for (let i = from; i <= to; i++) rows.push(trace.events[i]);
  return (
    <Panel label="Trace" meta={`${trace.length.toLocaleString('en-US')} recorded events`} flush collapsible={collapsible} defaultOpen={defaultOpen}>
      <ol className={styles.log}>
        {rows.map((e) => (
          <li key={e.index}>
            <button type="button" className={styles.logRow} aria-current={e.index === index ? 'step' : undefined} data-future={e.index > index} onClick={() => onSeek(e.index)}>
              <span className={styles.logIndex}>{e.index + 1}</span>
              <span className={styles.logBody}>
                <span className={styles.logIndent} style={{ width: `${Math.min(e.depth, 24) * 3}px` }} />
                <span className={styles.dot} data-cat={CATEGORY[e.type]} />
                {eventSummary(e)}
              </span>
            </button>
          </li>
        ))}
      </ol>
    </Panel>
  );
}
