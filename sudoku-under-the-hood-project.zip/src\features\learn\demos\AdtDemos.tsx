import { useMemo, useState } from 'react';
import { BUNDLED, DEMO_ID } from '../../../app/puzzles';
import { Button } from '../../../components/Button';
import { Segmented } from '../../../components/Segmented';
import { BoardError, SudokuBoard, cellName } from '../../../domain/SudokuBoard';
import { SudokuGrid } from '../../board/SudokuGrid';
import styles from '../Learn.module.css';

export const demoGrid = () => BUNDLED.find((p) => p.id === DEMO_ID)!.grid;

interface Line {
  call: string;
  result: string;
  ok: boolean;
}

function run(call: string, fn: () => unknown): Line {
  try {
    const value = fn();
    return { call, result: format(value), ok: true };
  } catch (error) {
    if (error instanceof BoardError) return { call, result: `throws BoardError ${error.code}: ${error.message}`, ok: false };
    return { call, result: `throws ${String(error)}`, ok: false };
  }
}

function format(value: unknown): string {
  if (value === undefined) return 'undefined';
  if (Array.isArray(value)) return `[${value.join(', ')}]`;
  if (value && typeof value === 'object') return JSON.stringify(value).replace(/"(\w+)":/g, '$1: ').replace(/,/g, ', ');
  return String(value);
}

function Console({ lines }: { lines: Line[] }) {
  return (
    <div className={styles.console} aria-live="polite">
      {lines.length === 0 && <div className={styles.prompt}>Results appear here.</div>}
      {lines.map((l, i) => (
        <div key={i}>
          <span className={styles.prompt}>&gt; </span>
          {l.call}
          {'\n'}
          <span className={l.ok ? styles.ok : styles.err}>{l.result}</span>
        </div>
      ))}
    </div>
  );
}

/** Lesson 1: call the public operations on a real board. */
export function AdtDemo() {
  const board = useMemo(() => new SudokuBoard(demoGrid()), []);
  const [sel, setSel] = useState(0);
  const [digit, setDigit] = useState(2);
  const [lines, setLines] = useState<Line[]>([]);
  const r = Math.floor(sel / 9);
  const c = sel % 9;
  const add = (line: Line) => setLines((ls) => [line, ...ls].slice(0, 8));
  const snapshot = board.getSnapshot().flat();
  return (
    <div className={styles.demo}>
      <div className={styles.demoBoard}>
        <SudokuGrid label="Demo board" values={snapshot} givens={snapshot.map((v) => v !== 0)} selected={sel} onSelect={setSel} />
      </div>
      <div className={styles.demoSide}>
        <div className={styles.controls}>
          <span className="label">Selected {cellName({ row: r, col: c })}</span>
          <label className="label" htmlFor="adt-digit">
            digit
          </label>
          <select id="adt-digit" value={digit} onChange={(e) => setDigit(Number(e.target.value))}>
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((d) => (
              <option key={d}>{d}</option>
            ))}
          </select>
        </div>
        <div className={styles.controls}>
          <Button size="sm" onClick={() => add(run(`board.getCell(${r}, ${c})`, () => board.getCell(r, c)))}>getCell</Button>
          <Button size="sm" onClick={() => add(run(`board.isGiven(${r}, ${c})`, () => board.isGiven(r, c)))}>isGiven</Button>
          <Button size="sm" onClick={() => add(run(`board.isValid(${r}, ${c}, ${digit})`, () => board.isValid(r, c, digit)))}>isValid</Button>
          <Button size="sm" onClick={() => add(run(`board.getCandidates(${r}, ${c})`, () => board.getCandidates(r, c)))}>getCandidates</Button>
          <Button size="sm" onClick={() => add(run('board.findEmptyCell()', () => board.findEmptyCell()))}>findEmptyCell</Button>
          <Button size="sm" onClick={() => add(run('board.countEmpty()', () => board.countEmpty()))}>countEmpty</Button>
          <Button size="sm" onClick={() => add(run('board.isSolved()', () => board.isSolved()))}>isSolved</Button>
        </div>
        <div className={styles.controls}>
          <span className="label">Try to reach the data</span>
          <Button size="sm" variant="ghost" onClick={() => add(run('Object.keys(board)', () => Object.keys(board)))}>Object.keys</Button>
          <Button size="sm" variant="ghost" onClick={() => add(run('(board as any).grid', () => (board as unknown as Record<string, unknown>).grid))}>board.grid</Button>
          <Button size="sm" variant="ghost" onClick={() => add(run('JSON.stringify(board)', () => JSON.stringify(board)))}>JSON.stringify</Button>
        </div>
        <Console lines={lines} />
      </div>
    </div>
  );
}

type Rep = 'array2d' | 'flat' | 'bitmask';

const bin = (mask: number) => mask.toString(2).padStart(10, '0').slice(0, 9);

/** Lesson 2: the same questions answered by three storage layouts. */
export function RepresentationsDemo() {
  const grid = demoGrid();
  const cells = grid.flat();
  const [sel, setSel] = useState(2);
  const [rep, setRep] = useState<Rep>('array2d');
  const r = Math.floor(sel / 9);
  const c = sel % 9;
  const b = Math.floor(r / 3) * 3 + Math.floor(c / 3);
  const maskOf = (values: number[]) => values.reduce((m, v) => (v ? m | (1 << v) : m), 0);
  const rowMask = maskOf(grid[r] as number[]);
  const colMask = maskOf(grid.map((row) => row[c]));
  const boxCells: number[] = [];
  for (let y = r - (r % 3); y < r - (r % 3) + 3; y++) for (let x = c - (c % 3); x < c - (c % 3) + 3; x++) boxCells.push(grid[y][x]);
  const boxMask = maskOf(boxCells);
  const used = rowMask | colMask | boxMask;
  const candidates = [1, 2, 3, 4, 5, 6, 7, 8, 9].filter((d) => !(used & (1 << d)));
  return (
    <div className={styles.demo}>
      <div className={styles.demoBoard}>
        <SudokuGrid label="Demo board" values={cells} givens={cells.map((v) => v !== 0)} selected={sel} onSelect={setSel} showPeers />
      </div>
      <div className={styles.demoSide}>
        <Segmented
          size="sm"
          label="Representation"
          value={rep}
          onChange={setRep}
          options={[
            { value: 'array2d', label: '9×9 array' },
            { value: 'flat', label: 'Flat array' },
            { value: 'bitmask', label: 'Bitmasks' },
          ]}
        />
        {rep === 'array2d' && (
          <dl className={styles.facts}>
            <dt>declaration</dt>
            <dd>grid: number[][]  // 9 arrays of 9</dd>
            <dt>getCell({r}, {c})</dt>
            <dd>grid[{r}][{c}] = {grid[r][c]}</dd>
            <dt>grid[{r}]</dt>
            <dd>[{grid[r].join(', ')}]</dd>
            <dt>memory</dt>
            <dd>81 numbers; one lookup per cell</dd>
          </dl>
        )}
        {rep === 'flat' && (
          <dl className={styles.facts}>
            <dt>declaration</dt>
            <dd>cells: number[]  // length 81</dd>
            <dt>getCell({r}, {c})</dt>
            <dd>
              cells[{r} * 9 + {c}] = cells[{r * 9 + c}] = {cells[r * 9 + c]}
            </dd>
            <dt>row {r}</dt>
            <dd>
              cells.slice({r * 9}, {r * 9 + 9}) = [{cells.slice(r * 9, r * 9 + 9).join(', ')}]
            </dd>
            <dt>memory</dt>
            <dd>81 numbers; index arithmetic instead of nested arrays</dd>
          </dl>
        )}
        {rep === 'bitmask' && (
          <dl className={styles.facts}>
            <dt>declaration</dt>
            <dd>rows, cols, boxes: number[9]  // bit d set = digit d used</dd>
            <dt>rows[{r}]</dt>
            <dd>0b{bin(rowMask)} (bits 9…1)</dd>
            <dt>cols[{c}]</dt>
            <dd>0b{bin(colMask)}</dd>
            <dt>boxes[{b}]</dt>
            <dd>0b{bin(boxMask)}</dd>
            <dt>used</dt>
            <dd>rows | cols | boxes = 0b{bin(used)}</dd>
            <dt>candidates</dt>
            <dd>{grid[r][c] ? 'cell is filled' : `[${candidates.join(', ')}]: one OR and nine bit tests`}</dd>
          </dl>
        )}
        <p className={styles.caption} style={{ margin: 0 }}>
          The question is the same in every layout: what is in {cellName({ row: r, col: c })}, and which digits could go there? Only the
          code inside the board class would change.
        </p>
      </div>
    </div>
  );
}

const ATTEMPTS: { label: string; code: string; run: (b: SudokuBoard) => unknown }[] = [
  { label: 'Change a clue as the player', code: 'board.setCell(0, 1, 9)', run: (b) => b.setCell(0, 1, 9) },
  { label: 'Write a value that is not a digit', code: 'board.setCell(0, 0, 10)', run: (b) => b.setCell(0, 0, 10) },
  { label: 'Read outside the board', code: 'board.getCell(9, 0)', run: (b) => b.getCell(9, 0) },
  { label: 'Solver places an illegal digit', code: 'board.placeCandidate(0, 0, 7)', run: (b) => b.placeCandidate(0, 0, 7) },
  {
    label: 'Solver undoes out of order',
    code: 'board.placeCandidate(0, 0, 2)\nboard.placeCandidate(0, 2, 4)\nboard.undoPlacement(0, 0)',
    run: (b) => {
      b.placeCandidate(0, 0, 2);
      b.placeCandidate(0, 2, 4);
      b.undoPlacement(0, 0);
    },
  },
  { label: 'A normal player move (allowed)', code: 'board.setCell(0, 0, 8)', run: (b) => b.setCell(0, 0, 8) },
];

/** Lesson 3: the board refuses unsafe changes. */
export function EncapsulationDemo() {
  const [results, setResults] = useState<Record<number, Line>>({});
  return (
    <div>
      {ATTEMPTS.map((a, i) => (
        <div key={i} className={styles.attempt}>
          <div>
            <div style={{ fontSize: 'var(--t-sm)', fontWeight: 600 }}>{a.label}</div>
            <code style={{ whiteSpace: 'pre-wrap' }}>{a.code}</code>
          </div>
          <Button size="sm" onClick={() => setResults((r) => ({ ...r, [i]: run(a.code, () => a.run(new SudokuBoard(demoGrid()))) }))}>
            Run
          </Button>
          {results[i] && (
            <div className={`${styles.attemptResult} ${results[i].ok ? styles.ok : styles.err}`} aria-live="polite">
              {results[i].ok ? `returned ${results[i].result}` : results[i].result}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
