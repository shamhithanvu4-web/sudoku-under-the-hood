import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import type { Grid } from '../domain/SudokuBoard';
import { GameSession } from '../features/play/gameSession';
import { BUNDLED, DEMO_ID, type PuzzleDef } from './puzzles';
import { readLocation, writeLocation, type Route } from './router';

interface AppState {
  route: Route;
  detail: string | null;
  navigate: (route: Route, detail?: string | null) => void;

  puzzles: readonly PuzzleDef[];
  puzzle: PuzzleDef;
  selectPuzzle: (id: string) => void;
  addCustomPuzzle: (grid: Grid) => PuzzleDef;

  /** The Play-mode session for the selected puzzle (kept per puzzle). */
  session: GameSession;
  /** Call after changing the session so views re-render. */
  touch: () => void;
  version: number;
  restartSession: () => void;
}

const Ctx = createContext<AppState | null>(null);

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [location, setLocation] = useState(readLocation);
  const [custom, setCustom] = useState<PuzzleDef[]>([]);
  const [puzzleId, setPuzzleId] = useState(DEMO_ID);
  const [version, setVersion] = useState(0);
  const sessions = useRef(new Map<string, GameSession>());

  useEffect(() => {
    const sync = () => setLocation(readLocation());
    window.addEventListener('popstate', sync);
    window.addEventListener('hashchange', sync);
    return () => {
      window.removeEventListener('popstate', sync);
      window.removeEventListener('hashchange', sync);
    };
  }, []);

  const navigate = useCallback((route: Route, detail: string | null = null) => {
    writeLocation(route, detail);
    setLocation({ route, detail });
    window.scrollTo({ top: 0 });
  }, []);

  const puzzles = useMemo(() => [...BUNDLED, ...custom], [custom]);
  const puzzle = puzzles.find((p) => p.id === puzzleId) ?? puzzles[0];

  let session = sessions.current.get(puzzle.id);
  if (!session) {
    session = new GameSession(puzzle.grid, { id: puzzle.id, name: puzzle.name, difficulty: puzzle.difficulty });
    sessions.current.set(puzzle.id, session);
  }

  const addCustomPuzzle = useCallback(
    (grid: Grid): PuzzleDef => {
      const def: PuzzleDef = {
        id: `custom-${custom.length + 1}`,
        name: `Custom ${custom.length + 1}`,
        difficulty: 'custom',
        grid,
        group: 'custom',
      };
      setCustom((list) => [...list, def]);
      setPuzzleId(def.id);
      return def;
    },
    [custom.length],
  );

  const restartSession = useCallback(() => {
    sessions.current.get(puzzle.id)?.reset();
    setVersion((v) => v + 1);
  }, [puzzle.id]);

  const value: AppState = {
    route: location.route,
    detail: location.detail,
    navigate,
    puzzles,
    puzzle,
    selectPuzzle: setPuzzleId,
    addCustomPuzzle,
    session,
    touch: () => setVersion((v) => v + 1),
    version,
    restartSession,
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp(): AppState {
  const state = useContext(Ctx);
  if (!state) throw new Error('useApp must be used inside AppStateProvider');
  return state;
}
