// SudokuBoard — academic reference implementation of the board ADT in C++17.
//
// This mirrors src/domain/SudokuBoard.ts operation for operation. The web app
// runs the TypeScript version; this file exists for courses that expect C++.
// It is compiled and tested on its own (see Makefile), not used by the app.
//
// Interface (the ADT) vs implementation (the data structure):
//   - Callers use only the public member functions below.
//   - The cells live in a private 9×9 two-dimensional array, grid_[row][col],
//     with 0 meaning "empty".
#pragma once

#include <array>
#include <optional>
#include <stdexcept>
#include <string>
#include <vector>

namespace sudoku {

constexpr int SIZE = 9;
constexpr int BOX = 3;
constexpr int EMPTY = 0;

struct Cell {
    int row;
    int col;
    bool operator==(const Cell& other) const { return row == other.row && col == other.col; }
};

enum class Unit { Row, Column, Box };

struct Conflict {
    Unit kind;
    Cell at;
    int value;
};

using Grid = std::array<std::array<int, SIZE>, SIZE>;

class BoardError : public std::runtime_error {
public:
    BoardError(std::string code, const std::string& message)
        : std::runtime_error(message), code_(std::move(code)) {}
    const std::string& code() const { return code_; }

private:
    std::string code_;
};

class SudokuBoard {
public:
    explicit SudokuBoard(const Grid& puzzle) { initialize(puzzle); }

    // Parses 81 characters: digits 1-9 are clues, '0' or '.' is empty.
    static Grid parse(const std::string& text);

    // initialize(puzzle): every non-zero value becomes an immutable clue.
    void initialize(const Grid& puzzle);

    // getCell(row, col): the value at a cell, 0 when empty.
    int getCell(int row, int col) const;

    // isGiven(row, col): true for a starting clue.
    bool isGiven(int row, int col) const;

    // setCell(row, col, value): PLAYER operation; refuses clues; allows rule conflicts.
    int setCell(int row, int col, int value);

    // findEmptyCell(): first empty cell in row-major order, or nothing when full.
    std::optional<Cell> findEmptyCell() const;

    // findConflict(row, col, digit): first clash in the row, column or box.
    std::optional<Conflict> findConflict(int row, int col, int digit) const;

    // isValid(row, col, digit): no clash.
    bool isValid(int row, int col, int digit) const { return !findConflict(row, col, digit).has_value(); }

    // getCandidates(row, col): digits that fit an empty cell, ascending; empty for a filled cell.
    std::vector<int> getCandidates(int row, int col) const;

    // isComplete(): no empty cells (says nothing about correctness).
    bool isComplete() const { return !findEmptyCell().has_value(); }

    // isSolved(): complete and every row, column and box holds 1-9 exactly once.
    bool isSolved() const;

    // validatePuzzle(): true when the starting clues break no rule.
    bool validatePuzzle() const;

    // reset(): back to the starting clues.
    void reset();

    // getSnapshot(): a copy of the current values; changing it cannot change the board.
    Grid getSnapshot() const { return grid_; }

    // placeCandidate / undoPlacement: SOLVER operations, last-in first-out.
    void placeCandidate(int row, int col, int digit);
    void undoPlacement(int row, int col);
    std::size_t placementCount() const { return trail_.size(); }

private:
    Grid grid_{};
    std::array<std::array<bool, SIZE>, SIZE> givens_{};
    Grid original_{};
    std::vector<Cell> trail_;

    static void checkIndex(int row, int col);
    static void checkValue(int value);
    static void checkDigit(int digit);
    static bool hasDuplicates(const Grid& grid);
};

std::string cellName(Cell cell);

}  // namespace sudoku
