#include "SudokuBoard.hpp"

#include <set>

namespace sudoku {

std::string cellName(Cell cell) {
    return "r" + std::to_string(cell.row + 1) + "c" + std::to_string(cell.col + 1);
}

Grid SudokuBoard::parse(const std::string& text) {
    std::string compact;
    for (char ch : text) {
        if (ch == ' ' || ch == '\n' || ch == '\r' || ch == '\t' || ch == '|' || ch == '-' || ch == '+') continue;
        if (ch != '.' && (ch < '0' || ch > '9')) throw BoardError("MALFORMED", std::string("Unexpected character '") + ch + "'.");
        compact.push_back(ch);
    }
    if (compact.size() != SIZE * SIZE) throw BoardError("MALFORMED", "A puzzle needs exactly 81 cells.");
    Grid grid{};
    for (int i = 0; i < SIZE * SIZE; ++i) grid[i / SIZE][i % SIZE] = compact[i] == '.' ? EMPTY : compact[i] - '0';
    return grid;
}

void SudokuBoard::initialize(const Grid& puzzle) {
    for (const auto& row : puzzle)
        for (int v : row)
            if (v < EMPTY || v > SIZE) throw BoardError("MALFORMED", "Values must be 0-9.");
    original_ = puzzle;
    grid_ = puzzle;
    for (int r = 0; r < SIZE; ++r)
        for (int c = 0; c < SIZE; ++c) givens_[r][c] = puzzle[r][c] != EMPTY;
    trail_.clear();
}

int SudokuBoard::getCell(int row, int col) const {
    checkIndex(row, col);
    return grid_[row][col];
}

bool SudokuBoard::isGiven(int row, int col) const {
    checkIndex(row, col);
    return givens_[row][col];
}

int SudokuBoard::setCell(int row, int col, int value) {
    checkIndex(row, col);
    checkValue(value);
    if (givens_[row][col]) throw BoardError("GIVEN_CELL", cellName({row, col}) + " is a starting clue and cannot be changed.");
    int previous = grid_[row][col];
    grid_[row][col] = value;
    return previous;
}

std::optional<Cell> SudokuBoard::findEmptyCell() const {
    for (int row = 0; row < SIZE; ++row)
        for (int col = 0; col < SIZE; ++col)
            if (grid_[row][col] == EMPTY) return Cell{row, col};
    return std::nullopt;
}

std::optional<Conflict> SudokuBoard::findConflict(int row, int col, int digit) const {
    checkIndex(row, col);
    checkDigit(digit);
    for (int c = 0; c < SIZE; ++c)
        if (c != col && grid_[row][c] == digit) return Conflict{Unit::Row, {row, c}, digit};
    for (int r = 0; r < SIZE; ++r)
        if (r != row && grid_[r][col] == digit) return Conflict{Unit::Column, {r, col}, digit};
    int top = row - row % BOX, left = col - col % BOX;
    for (int r = top; r < top + BOX; ++r)
        for (int c = left; c < left + BOX; ++c)
            if ((r != row || c != col) && grid_[r][c] == digit) return Conflict{Unit::Box, {r, c}, digit};
    return std::nullopt;
}

std::vector<int> SudokuBoard::getCandidates(int row, int col) const {
    checkIndex(row, col);
    if (grid_[row][col] != EMPTY) return {};
    std::array<bool, SIZE + 1> used{};
    for (int i = 0; i < SIZE; ++i) {
        used[grid_[row][i]] = true;
        used[grid_[i][col]] = true;
    }
    int top = row - row % BOX, left = col - col % BOX;
    for (int r = top; r < top + BOX; ++r)
        for (int c = left; c < left + BOX; ++c) used[grid_[r][c]] = true;
    std::vector<int> candidates;
    for (int d = 1; d <= SIZE; ++d)
        if (!used[d]) candidates.push_back(d);
    return candidates;
}

bool SudokuBoard::isSolved() const {
    if (!isComplete()) return false;
    for (int i = 0; i < SIZE; ++i) {
        std::set<int> row, col, box;
        for (int j = 0; j < SIZE; ++j) {
            row.insert(grid_[i][j]);
            col.insert(grid_[j][i]);
            box.insert(grid_[BOX * (i / BOX) + j / BOX][BOX * (i % BOX) + j % BOX]);
        }
        if (row.size() != SIZE || col.size() != SIZE || box.size() != SIZE) return false;
    }
    return true;
}

bool SudokuBoard::hasDuplicates(const Grid& grid) {
    for (int i = 0; i < SIZE; ++i) {
        std::array<int, SIZE + 1> row{}, col{}, box{};
        for (int j = 0; j < SIZE; ++j) {
            if (grid[i][j] && ++row[grid[i][j]] > 1) return true;
            if (grid[j][i] && ++col[grid[j][i]] > 1) return true;
            int v = grid[BOX * (i / BOX) + j / BOX][BOX * (i % BOX) + j % BOX];
            if (v && ++box[v] > 1) return true;
        }
    }
    return false;
}

bool SudokuBoard::validatePuzzle() const { return !hasDuplicates(original_); }

void SudokuBoard::reset() {
    grid_ = original_;
    trail_.clear();
}

void SudokuBoard::placeCandidate(int row, int col, int digit) {
    checkIndex(row, col);
    checkDigit(digit);
    if (givens_[row][col]) throw BoardError("GIVEN_CELL", cellName({row, col}) + " is a starting clue.");
    if (grid_[row][col] != EMPTY) throw BoardError("CELL_OCCUPIED", cellName({row, col}) + " is not empty.");
    if (!isValid(row, col, digit)) throw BoardError("ILLEGAL_PLACEMENT", std::to_string(digit) + " breaks a rule at " + cellName({row, col}) + ".");
    grid_[row][col] = digit;
    trail_.push_back({row, col});
}

void SudokuBoard::undoPlacement(int row, int col) {
    if (trail_.empty() || !(trail_.back() == Cell{row, col}))
        throw BoardError("UNDO_ORDER", cellName({row, col}) + " is not the most recent placement.");
    trail_.pop_back();
    grid_[row][col] = EMPTY;
}

void SudokuBoard::checkIndex(int row, int col) {
    if (row < 0 || row >= SIZE || col < 0 || col >= SIZE)
        throw BoardError("INDEX_OUT_OF_RANGE", "Cell (" + std::to_string(row) + ", " + std::to_string(col) + ") is outside the board.");
}

void SudokuBoard::checkValue(int value) {
    if (value < EMPTY || value > SIZE) throw BoardError("VALUE_OUT_OF_RANGE", std::to_string(value) + " is not a cell value (0-9).");
}

void SudokuBoard::checkDigit(int digit) {
    if (digit < 1 || digit > SIZE) throw BoardError("VALUE_OUT_OF_RANGE", std::to_string(digit) + " is not a Sudoku digit (1-9).");
}

}  // namespace sudoku
