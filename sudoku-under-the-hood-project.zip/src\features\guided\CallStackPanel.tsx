import { useState, type ReactNode } from 'react';
import { Button } from '../../components/Button';
import { Panel } from '../../components/Panel';
import { cellName } from '../../domain/SudokuBoard';
import type { CallRecord, Trace } from '../../solver/trace';
import styles from './Guided.module.css';

const SHOW = 7;

/**
 * The open recursive calls at this step, newest on top. Each frame lists the
 * branches it has tried so far: the digits it placed before calling itself.
 */
export function CallStackPanel({ trace, index, onSeek, collapsible, defaultOpen = true }: { trace: Trace; index: number; onSeek: (i: number) => void; collapsible?: boolean; defaultOpen?: boolean }) {
  const [expanded, setExpanded] = useState(false);
  const stack = index >= 0 ? trace.stackAt(index) : [];
  const frames = [...stack].reverse();
  const hidden = !expanded && frames.length > SHOW + 2 ? frames.length - SHOW - 1 : 0;
  const visible = hidden ? [...frames.slice(0, SHOW), frames[frames.length - 1]] : frames;
  const values = index >= 0 ? trace.boardAt(index) : trace.initial;

  return (
    <Panel label="Call stack" meta={stack.length ? `${stack.length} open ${stack.length === 1 ? 'call' : 'calls'}` : 'empty'} flush collapsible={collapsible} defaultOpen={defaultOpen}>
      {frames.length === 0 ? (
        <p className={styles.collapsed} style={{ border: 0, color: 'var(--gray)', fontSize: 'var(--t-sm)' }}>
          {index < 0 ? 'No calls yet. The first call is solve() at depth 0.' : 'Every call has returned.'}
        </p>
      ) : (
        <ol className={styles.stack} aria-label="Open calls, newest first">
          {visible.map((call, k) => (
            <FrameRow
              key={call.id}
              call={call}
              trace={trace}
              index={index}
              value={call.cell ? values[call.cell.row * 9 + call.cell.col] : 0}
              top={k === 0}
              onSeek={onSeek}
              before={hidden && k === SHOW ? (
                <li className={styles.collapsed}>
                  <Button size="sm" variant="ghost" onClick={() => setExpanded(true)}>
                    Show {hidden} more {hidden === 1 ? 'frame' : 'frames'}
                  </Button>
                </li>
              ) : null}
            />
          ))}
          {expanded && frames.length > SHOW + 2 && (
            <li className={styles.collapsed}>
              <Button size="sm" variant="ghost" onClick={() => setExpanded(false)}>
                Collapse
              </Button>
            </li>
          )}
        </ol>
      )}
    </Panel>
  );
}

function FrameRow({ call, trace, index, value, top, onSeek, before }: { call: CallRecord; trace: Trace; index: number; value: number; top: boolean; onSeek: (i: number) => void; before: ReactNode }) {
  const children = trace.childrenAt(call, index);
  return (
    <>
      {before}
      <li className={`${styles.frame} ${top ? styles.frameTop : ''}`}>
        <button type="button" className={styles.frameDepth} onClick={() => onSeek(call.enterIndex)} title={`Jump to the start of call #${call.id}`}>
          d{call.depth}
        </button>
        <div className={styles.frameMain}>
          <span className={styles.frameTitle}>
            solve() <em>#{call.id}</em> {call.cell ? `· ${cellName(call.cell)}` : '· board full'}
            {call.cell && value ? ` = ${value}` : ''}
          </span>
          {children.length > 0 && (
            <span className={styles.branches} aria-label="Branches tried">
              {children.map((child) => {
                const status = trace.statusAt(child, index);
                const size = trace.subtreeSize(child);
                return (
                  <button
                    key={child.id}
                    type="button"
                    className={styles.branch}
                    data-status={status}
                    onClick={() => onSeek(child.enterIndex)}
                    title={`${child.via?.digit} at ${child.via ? cellName(child.via.cell) : ''}: ${status === 'failed' ? `dead end after ${size} ${size === 1 ? 'call' : 'calls'}` : status === 'solved' ? 'led to the solution' : 'being explored'}`}
                  >
                    {child.via?.digit}
                    {status === 'failed' && <small>✕{size > 1 ? size : ''}</small>}
                    {status === 'solved' && <small>✓</small>}
                  </button>
                );
              })}
            </span>
          )}
        </div>
      </li>
    </>
  );
}
