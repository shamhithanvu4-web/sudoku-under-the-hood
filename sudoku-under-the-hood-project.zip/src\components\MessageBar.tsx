import type { Message } from '../features/play/gameSession';
import { Icon } from './Icon';
import styles from './MessageBar.module.css';

/** Status line read out to screen readers when it changes. */
export function MessageBar({ message, placeholder }: { message: Message | null; placeholder?: string }) {
  return (
    <div className={styles.bar} data-tone={message?.tone ?? 'none'} role="status" aria-live="polite">
      {message ? (
        <>
          <span className={styles.icon} aria-hidden="true">
            <Icon name={message.tone === 'success' ? 'check' : 'info'} size={16} />
          </span>
          <span>{message.text}</span>
        </>
      ) : (
        <span className={styles.empty}>{placeholder}</span>
      )}
    </div>
  );
}
