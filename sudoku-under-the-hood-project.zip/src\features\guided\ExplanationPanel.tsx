import { useApp } from '../../app/AppState';
import { Panel } from '../../components/Panel';
import { Segmented } from '../../components/Segmented';
import { explainEvent } from '../../explain/explain';
import type { Trace } from '../../solver/trace';
import type { SolverKind } from '../../solver/types';
import { CATEGORY } from './eventStyle';
import styles from './Guided.module.css';

export type Detail = 'concise' | 'detailed';

export function ExplanationPanel({
  trace,
  index,
  kind,
  detail,
  onDetail,
}: {
  trace: Trace;
  index: number;
  kind: SolverKind;
  detail: Detail;
  onDetail: (d: Detail) => void;
}) {
  const { navigate } = useApp();
  const e = index >= 0 ? trace.events[index] : null;
  const x = e ? explainEvent(trace, index, kind) : null;
  return (
    <Panel
      label="What just happened"
      meta={e ? `step ${(index + 1).toLocaleString('en-US')}` : 'not started'}
      actions={
        <Segmented
          size="sm"
          label="Explanation detail"
          value={detail}
          onChange={onDetail}
          options={[
            { value: 'concise', label: 'Concise' },
            { value: 'detailed', label: 'Detailed' },
          ]}
        />
      }
    >
      {e && x ? (
        <div aria-live="polite">
          <div className={styles.explainHead}>
            <span className={styles.badge} data-cat={CATEGORY[e.type]} data-event-type={e.type}>
              {e.type}
            </span>
            {e.callId >= 0 && (
              <span className={styles.depthTag}>
                call #{e.callId} · depth {e.depth}
              </span>
            )}
          </div>
          <h2 className={styles.explainTitle}>{x.title}</h2>
          <p className={styles.explainText}>{x.concise}</p>
          {detail === 'detailed' && <p className={styles.explainDetail}>{x.detailed}</p>}
          {detail === 'detailed' ? (
            <dl className={styles.operation}>
              <dt>operation</dt>
              <dd>{x.call}</dd>
              <dt>result</dt>
              <dd>{x.outcome}</dd>
              <dt>indices</dt>
              <dd>0-based in code: r1c1 is grid[0][0]</dd>
            </dl>
          ) : (
            <dl className={styles.operation}>
              <dt>operation</dt>
              <dd>{x.name}</dd>
            </dl>
          )}
          <div className={styles.conceptRow}>
            <span className="label">DSA concept</span>
            <button type="button" className={styles.conceptLink} onClick={() => navigate('learn', x.lesson)}>
              {x.concept}
            </button>
          </div>
        </div>
      ) : (
        <p className={styles.emptyExplain}>
          The solver has been run on this puzzle and every step was recorded. Press <strong>Start</strong> to replay it, or step
          through with <kbd>→</kbd>. Each step is explained here and highlighted in the source code.
        </p>
      )}
    </Panel>
  );
}
