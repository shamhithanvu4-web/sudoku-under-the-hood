/**
 * SudokuBoard — the Board Abstract Data Type (ADT).
 *
 * An ADT is defined by its operations and their behaviour, not by how the
 * data is stored. Code outside this class (the game UI, the solvers, the
 * lessons) can only use the public methods documented below.
 *
 * Implementation choice: the cells live in a 9×9 two-dimensional array of
 * numbers (`#grid[row][col]`, 0 = empty). The array is a *private* field
 * (the `#` prefix is enforced by the JavaScript engine), so no other module
 * can read or change it directly. Swapping the array for another data
 * structure would not change any caller.
 *
 * Two kinds of writers are kept apart on purpose:
 *   - Player operations:  setCell()                — any non-clue cell, any order.
 *   - Solver operations:  placeCandidate() / undoPlacement()
 *                         — only legal digits, only into empty cells, and
 *                           undone in last-in-first-out order, exactly like
 *                           the recursion that makes them.
 *
 * Indices are 0-based (row 0..8, col 0..8). The UI shows them 1-based as
 * r1c1..r9c9 for people.
 */

export const SIZE = 9;
export const BOX = 3;
export const EMPTY = 0;

export interface Coord {
  readonly row: number;
  readonly col: number;
}

/** A read-only 9×9 grid of values (0 = empty). */
export type Grid = readonly (readonly number[])[];

export type ConstraintKind = 'row' | 'column' | 'box';

/** Why a digit cannot go in a cell: it already appears at `at` in the same unit. */
export interface Conflict {
  readonly kind: ConstraintKind;
  readonly at: Coord;
  readonly value: number;
}

/** Two cells in the same unit holding the same digit. */
export interface ConflictPair {
  readonly kind: ConstraintKind;
  readonly a: Coord;
  readonly b: Coord;
  readonly value: number;
}

export interface PuzzleReport {
  /** True when the starting clues break no Sudoku rule. */
  readonly ok: boolean;
  readonly clueCount: number;
  readonly conflicts: readonly ConflictPair[];
}

export type BoardErrorCode =
  | 'MALFORMED'
  | 'INDEX_OUT_OF_RANGE'
  | 'VALUE_OUT_OF_RANGE'
  | 'GIVEN_CELL'
  | 'CELL_OCCUPIED'
  | 'ILLEGAL_PLACEMENT'
  | 'UNDO_ORDER';

/** Thrown when a caller breaks an operation's precondition. */
export class BoardError extends Error {
  readonly code: BoardErrorCode;
  constructor(code: BoardErrorCode, message: string) {
    super(message);
    this.name = 'BoardError';
    this.code = code;
  }
}

/** Human-readable cell name, e.g. { row: 3, col: 6 } → "r4c7". */
export function cellName(cell: Coord): string {
  return `r${cell.row + 1}c${cell.col + 1}`;
}

export class SudokuBoard {
  /** The underlying data structure: a 9×9 two-dimensional array. 0 = empty. */
  #grid: number[][] = [];
  /** #givens[row][col] is true for the puzzle's starting clues. */
  #givens: boolean[][] = [];
  /** The starting puzzle, kept so reset() can restore it. */
  #original: number[][] = [];
  /** Solver placements, newest last. It grows and shrinks with the recursion. */
  #trail: Coord[] = [];

  /** Creates a board from a 9×9 grid (0 = empty). See initialize(). */
  constructor(puzzle: Grid) {
    this.initialize(puzzle);
  }

  /**
   * initialize(puzzle) — loads a new puzzle.
   * Every non-zero value becomes an immutable starting clue.
   * Throws MALFORMED unless the input is 9 rows of 9 integers in 0..9.
   * Does not check Sudoku rules; call validatePuzzle() for that.
   */
  initialize(puzzle: Grid): void {
    assertWellFormed(puzzle);
    this.#original = puzzle.map((row) => [...row]);
    this.#grid = puzzle.map((row) => [...row]);
    this.#givens = puzzle.map((row) => row.map((value) => value !== EMPTY));
    this.#trail = [];
  }

  /** getCell(row, col) — the value at a cell (0 when empty). O(1). */
  getCell(row: number, col: number): number {
    this.#checkIndex(row, col);
    return this.#grid[row][col];
  }

  /** isGiven(row, col) — true when the cell is one of the starting clues. O(1). */
  isGiven(row: number, col: number): boolean {
    this.#checkIndex(row, col);
    return this.#givens[row][col];
  }

  /**
   * setCell(row, col, value) — PLAYER operation. Writes 0..9 into a non-clue cell
   * and returns the value it replaced. It does not reject rule conflicts:
   * a player may make a mistake, and the game highlights it instead.
   * Throws GIVEN_CELL for a starting clue.
   */
  setCell(row: number, col: number, value: number): number {
    this.#checkIndex(row, col);
    this.#checkValue(value);
    if (this.#givens[row][col]) {
      throw new BoardError('GIVEN_CELL', `${cellName({ row, col })} is a starting clue and cannot be changed.`);
    }
    const previous = this.#grid[row][col];
    this.#grid[row][col] = value;
    return previous;
  }

  /**
   * findEmptyCell() — the first empty cell in row-major order
   * (row 0 left to right, then row 1, …), or null when the board is full.
   * O(81) in the worst case.
   */
  findEmptyCell(): Coord | null {
    for (let row = 0; row < SIZE; row++) {
      for (let col = 0; col < SIZE; col++) {
        if (this.#grid[row][col] === EMPTY) return { row, col };
      }
    }
    return null;
  }

  /**
   * findConflict(row, col, digit) — checks the three Sudoku rules for putting
   * `digit` at (row, col): the digit must not already appear elsewhere in the
   * same row, column, or 3×3 box. Returns the first clash found, or null.
   * The cell itself is ignored, so a filled cell can be re-checked.
   * Scans at most 27 cells: O(1) for a fixed 9×9 board.
   */
  findConflict(row: number, col: number, digit: number): Conflict | null {
    this.#checkIndex(row, col);
    this.#checkDigit(digit);
    for (let c = 0; c < SIZE; c++) {
      if (c !== col && this.#grid[row][c] === digit) {
        return { kind: 'row', at: { row, col: c }, value: digit };
      }
    }
    for (let r = 0; r < SIZE; r++) {
      if (r !== row && this.#grid[r][col] === digit) {
        return { kind: 'column', at: { row: r, col }, value: digit };
      }
    }
    const top = row - (row % BOX);
    const left = col - (col % BOX);
    for (let r = top; r < top + BOX; r++) {
      for (let c = left; c < left + BOX; c++) {
        if ((r !== row || c !== col) && this.#grid[r][c] === digit) {
          return { kind: 'box', at: { row: r, col: c }, value: digit };
        }
      }
    }
    return null;
  }

  /** isValid(row, col, digit) — true when findConflict() finds no clash. */
  isValid(row: number, col: number, digit: number): boolean {
    return this.findConflict(row, col, digit) === null;
  }

  /**
   * getCandidates(row, col) — the digits that could legally go in an empty
   * cell right now, in increasing order. Returns [] for a filled cell.
   * One pass over the cell's row, column and box (27 reads).
   */
  getCandidates(row: number, col: number): number[] {
    this.#checkIndex(row, col);
    if (this.#grid[row][col] !== EMPTY) return [];
    const used = new Array<boolean>(SIZE + 1).fill(false);
    for (let i = 0; i < SIZE; i++) {
      used[this.#grid[row][i]] = true;
      used[this.#grid[i][col]] = true;
    }
    const top = row - (row % BOX);
    const left = col - (col % BOX);
    for (let r = top; r < top + BOX; r++) {
      for (let c = left; c < left + BOX; c++) used[this.#grid[r][c]] = true;
    }
    const candidates: number[] = [];
    for (let digit = 1; digit <= SIZE; digit++) {
      if (!used[digit]) candidates.push(digit);
    }
    return candidates;
  }

  /** isComplete() — true when no cell is empty. Says nothing about correctness. */
  isComplete(): boolean {
    return this.findEmptyCell() === null;
  }

  /**
   * isSolved() — true only when the board is complete AND every row, every
   * column and every 3×3 box contains each digit 1–9 exactly once.
   * A full board with a mistake is complete but not solved.
   */
  isSolved(): boolean {
    if (!this.isComplete()) return false;
    for (let i = 0; i < SIZE; i++) {
      const rowDigits = new Set<number>();
      const colDigits = new Set<number>();
      const boxDigits = new Set<number>();
      for (let j = 0; j < SIZE; j++) {
        rowDigits.add(this.#grid[i][j]);
        colDigits.add(this.#grid[j][i]);
        const r = BOX * Math.floor(i / BOX) + Math.floor(j / BOX);
        const c = BOX * (i % BOX) + (j % BOX);
        boxDigits.add(this.#grid[r][c]);
      }
      if (rowDigits.size !== SIZE || colDigits.size !== SIZE || boxDigits.size !== SIZE) {
        return false;
      }
    }
    return true;
  }

  /**
   * findAllConflicts() — every pair of cells that currently break a rule
   * (same digit twice in a row, column or box). Used to highlight mistakes.
   */
  findAllConflicts(): ConflictPair[] {
    return collectConflicts(this.#grid);
  }

  /**
   * validatePuzzle() — checks the STARTING clues only. A puzzle whose clues
   * already break a rule can never be solved, so the solver refuses it.
   * (A puzzle can pass this check and still have no solution; only a search
   * can prove that.)
   */
  validatePuzzle(): PuzzleReport {
    const conflicts = collectConflicts(this.#original);
    const clueCount = this.#original.flat().filter((value) => value !== EMPTY).length;
    return { ok: conflicts.length === 0, clueCount, conflicts };
  }

  /** reset() — restores the starting puzzle and forgets every placement. */
  reset(): void {
    this.#grid = this.#original.map((row) => [...row]);
    this.#trail = [];
  }

  /** getSnapshot() — a frozen copy of the current values. Changing it cannot change the board. */
  getSnapshot(): Grid {
    return Object.freeze(this.#grid.map((row) => Object.freeze([...row])));
  }

  /** getOriginal() — a frozen copy of the starting puzzle. */
  getOriginal(): Grid {
    return Object.freeze(this.#original.map((row) => Object.freeze([...row])));
  }

  /** countEmpty() — how many cells are still 0. */
  countEmpty(): number {
    return this.#grid.flat().filter((value) => value === EMPTY).length;
  }

  // ───────────────────────── Solver interface ─────────────────────────

  /**
   * placeCandidate(row, col, digit) — SOLVER operation. Tentatively puts a
   * digit into an EMPTY cell. The digit must pass findConflict(); the board
   * refuses illegal moves instead of trusting the caller. The placement is
   * pushed onto a trail so it can be undone.
   */
  placeCandidate(row: number, col: number, digit: number): void {
    this.#checkIndex(row, col);
    this.#checkDigit(digit);
    if (this.#givens[row][col]) {
      throw new BoardError('GIVEN_CELL', `${cellName({ row, col })} is a starting clue.`);
    }
    if (this.#grid[row][col] !== EMPTY) {
      throw new BoardError('CELL_OCCUPIED', `${cellName({ row, col })} is not empty.`);
    }
    if (!this.isValid(row, col, digit)) {
      throw new BoardError('ILLEGAL_PLACEMENT', `${digit} breaks a rule at ${cellName({ row, col })}.`);
    }
    this.#grid[row][col] = digit;
    this.#trail.push({ row, col });
  }

  /**
   * undoPlacement(row, col) — SOLVER operation. Removes the most recent
   * tentative placement and restores the cell to 0. Undoing anything except
   * the newest placement throws UNDO_ORDER: backtracking is last-in, first-out.
   */
  undoPlacement(row: number, col: number): void {
    const last = this.#trail[this.#trail.length - 1];
    if (last === undefined || last.row !== row || last.col !== col) {
      throw new BoardError('UNDO_ORDER', `${cellName({ row, col })} is not the most recent placement.`);
    }
    this.#trail.pop();
    this.#grid[row][col] = EMPTY;
  }

  /** placementCount() — how many tentative placements are currently on the trail. */
  placementCount(): number {
    return this.#trail.length;
  }

  // ───────────────────────── Private helpers ─────────────────────────

  #checkIndex(row: number, col: number): void {
    if (!Number.isInteger(row) || !Number.isInteger(col) || row < 0 || row >= SIZE || col < 0 || col >= SIZE) {
      throw new BoardError('INDEX_OUT_OF_RANGE', `Cell (${row}, ${col}) is outside the 9×9 board.`);
    }
  }

  #checkValue(value: number): void {
    if (!Number.isInteger(value) || value < EMPTY || value > SIZE) {
      throw new BoardError('VALUE_OUT_OF_RANGE', `${value} is not a cell value (use 0–9).`);
    }
  }

  #checkDigit(digit: number): void {
    if (!Number.isInteger(digit) || digit < 1 || digit > SIZE) {
      throw new BoardError('VALUE_OUT_OF_RANGE', `${digit} is not a Sudoku digit (use 1–9).`);
    }
  }
}

function assertWellFormed(puzzle: Grid): void {
  const ok =
    Array.isArray(puzzle) &&
    puzzle.length === SIZE &&
    puzzle.every(
      (row) =>
        Array.isArray(row) &&
        row.length === SIZE &&
        row.every((value) => Number.isInteger(value) && value >= EMPTY && value <= SIZE),
    );
  if (!ok) {
    throw new BoardError('MALFORMED', 'A puzzle must be 9 rows of 9 whole numbers from 0 to 9.');
  }
}

/** Groups the 27 units (9 rows, 9 columns, 9 boxes) and reports duplicate digits. */
function collectConflicts(grid: Grid): ConflictPair[] {
  const pairs: ConflictPair[] = [];
  const units: { kind: ConstraintKind; cells: Coord[] }[] = [];
  for (let i = 0; i < SIZE; i++) {
    const rowCells: Coord[] = [];
    const colCells: Coord[] = [];
    const boxCells: Coord[] = [];
    for (let j = 0; j < SIZE; j++) {
      rowCells.push({ row: i, col: j });
      colCells.push({ row: j, col: i });
      boxCells.push({
        row: BOX * Math.floor(i / BOX) + Math.floor(j / BOX),
        col: BOX * (i % BOX) + (j % BOX),
      });
    }
    units.push({ kind: 'row', cells: rowCells }, { kind: 'column', cells: colCells }, { kind: 'box', cells: boxCells });
  }
  for (const unit of units) {
    for (let x = 0; x < unit.cells.length; x++) {
      const a = unit.cells[x];
      const value = grid[a.row][a.col];
      if (value === EMPTY) continue;
      for (let y = x + 1; y < unit.cells.length; y++) {
        const b = unit.cells[y];
        if (grid[b.row][b.col] === value) pairs.push({ kind: unit.kind, a, b, value });
      }
    }
  }
  return pairs;
}
