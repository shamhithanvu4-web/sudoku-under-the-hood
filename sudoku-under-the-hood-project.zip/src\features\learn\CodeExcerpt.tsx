import { useRef } from 'react';
import { CopyButton } from '../../components/CopyButton';
import { extractMember, publicSignatures } from '../../explain/sourceIndex';
import { SOURCES } from '../../explain/sources';
import { highlight } from '../../explain/highlight';
import guided from '../guided/Guided.module.css';

export interface CodeRef {
  file: keyof typeof SOURCES;
  member?: string;
  step?: string;
  signatures?: boolean;
}

/** A slice of a real source file: one member, or the public signatures of the board ADT. */
export function CodeExcerpt({ code }: { code: CodeRef }) {
  const src = SOURCES[code.file];
  const pre = useRef<HTMLPreElement>(null);
  let lines: { n: number | null; tokens: ReturnType<typeof highlight>[number]; active: boolean }[] = [];
  let text = '';
  let where = src.path;

  if (code.signatures) {
    const sigs = publicSignatures(src.view);
    text = `class SudokuBoard {\n${sigs.map((s) => `  ${s};`).join('\n')}\n}`;
    lines = highlight(text).map((tokens) => ({ n: null, tokens, active: false }));
    where = `${src.path} · public operations`;
  } else if (code.member) {
    const m = extractMember(src.view, code.member);
    if (m) {
      const active = new Set(code.step ? (src.view.steps.get(code.step) ?? []) : [m.signatureLine]);
      text = m.lines.join('\n');
      lines = src.tokens.slice(m.startLine - 1, m.startLine - 1 + m.lines.length).map((tokens, i) => ({ n: m.startLine + i, tokens, active: active.has(m.startLine + i) }));
      where = `${src.path} · lines ${m.startLine}–${m.startLine + m.lines.length - 1}`;
    }
  }

  return (
    <div>
      <div className={guided.codeFoot} style={{ borderTop: 0, borderBottom: '1px solid var(--line)', alignItems: 'center' }}>
        <span>{where}</span>
        <CopyButton text={text} fallbackTarget={() => pre.current} />
      </div>
      <div className={guided.codeScroll} style={{ maxHeight: 420 }}>
        <pre className={guided.code} ref={pre}>
          {lines.map((l, i) => (
            <div key={i} className={`${guided.codeLine} ${l.active ? guided.active : ''}`}>
              <span className={guided.lineNo}>{l.n ?? ''}</span>
              <code style={{ background: 'none', padding: 0 }}>
                {l.tokens.length === 0 ? ' ' : l.tokens.map((t, k) => <span key={k} className={guided[`tk-${t.kind}`]}>{t.text}</span>)}
              </code>
            </div>
          ))}
        </pre>
      </div>
    </div>
  );
}
