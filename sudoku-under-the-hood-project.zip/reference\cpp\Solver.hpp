// Recursive backtracking solvers: plain (first empty cell, digits 1-9) and MRV.
// Counters follow the same conventions as the web app's Recorder, so the
// numbers can be compared with Analyze mode for the same puzzle.
#pragma once

#include "SudokuBoard.hpp"

namespace sudoku {

struct Stats {
    long recursiveCalls = 0;
    long candidateAttempts = 0;
    long rejected = 0;
    long placements = 0;
    long backtracks = 0;
    long deadEnds = 0;
    int maxDepth = 0;
    long peerScans = 0;
};

// Solve in place. true: board holds the solution. false: board restored to its clues.
bool solveBacktracking(SudokuBoard& board, Stats& stats);
bool solveMRV(SudokuBoard& board, Stats& stats);

}  // namespace sudoku
