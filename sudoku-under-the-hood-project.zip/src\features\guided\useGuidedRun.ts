import { useEffect, useMemo, useState } from 'react';
import { useApp } from '../../app/AppState';
import { gridToString } from '../../domain/puzzleFormat';
import type { Grid } from '../../domain/SudokuBoard';
import type { SolverKind } from '../../solver/types';
import { usePlayback } from './usePlayback';
import { useSolverRun } from './useSolverRun';

export type Source = 'original' | 'board';

/** The selected puzzle, solver and starting board, recorded and ready to replay. */
export function useGuidedRun(kind: SolverKind, source: Source) {
  const { puzzle, session, version } = useApp();
  const playerEntries = useMemo(() => {
    const view = session.view();
    return view.values.filter((v, i) => v !== 0 && !view.givens[i]).length;
    // version changes whenever the player edits the board
  }, [session, version]);
  const effectiveSource: Source = source === 'board' && playerEntries > 0 ? 'board' : 'original';
  const grid: Grid = effectiveSource === 'board' ? session.current : puzzle.grid;
  const key = `${puzzle.id}|${kind}|${gridToString(grid)}`;
  const { result, running } = useSolverRun(grid, kind, key);
  const trace = result?.trace ?? null;
  const playback = usePlayback(trace, key);
  return { puzzle, grid, result, running, trace, playback, playerEntries, effectiveSource, key };
}

/** Space, arrows, Home and End drive playback while focus is not in a form field. */
export function usePlaybackKeys(p: ReturnType<typeof usePlayback>, enabled = true) {
  const [lastKey, setLastKey] = useState('');
  useEffect(() => {
    if (!enabled) return;
    const handler = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && (/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName) || t.getAttribute('role') === 'radio' || t.getAttribute('role') === 'tab')) return;
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      let handled = true;
      if (e.key === ' ' && !(t && t.tagName === 'BUTTON')) p.toggle();
      else if (e.key === 'ArrowRight') e.shiftKey ? p.jumpTo('BACKTRACK', 1) : p.step(1);
      else if (e.key === 'ArrowLeft') e.shiftKey ? p.jumpTo('BACKTRACK', -1) : p.step(-1);
      else if (e.key === 'Home') p.setIndex(-1);
      else if (e.key === 'End') p.setIndex(p.length - 1);
      else handled = false;
      if (handled) {
        e.preventDefault();
        setLastKey(e.key);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [enabled, p]);
  return lastKey;
}
