/**
 * What the board should show at one moment of a recorded run.
 * Everything here is derived from the trace; nothing re-runs the algorithm.
 */
import { SIZE, SudokuBoard, BOX } from '../../domain/SudokuBoard';
import { toGrid } from '../../domain/puzzleFormat';
import type { Trace } from '../../solver/trace';
import type { CellMark, UnitHighlight } from '../board/SudokuGrid';

export interface BoardView {
  values: Uint8Array;
  givens: boolean[];
  marks: Map<number, CellMark>;
  focusCell: number | null;
  units: UnitHighlight[];
  link: { from: number; to: number } | null;
}

export interface BoardViewOptions {
  /** Label each tentative placement with the recursion depth that made it. */
  depthLabels: boolean;
  /** Show the number of candidates in every empty cell (MRV's scores). */
  candidateCounts: boolean;
}

const at = (c: { row: number; col: number }) => c.row * SIZE + c.col;
const boxIndex = (c: { row: number; col: number }) => Math.floor(c.row / BOX) * BOX + Math.floor(c.col / BOX);

export function buildBoardView(trace: Trace, index: number, options: BoardViewOptions): BoardView {
  const values = trace.boardAt(index);
  const givens = Array.from(trace.initial, (v) => v !== 0);
  const marks = new Map<number, CellMark>();
  const set = (i: number, patch: CellMark) => marks.set(i, { ...marks.get(i), ...patch });

  values.forEach((v, i) => {
    if (v !== 0 && !givens[i]) set(i, { tone: 'solver' });
  });

  if (options.depthLabels && index >= 0) {
    for (const frame of trace.stackAt(index)) {
      if (frame.cell && values[at(frame.cell)] !== 0) set(at(frame.cell), { corner: `d${frame.depth}` });
    }
  }

  if (options.candidateCounts) {
    const board = new SudokuBoard(toGrid(values));
    values.forEach((v, i) => {
      if (v === 0) set(i, { corner: String(board.getCandidates(Math.floor(i / SIZE), i % SIZE).length) });
    });
  }

  let focusCell: number | null = null;
  const units: UnitHighlight[] = [];
  let link: BoardView['link'] = null;
  const e = index >= 0 ? trace.events[index] : undefined;

  if (e) {
    const cell = e.cell ?? (e.callId >= 0 ? trace.calls[e.callId].cell : null) ?? null;
    const i = cell ? at(cell) : null;
    switch (e.type) {
      case 'CELL_SELECTED':
        focusCell = i;
        break;
      case 'CANDIDATES_COMPUTED':
        focusCell = i;
        if (cell) units.push({ row: cell.row, col: cell.col, box: boxIndex(cell), tone: 'scan' });
        if (i !== null) set(i, { pencil: e.candidates ?? [], pencilTone: 'candidates' });
        break;
      case 'CANDIDATE_TRIED':
        focusCell = i;
        if (i !== null) set(i, { ghost: e.digit, ghostTone: 'trying' });
        break;
      case 'VALIDATION_PASSED':
        focusCell = i;
        if (cell) units.push({ row: cell.row, col: cell.col, box: boxIndex(cell), tone: 'scan' });
        if (i !== null) set(i, { ghost: e.digit, ghostTone: 'accepted' });
        break;
      case 'VALIDATION_FAILED': {
        focusCell = i;
        const c = e.conflict!;
        if (cell) {
          if (c.kind === 'row') units.push({ row: cell.row, tone: 'clash' });
          if (c.kind === 'column') units.push({ col: cell.col, tone: 'clash' });
          if (c.kind === 'box') units.push({ box: boxIndex(cell), tone: 'clash' });
        }
        if (i !== null) {
          set(i, { ghost: e.digit, ghostTone: 'rejected' });
          set(at(c.at), { tone: 'clash-source' });
          link = { from: i, to: at(c.at) };
        }
        break;
      }
      case 'VALUE_PLACED':
        focusCell = i;
        if (i !== null) set(i, { tone: 'placed' });
        break;
      case 'RECURSION_ENTERED':
        if (e.via) set(at(e.via.cell), { tone: 'placed' });
        break;
      case 'RECURSION_RETURNED':
        focusCell = i;
        if (i !== null && e.result === false) set(i, { tone: 'deadend' });
        break;
      case 'BACKTRACK':
        focusCell = i;
        if (i !== null) set(i, { tone: 'backtrack', ghost: e.before, ghostTone: 'backtrack' });
        break;
      case 'DEAD_END':
        focusCell = i;
        if (i !== null) set(i, { tone: 'deadend' });
        break;
      case 'SOLUTION_FOUND':
        values.forEach((_, k) => {
          if (!givens[k]) set(k, { tone: 'solved' });
        });
        break;
      default:
        break;
    }
  }

  return { values, givens, marks, focusCell, units, link };
}
