import { Panel } from '../../components/Panel';
import type { RunResult } from '../../solver/runSolver';
import type { SolverStats } from '../../solver/types';
import styles from './Guided.module.css';

const fmt = (n: number) => n.toLocaleString('en-US');

export const STAT_ROWS: { key: keyof SolverStats; label: string; tone?: 'failure' | 'success' }[] = [
  { key: 'recursiveCalls', label: 'Recursive calls' },
  { key: 'candidateAttempts', label: 'Digits tried' },
  { key: 'rejected', label: 'Rejected by rules', tone: 'failure' },
  { key: 'placements', label: 'Placements', tone: 'success' },
  { key: 'backtracks', label: 'Backtracks', tone: 'failure' },
  { key: 'deadEnds', label: 'Dead ends', tone: 'failure' },
  { key: 'maxDepth', label: 'Max depth' },
  { key: 'peerScans', label: 'Row/col/box scans' },
];

/** Counters accumulated up to the current step, rebuilt from the trace. */
export function StatsPanel({ stats, result, index, collapsible, defaultOpen = true }: { stats: SolverStats; result: RunResult; index: number; collapsible?: boolean; defaultOpen?: boolean }) {
  const atEnd = result.trace ? index >= result.trace.length - 1 : true;
  return (
    <Panel label="Counters" meta={atEnd ? 'whole run' : 'up to this step'} flush collapsible={collapsible} defaultOpen={defaultOpen}>
      <dl className={styles.stats}>
        {STAT_ROWS.map((row) => (
          <div key={row.key} className={styles.stat} data-tone={row.tone}>
            <dt>{row.label}</dt>
            <dd>{fmt(stats[row.key])}</dd>
          </div>
        ))}
      </dl>
      <p className={styles.statsFoot}>
        Recording this run took {result.durationMs.toFixed(1)} ms, including the cost of tracing every step. For timing comparisons,
        use Analyze, which runs the solvers without recording.
      </p>
    </Panel>
  );
}
