import { useEffect, useRef, type KeyboardEvent } from 'react';
import styles from './SudokuGrid.module.css';

export type CellTone =
  | 'solver'
  | 'placed'
  | 'backtrack'
  | 'deadend'
  | 'conflict'
  | 'clash-source'
  | 'wrong'
  | 'hint'
  | 'solved';

export interface CellMark {
  tone?: CellTone;
  /** A digit drawn over the cell while the solver considers it. */
  ghost?: number;
  ghostTone?: 'trying' | 'accepted' | 'rejected' | 'backtrack';
  /** Small candidate digits to show in an empty cell. */
  pencil?: readonly number[];
  pencilTone?: 'candidates' | 'notes';
  /** Tiny corner label (recursion depth, candidate count…). */
  corner?: string;
}

export interface UnitHighlight {
  row?: number;
  col?: number;
  box?: number;
  tone: 'scan' | 'clash';
}

interface Props {
  values: ArrayLike<number>;
  givens: ArrayLike<boolean>;
  /** Player pencil notes as bitmasks (bit d = digit d). */
  notes?: readonly number[];
  marks?: ReadonlyMap<number, CellMark>;
  selected?: number | null;
  /** The solver's current cell. */
  focusCell?: number | null;
  units?: readonly UnitHighlight[];
  /** Draws a line between a tried cell and the clue that blocks it. */
  link?: { from: number; to: number } | null;
  /** Highlight the selected cell's row, column, box and matching digits. */
  showPeers?: boolean;
  /** 'sudoku' draws 1-based r1–r9 / c1–c9 labels around the board. */
  coords?: 'sudoku' | 'none';
  onSelect?: (index: number) => void;
  /** Keys other than arrows. Return true when handled. */
  onKey?: (e: KeyboardEvent<HTMLDivElement>, index: number) => boolean;
  label: string;
  /** Changes on every solver step so short animations replay. */
  animKey?: number;
  className?: string;
}

const boxOf = (i: number) => Math.floor(Math.floor(i / 9) / 3) * 3 + Math.floor((i % 9) / 3);

export function SudokuGrid({
  values,
  givens,
  notes,
  marks,
  selected = null,
  focusCell = null,
  units = [],
  link = null,
  showPeers = false,
  coords = 'none',
  onSelect,
  onKey,
  label,
  animKey,
  className,
}: Props) {
  const boardRef = useRef<HTMLDivElement>(null);
  const interactive = Boolean(onSelect);
  const keyboardMove = useRef(false);

  useEffect(() => {
    if (!keyboardMove.current || selected === null) return;
    keyboardMove.current = false;
    boardRef.current?.querySelector<HTMLElement>(`[data-index="${selected}"]`)?.focus();
  }, [selected]);

  const selRow = selected !== null ? Math.floor(selected / 9) : -1;
  const selCol = selected !== null ? selected % 9 : -1;
  const selBox = selected !== null ? boxOf(selected) : -1;
  const selValue = selected !== null ? values[selected] : 0;

  const onKeyDown = (e: KeyboardEvent<HTMLDivElement>) => {
    if (!interactive) return;
    const current = selected ?? 0;
    const moves: Record<string, number> = { ArrowUp: -9, ArrowDown: 9, ArrowLeft: -1, ArrowRight: 1 };
    if (e.key in moves) {
      e.preventDefault();
      let next = current;
      const r = Math.floor(current / 9);
      const c = current % 9;
      if (e.key === 'ArrowUp') next = ((r + 8) % 9) * 9 + c;
      if (e.key === 'ArrowDown') next = ((r + 1) % 9) * 9 + c;
      if (e.key === 'ArrowLeft') next = r * 9 + ((c + 8) % 9);
      if (e.key === 'ArrowRight') next = r * 9 + ((c + 1) % 9);
      keyboardMove.current = true;
      onSelect?.(next);
      return;
    }
    if (selected !== null && onKey?.(e, selected)) e.preventDefault();
  };

  const unitClass = (i: number): string | undefined => {
    const r = Math.floor(i / 9);
    const c = i % 9;
    const b = boxOf(i);
    let tone: string | undefined;
    for (const u of units) {
      if (u.row === r || u.col === c || u.box === b) tone = u.tone === 'clash' ? styles.unitClash : (tone ?? styles.unitScan);
    }
    return tone;
  };

  const colLabels = Array.from({ length: 9 }, (_, i) => `c${i + 1}`);
  const rowLabels = Array.from({ length: 9 }, (_, i) => `r${i + 1}`);

  return (
    <div className={`${styles.frame} ${coords !== 'none' ? styles.withCoords : ''} ${className ?? ''}`}>
      {coords !== 'none' && (
        <>
          <div className={styles.corner} aria-hidden="true" />
          <div className={styles.colLabels} aria-hidden="true">
            {colLabels.map((l, i) => (
              <span key={i} className={selCol === i ? styles.coordActive : undefined}>
                {l}
              </span>
            ))}
          </div>
          <div className={styles.rowLabels} aria-hidden="true">
            {rowLabels.map((l, i) => (
              <span key={i} className={selRow === i ? styles.coordActive : undefined}>
                {l}
              </span>
            ))}
          </div>
        </>
      )}
      <div
        ref={boardRef}
        className={`${styles.board} ${interactive ? styles.interactive : ''}`}
        role="grid"
        aria-label={label}
        aria-readonly={!interactive}
        onKeyDown={onKeyDown}
      >
        {Array.from({ length: 9 }, (_, r) => (
          <div role="row" key={r} className={styles.row}>
            {Array.from({ length: 9 }, (_, c) => {
              const i = r * 9 + c;
              const value = values[i];
              const given = givens[i];
              const mark = marks?.get(i);
              const isSelected = i === selected;
              const peer =
                showPeers && selected !== null && !isSelected && (r === selRow || c === selCol || boxOf(i) === selBox);
              const same = showPeers && selValue !== 0 && value === selValue && !isSelected;
              const noteMask = notes?.[i] ?? 0;
              const pencil = value === 0 ? (mark?.pencil ?? (noteMask ? digitsOf(noteMask) : undefined)) : undefined;
              const classes = [
                styles.cell,
                c % 3 === 2 && c < 8 && styles.boxRight,
                r % 3 === 2 && r < 8 && styles.boxBottom,
                given ? styles.given : value ? styles.entry : undefined,
                peer && styles.peer,
                same && styles.same,
                unitClass(i),
                mark?.tone && styles[`tone-${mark.tone}`],
                isSelected && styles.selected,
                i === focusCell && styles.focus,
              ]
                .filter(Boolean)
                .join(' ');
              return (
                <div
                  key={c}
                  role="gridcell"
                  data-index={i}
                  className={classes}
                  tabIndex={interactive ? (isSelected || (selected === null && i === 0) ? 0 : -1) : undefined}
                  aria-selected={interactive ? isSelected : undefined}
                  aria-label={cellLabel(r, c, value, given, mark)}
                  onClick={interactive ? () => onSelect?.(i) : undefined}
                  onFocus={interactive && !isSelected ? () => onSelect?.(i) : undefined}
                >
                  {value !== 0 ? (
                    <span
                      key={mark?.tone === 'placed' ? `p${animKey}` : 'v'}
                      className={`${styles.digit} ${mark?.tone === 'placed' ? styles.pop : ''}`}
                    >
                      {value}
                    </span>
                  ) : pencil ? (
                    <span className={`${styles.pencil} ${mark?.pencilTone === 'candidates' ? styles.pencilCandidates : ''}`} aria-hidden="true">
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((d) => (
                        <span key={d}>{pencil.includes(d) ? d : ''}</span>
                      ))}
                    </span>
                  ) : null}
                  {mark?.ghost !== undefined && (
                    <span
                      key={`g${animKey}`}
                      className={`${styles.ghost} ${styles[`ghost-${mark.ghostTone ?? 'trying'}`]}`}
                      aria-hidden="true"
                    >
                      {mark.ghost}
                    </span>
                  )}
                  {mark?.corner && (
                    <span className={styles.cornerLabel} aria-hidden="true">
                      {mark.corner}
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        ))}
        {link && <ConflictLink from={link.from} to={link.to} />}
      </div>
    </div>
  );
}

function ConflictLink({ from, to }: { from: number; to: number }) {
  const x1 = (from % 9) + 0.5;
  const y1 = Math.floor(from / 9) + 0.5;
  const x2 = (to % 9) + 0.5;
  const y2 = Math.floor(to / 9) + 0.5;
  return (
    <svg className={styles.link} viewBox="0 0 9 9" preserveAspectRatio="none" aria-hidden="true">
      <line x1={x1} y1={y1} x2={x2} y2={y2} />
      <circle cx={x2} cy={y2} r="0.42" />
    </svg>
  );
}

export function digitsOf(mask: number): number[] {
  const out: number[] = [];
  for (let d = 1; d <= 9; d++) if (mask & (1 << d)) out.push(d);
  return out;
}

function cellLabel(r: number, c: number, value: number, given: boolean, mark?: CellMark): string {
  const where = `Row ${r + 1}, column ${c + 1}`;
  const what = value === 0 ? 'empty' : given ? `clue ${value}` : `${value}`;
  const extra =
    mark?.tone === 'conflict'
      ? ', breaks a rule'
      : mark?.tone === 'wrong'
        ? ', does not match the solution'
        : mark?.ghost !== undefined
          ? `, solver considering ${mark.ghost}`
          : '';
  return `${where}: ${what}${extra}`;
}
