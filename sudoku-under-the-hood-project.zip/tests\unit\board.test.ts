import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { SudokuBoard, BoardError, type Grid } from '../../src/domain/SudokuBoard';
import { parsePuzzle, gridToString, gridFromString } from '../../src/domain/puzzleFormat';
import { CLASSIC, CLASSIC_SOLUTION, copy } from './helpers';

const code = (fn: () => unknown): string => {
  try {
    fn();
  } catch (error) {
    if (error instanceof BoardError) return error.code;
    throw error;
  }
  return 'NO_ERROR';
};

describe('initialization', () => {
  test('loads clues and empties', () => {
    const board = new SudokuBoard(CLASSIC);
    assert.equal(board.getCell(0, 0), 5);
    assert.equal(board.getCell(0, 2), 0);
    assert.equal(board.isGiven(0, 0), true);
    assert.equal(board.isGiven(0, 2), false);
    assert.equal(board.countEmpty(), 51);
    assert.deepEqual(board.getSnapshot(), CLASSIC);
  });

  test('rejects malformed input', () => {
    assert.equal(code(() => new SudokuBoard(CLASSIC.slice(0, 8))), 'MALFORMED');
    const tooBig = copy(CLASSIC);
    tooBig[4][4] = 10;
    assert.equal(code(() => new SudokuBoard(tooBig)), 'MALFORMED');
    const fraction = copy(CLASSIC);
    fraction[1][1] = 2.5;
    assert.equal(code(() => new SudokuBoard(fraction)), 'MALFORMED');
    const shortRow = copy(CLASSIC);
    shortRow[2] = shortRow[2].slice(0, 8);
    assert.equal(code(() => new SudokuBoard(shortRow)), 'MALFORMED');
  });

  test('text parser accepts layouts and reports errors', () => {
    const text = gridToString(CLASSIC);
    const spaced = text.replace(/(.{9})/g, '$1\n').replace(/(.{3})/g, '$1|');
    const parsed = parsePuzzle(spaced);
    assert.ok(parsed.ok);
    if (parsed.ok) assert.deepEqual(parsed.grid, CLASSIC);
    const short = parsePuzzle(text.slice(1));
    assert.ok(!short.ok && /80/.test(short.error));
    const bad = parsePuzzle(text.slice(1) + 'x');
    assert.ok(!bad.ok && /"x"/.test(bad.error));
  });
});

describe('access and updates', () => {
  test('setCell changes player cells and returns the old value', () => {
    const board = new SudokuBoard(CLASSIC);
    assert.equal(board.setCell(0, 2, 4), 0);
    assert.equal(board.getCell(0, 2), 4);
    assert.equal(board.setCell(0, 2, 0), 4);
    assert.equal(board.getCell(0, 2), 0);
  });

  test('invalid coordinates and values are rejected', () => {
    const board = new SudokuBoard(CLASSIC);
    assert.equal(code(() => board.getCell(-1, 0)), 'INDEX_OUT_OF_RANGE');
    assert.equal(code(() => board.getCell(0, 9)), 'INDEX_OUT_OF_RANGE');
    assert.equal(code(() => board.getCell(1.5, 0)), 'INDEX_OUT_OF_RANGE');
    assert.equal(code(() => board.setCell(0, 2, 10)), 'VALUE_OUT_OF_RANGE');
    assert.equal(code(() => board.setCell(0, 2, -1)), 'VALUE_OUT_OF_RANGE');
    assert.equal(code(() => board.findConflict(0, 2, 0)), 'VALUE_OUT_OF_RANGE');
    assert.equal(code(() => board.placeCandidate(0, 2, 12)), 'VALUE_OUT_OF_RANGE');
  });

  test('starting clues cannot be changed by the player or the solver', () => {
    const board = new SudokuBoard(CLASSIC);
    assert.equal(code(() => board.setCell(0, 0, 1)), 'GIVEN_CELL');
    assert.equal(code(() => board.setCell(0, 0, 0)), 'GIVEN_CELL');
    assert.equal(code(() => board.placeCandidate(0, 0, 1)), 'GIVEN_CELL');
    assert.equal(board.getCell(0, 0), 5);
  });

  test('the internal array cannot be reached or changed from outside', () => {
    const board = new SudokuBoard(CLASSIC);
    assert.deepEqual(Object.keys(board), []);
    const snapshot = board.getSnapshot() as number[][];
    assert.ok(Object.isFrozen(snapshot) && Object.isFrozen(snapshot[0]));
    assert.throws(() => {
      snapshot[0][2] = 9;
    }, TypeError);
    assert.equal(board.getCell(0, 2), 0);
  });
});

describe('rule checking', () => {
  const board = new SudokuBoard(CLASSIC);

  test('row constraint', () => {
    // r1 already has 5 at c1.
    assert.deepEqual(board.findConflict(0, 2, 5), { kind: 'row', at: { row: 0, col: 0 }, value: 5 });
  });

  test('column constraint', () => {
    // c3 has 8 at r3, and row 1 has no 8.
    assert.deepEqual(board.findConflict(0, 2, 8), { kind: 'column', at: { row: 2, col: 2 }, value: 8 });
  });

  test('box constraint', () => {
    // Top-left box has 9 at r3c2; row 1 and column 3 have no 9.
    assert.deepEqual(board.findConflict(0, 2, 9), { kind: 'box', at: { row: 2, col: 1 }, value: 9 });
  });

  test('a legal digit has no conflict, and a cell does not conflict with itself', () => {
    assert.equal(board.findConflict(0, 2, 4), null);
    assert.equal(board.isValid(0, 2, 4), true);
    assert.equal(board.isValid(0, 0, 5), true);
  });

  test('getCandidates agrees with isValid for every empty cell', () => {
    for (let row = 0; row < 9; row++) {
      for (let col = 0; col < 9; col++) {
        if (board.getCell(row, col) !== 0) {
          assert.deepEqual(board.getCandidates(row, col), []);
          continue;
        }
        const expected = [1, 2, 3, 4, 5, 6, 7, 8, 9].filter((d) => board.isValid(row, col, d));
        assert.deepEqual(board.getCandidates(row, col), expected);
      }
    }
  });

  test('findEmptyCell scans in row-major order', () => {
    const b = new SudokuBoard(CLASSIC);
    assert.deepEqual(b.findEmptyCell(), { row: 0, col: 2 });
    b.setCell(0, 2, 4);
    assert.deepEqual(b.findEmptyCell(), { row: 0, col: 3 });
    assert.equal(new SudokuBoard(CLASSIC_SOLUTION).findEmptyCell(), null);
  });
});

describe('completion', () => {
  test('a solved grid is complete and solved', () => {
    const board = new SudokuBoard(CLASSIC_SOLUTION);
    assert.equal(board.isComplete(), true);
    assert.equal(board.isSolved(), true);
  });

  test('a full grid with a mistake is complete but not solved', () => {
    const wrong = copy(CLASSIC_SOLUTION);
    [wrong[0][0], wrong[0][1]] = [wrong[0][1], wrong[0][0]];
    const board = new SudokuBoard(wrong);
    assert.equal(board.isComplete(), true);
    assert.equal(board.isSolved(), false);
  });

  test('a full grid of one repeated row pattern is not solved', () => {
    const rows: Grid = Array.from({ length: 9 }, () => [1, 2, 3, 4, 5, 6, 7, 8, 9]);
    const board = new SudokuBoard(rows);
    assert.equal(board.isComplete(), true);
    assert.equal(board.isSolved(), false);
  });

  test('an incomplete board is neither', () => {
    const board = new SudokuBoard(CLASSIC);
    assert.equal(board.isComplete(), false);
    assert.equal(board.isSolved(), false);
  });
});

describe('puzzle validation', () => {
  test('a legal puzzle passes', () => {
    const report = new SudokuBoard(CLASSIC).validatePuzzle();
    assert.equal(report.ok, true);
    assert.equal(report.clueCount, 30);
  });

  test('duplicate clues are reported', () => {
    const bad = copy(CLASSIC);
    bad[0][2] = 5; // second 5 in row 1 (and box 1)
    const report = new SudokuBoard(bad).validatePuzzle();
    assert.equal(report.ok, false);
    assert.ok(report.conflicts.some((c) => c.kind === 'row' && c.value === 5));
  });

  test('validatePuzzle checks clues only, findAllConflicts checks the current board', () => {
    const board = new SudokuBoard(CLASSIC);
    board.setCell(0, 2, 3); // r1 already has 3 at c2
    assert.equal(board.validatePuzzle().ok, true);
    const conflicts = board.findAllConflicts();
    assert.ok(conflicts.some((c) => c.kind === 'row' && c.value === 3));
  });
});

describe('solver placements', () => {
  test('placeCandidate refuses occupied cells and illegal digits', () => {
    const board = new SudokuBoard(CLASSIC);
    assert.equal(code(() => board.placeCandidate(0, 2, 5)), 'ILLEGAL_PLACEMENT');
    board.placeCandidate(0, 2, 4);
    assert.equal(code(() => board.placeCandidate(0, 2, 1)), 'CELL_OCCUPIED');
  });

  test('undoPlacement is last-in, first-out', () => {
    const board = new SudokuBoard(CLASSIC);
    board.placeCandidate(0, 2, 4);
    board.placeCandidate(0, 3, 6);
    assert.equal(board.placementCount(), 2);
    assert.equal(code(() => board.undoPlacement(0, 2)), 'UNDO_ORDER');
    board.undoPlacement(0, 3);
    board.undoPlacement(0, 2);
    assert.equal(board.placementCount(), 0);
    assert.deepEqual(board.getSnapshot(), CLASSIC);
    assert.equal(code(() => board.undoPlacement(0, 2)), 'UNDO_ORDER');
  });

  test('reset restores the original puzzle and clears placements', () => {
    const board = new SudokuBoard(CLASSIC);
    board.setCell(0, 2, 4);
    board.placeCandidate(0, 3, 6);
    board.reset();
    assert.deepEqual(board.getSnapshot(), CLASSIC);
    assert.equal(board.placementCount(), 0);
    assert.equal(gridToString(board.getOriginal()), gridToString(gridFromString(gridToString(CLASSIC))));
  });
});
