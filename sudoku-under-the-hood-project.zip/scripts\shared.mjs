// Shared esbuild configuration and HTML template for dev and production builds.
import { readFile } from 'node:fs/promises';
import path from 'node:path';

/** `import text from './file.ts?raw'` bundles the file's exact source text. */
export const rawPlugin = {
  name: 'raw-source',
  setup(build) {
    build.onResolve({ filter: /\?raw$/ }, (args) => ({
      path: path.resolve(args.resolveDir, args.path.replace(/\?raw$/, '')),
      namespace: 'raw-source',
    }));
    build.onLoad({ filter: /.*/, namespace: 'raw-source' }, async (args) => ({
      contents: await readFile(args.path, 'utf8'),
      loader: 'text',
      watchFiles: [args.path],
    }));
  },
};

export const baseOptions = {
  entryPoints: ['src/main.tsx'],
  bundle: true,
  format: 'esm',
  target: ['es2022', 'chrome111', 'firefox115', 'safari16.4'],
  jsx: 'automatic',
  // Fonts are inlined as data: URLs so the page needs no network access.
  loader: { '.json': 'json', '.woff2': 'dataurl' },
  plugins: [rawPlugin],
  logLevel: 'info',
};

export const TITLE = 'Sudoku: Under the Hood';

/**
 * The page content shared by every build: head elements, then the app root and script.
 * Returns { head, body } so callers can wrap them in a full document or publish them as-is.
 */
export function pageParts({ css, js, cssHref, jsSrc }) {
  const head = [
    `<title>${TITLE}</title>`,
    '<meta name="claude:viewport-fit-sides" content="cover">',
    '<meta name="description" content="Play the puzzle. Discover the algorithm. An interactive Data Structures and Algorithms lab built on a real Sudoku solver.">',
    cssHref ? `<link rel="stylesheet" href="${cssHref}">` : `<style>\n${css}\n</style>`,
  ].join('\n');
  const script = jsSrc
    ? `<script type="module" src="${jsSrc}"></script>`
    : `<script type="module">\n${js.replace(/<\/script/gi, '<\\/script')}\n</script>`;
  const body = ['<div id="root"></div>', script].join('\n');
  return { head, body };
}

/** A complete HTML document (for opening locally or hosting anywhere). */
export function fullDocument({ head, body }, extraHead = '') {
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
${head}
${extraHead}
</head>
<body>
${body}
</body>
</html>
`;
}
