/**
 * Difficulty rating by the human techniques a puzzle needs.
 *
 * The rater solves the puzzle the way a person would, always using the
 * simplest technique that makes progress, and records the hardest one used:
 *
 *   easy    — naked singles only (a cell with exactly one candidate)
 *   medium  — also needs hidden singles (a digit with one possible cell in a unit)
 *   hard    — also needs candidate eliminations (locked candidates, naked pairs)
 *   expert  — these techniques get stuck; finishing needs trial and error (search)
 *
 * The bundled puzzles' labels come from this function, and a test re-rates
 * every puzzle to confirm them.
 */
import { SIZE, BOX, EMPTY, type Grid } from './SudokuBoard';

export type Difficulty = 'easy' | 'medium' | 'hard' | 'expert';

export interface Rating {
  readonly difficulty: Difficulty;
  /** Deductions made with each technique. */
  readonly counts: { nakedSingles: number; hiddenSingles: number; eliminations: number };
  /** Cells still empty when the techniques ran out (0 unless expert). */
  readonly remaining: number;
  /** True when the rater hit a cell with no candidates (contradictory puzzle). */
  readonly contradiction: boolean;
}

const ALL = 0b1111111110;

const UNITS: number[][] = (() => {
  const units: number[][] = [];
  for (let i = 0; i < SIZE; i++) {
    const row: number[] = [];
    const col: number[] = [];
    const box: number[] = [];
    for (let j = 0; j < SIZE; j++) {
      row.push(i * SIZE + j);
      col.push(j * SIZE + i);
      const r = BOX * Math.floor(i / BOX) + Math.floor(j / BOX);
      const c = BOX * (i % BOX) + (j % BOX);
      box.push(r * SIZE + c);
    }
    units.push(row, col, box);
  }
  return units;
})();

const PEERS: number[][] = Array.from({ length: SIZE * SIZE }, (_, i) => {
  const set = new Set<number>();
  for (const unit of UNITS) if (unit.includes(i)) unit.forEach((j) => j !== i && set.add(j));
  return [...set];
});

const bitCount = (mask: number): number => {
  let n = 0;
  while (mask) {
    mask &= mask - 1;
    n++;
  }
  return n;
};
const onlyDigit = (mask: number): number => Math.log2(mask);

export function ratePuzzle(grid: Grid): Rating {
  const values = grid.flat();
  const cand = values.map(() => ALL);
  const counts = { nakedSingles: 0, hiddenSingles: 0, eliminations: 0 };
  let contradiction = false;

  const place = (i: number, digit: number) => {
    values[i] = digit;
    cand[i] = 0;
    for (const p of PEERS[i]) cand[p] &= ~(1 << digit);
  };
  for (let i = 0; i < values.length; i++) {
    if (values[i] !== EMPTY) {
      const digit = values[i];
      cand[i] = 0;
      for (const p of PEERS[i]) cand[p] &= ~(1 << digit);
    }
  }
  for (let i = 0; i < values.length; i++) {
    if (values[i] !== EMPTY) {
      for (const p of PEERS[i]) if (values[p] === values[i]) contradiction = true;
    }
  }

  let level = 0;
  for (;;) {
    if (contradiction) break;
    if (values.some((v, i) => v === EMPTY && cand[i] === 0)) {
      contradiction = true;
      break;
    }
    if (!values.includes(EMPTY)) break;

    const naked = values.findIndex((v, i) => v === EMPTY && bitCount(cand[i]) === 1);
    if (naked !== -1) {
      place(naked, onlyDigit(cand[naked]));
      counts.nakedSingles++;
      level = Math.max(level, 1);
      continue;
    }
    if (hiddenSingle(values, cand, place)) {
      counts.hiddenSingles++;
      level = Math.max(level, 2);
      continue;
    }
    if (lockedCandidates(values, cand) || nakedPairs(values, cand)) {
      counts.eliminations++;
      level = Math.max(level, 3);
      continue;
    }
    break;
  }

  const remaining = values.filter((v) => v === EMPTY).length;
  const difficulty: Difficulty =
    remaining > 0 || contradiction ? 'expert' : level <= 1 ? 'easy' : level === 2 ? 'medium' : 'hard';
  return { difficulty, counts, remaining, contradiction };
}

function hiddenSingle(values: number[], cand: number[], place: (i: number, d: number) => void): boolean {
  for (const unit of UNITS) {
    for (let digit = 1; digit <= SIZE; digit++) {
      const bit = 1 << digit;
      if (unit.some((i) => values[i] === digit)) continue;
      const spots = unit.filter((i) => values[i] === EMPTY && cand[i] & bit);
      if (spots.length === 1) {
        place(spots[0], digit);
        return true;
      }
    }
  }
  return false;
}

/** Pointing and claiming: a digit confined to one box-line intersection. */
function lockedCandidates(values: number[], cand: number[]): boolean {
  let changed = false;
  const boxes = UNITS.filter((_, k) => k % 3 === 2);
  const lines = UNITS.filter((_, k) => k % 3 !== 2);
  for (let digit = 1; digit <= SIZE; digit++) {
    const bit = 1 << digit;
    for (const box of boxes) {
      for (const line of lines) {
        const inter = box.filter((i) => line.includes(i));
        if (inter.length === 0) continue;
        const has = (i: number) => values[i] === EMPTY && (cand[i] & bit) !== 0;
        const inInter = inter.some(has);
        if (!inInter) continue;
        const boxRest = box.filter((i) => !inter.includes(i));
        const lineRest = line.filter((i) => !inter.includes(i));
        if (!boxRest.some(has) && lineRest.some(has)) {
          lineRest.forEach((i) => (cand[i] &= ~bit));
          changed = true;
        }
        if (!lineRest.some(has) && boxRest.some(has)) {
          boxRest.forEach((i) => (cand[i] &= ~bit));
          changed = true;
        }
        if (changed) return true;
      }
    }
  }
  return changed;
}

function nakedPairs(values: number[], cand: number[]): boolean {
  for (const unit of UNITS) {
    const pairs = unit.filter((i) => values[i] === EMPTY && bitCount(cand[i]) === 2);
    for (let x = 0; x < pairs.length; x++) {
      for (let y = x + 1; y < pairs.length; y++) {
        const mask = cand[pairs[x]];
        if (mask !== cand[pairs[y]]) continue;
        let changed = false;
        for (const i of unit) {
          if (i === pairs[x] || i === pairs[y] || values[i] !== EMPTY) continue;
          if (cand[i] & mask) {
            cand[i] &= ~mask;
            changed = true;
          }
        }
        if (changed) return true;
      }
    }
  }
  return false;
}
