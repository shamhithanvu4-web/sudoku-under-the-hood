/** A 3×3 box with one cell filled: the board, and the one decision being made. */
export function Logo({ size = 30 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 30 30" aria-hidden="true">
      <rect x="1" y="1" width="28" height="28" rx="2" fill="#fff" stroke="#303630" strokeWidth="2" />
      <path d="M10.3 1v28M19.7 1v28M1 10.3h28M1 19.7h28" stroke="#bcc4b3" strokeWidth="1" />
      <rect x="10.8" y="10.8" width="8.4" height="8.4" fill="#657451" />
      <path d="M20.8 4.2h5M23.3 4.2v4.6" stroke="#b07a1e" strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  );
}
