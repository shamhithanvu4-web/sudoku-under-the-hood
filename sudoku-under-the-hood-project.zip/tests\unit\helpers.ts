/**
 * Test helpers. `isValidSolution` is written independently of the board ADT
 * so tests do not trust the code they are checking.
 */
import puzzleData from '../../src/data/puzzles.json';
import { gridFromString } from '../../src/domain/puzzleFormat';
import type { Grid } from '../../src/domain/SudokuBoard';

export const data = puzzleData as {
  demoId: string;
  puzzles: { id: string; name: string; difficulty: string; givens: string }[];
  lessons: { id: string; givens: string }[];
  lab: { id: string; givens: string }[];
};

export const CLASSIC = gridFromString(
  '53..7....6..195....98....6.8...6...34..8.3..17...2...6.6....28....419..5....8..79',
);
export const CLASSIC_SOLUTION = gridFromString(
  '534678912672195348198342567859761423426853791713924856961537284287419635345286179',
);

export function puzzle(id: string): Grid {
  const all = [...data.puzzles, ...data.lessons, ...data.lab];
  const found = all.find((p) => p.id === id);
  if (!found) throw new Error(`No puzzle ${id}`);
  return gridFromString(found.givens);
}

/** Every row, column and 3×3 box contains exactly the digits 1–9. */
export function isValidSolution(grid: Grid): boolean {
  const full = (values: number[]) => values.slice().sort().join('') === '123456789';
  for (let i = 0; i < 9; i++) {
    const row = grid[i].slice();
    const col = grid.map((r) => r[i]);
    const box: number[] = [];
    for (let j = 0; j < 9; j++) {
      box.push(grid[3 * Math.floor(i / 3) + Math.floor(j / 3)][3 * (i % 3) + (j % 3)]);
    }
    if (!full(row) || !full(col) || !full(box)) return false;
  }
  return true;
}

/** Every clue of `puzzle` is unchanged in `solution`. */
export function keepsClues(puzzle: Grid, solution: Grid): boolean {
  return puzzle.every((row, r) => row.every((v, c) => v === 0 || solution[r][c] === v));
}

export function copy(grid: Grid): number[][] {
  return grid.map((row) => [...row]);
}
