// Development server with rebuild-on-save and automatic page reload.
//   npm run dev   →   http://localhost:5173
import * as esbuild from 'esbuild';
import { mkdir, writeFile } from 'node:fs/promises';
import { baseOptions, pageParts, fullDocument } from './shared.mjs';

const dir = '.dev';
await mkdir(dir, { recursive: true });
const reload = `<script>new EventSource('/esbuild').addEventListener('change', () => location.reload());</script>`;
await writeFile(`${dir}/index.html`, fullDocument(pageParts({ cssHref: '/main.css', jsSrc: '/main.js' }), reload));

const ctx = await esbuild.context({
  ...baseOptions,
  outdir: dir,
  sourcemap: true,
  define: { 'process.env.NODE_ENV': '"development"' },
});
await ctx.watch();
const port = Number(process.env.PORT ?? 5173);
const { hosts } = await ctx.serve({ servedir: dir, port });
console.log(`Sudoku: Under the Hood → http://${hosts[0] === '0.0.0.0' ? 'localhost' : hosts[0]}:${port}`);
