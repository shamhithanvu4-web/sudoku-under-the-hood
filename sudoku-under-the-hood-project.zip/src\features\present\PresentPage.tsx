import { useEffect, useMemo, useState } from 'react';
import { useApp } from '../../app/AppState';
import { Logo } from '../../app/Logo';
import { BUNDLED, DEMO_ID } from '../../app/puzzles';
import { GameSession } from '../play/gameSession';
import { Button } from '../../components/Button';
import { MessageBar } from '../../components/MessageBar';
import { Segmented } from '../../components/Segmented';
import guide from '../../data/presenterGuide.json';
import { explainEvent } from '../../explain/explain';
import { SOURCES } from '../../explain/sources';
import type { SolverKind } from '../../solver/types';
import { SudokuGrid } from '../board/SudokuGrid';
import { buildBoardView } from '../guided/boardView';
import { CATEGORY } from '../guided/eventStyle';
import { PlaybackControls } from '../guided/PlaybackControls';
import { useGuidedRun, usePlaybackKeys } from '../guided/useGuidedRun';
import { NumberPad, PlayTools } from '../play/PlayControls';
import { usePlayController } from '../play/usePlayController';
import guidedStyles from '../guided/Guided.module.css';
import styles from './Present.module.css';

type Mode = 'play' | 'solve';

function freshDemoSession(): GameSession {
  const demo = BUNDLED.find((p) => p.id === DEMO_ID)!;
  return new GameSession(demo.grid, { id: demo.id, name: demo.name, difficulty: demo.difficulty });
}
const fmt = (n: number) => n.toLocaleString('en-US');

export function PresentPage() {
  const { navigate, selectPuzzle, puzzle } = useApp();
  // Every visit to Present starts on a fresh copy of the classroom demo board,
  // separate from anything entered in Play mode.
  const [demoSession, setDemoSession] = useState(freshDemoSession);
  useEffect(() => {
    selectPuzzle(DEMO_ID);
  }, [selectPuzzle]);
  const [mode, setMode] = useState<Mode>('play');
  const [kind, setKind] = useState<SolverKind>('backtracking');
  const [guideOpen, setGuideOpen] = useState(false);
  const [guideStep, setGuideStep] = useState<number | null>(null);
  const [showCode, setShowCode] = useState(true);
  const [fullscreen, setFullscreen] = useState(false);

  const play = usePlayController(demoSession);
  const { trace, result, running, playback: p } = useGuidedRun(kind, 'original');
  usePlaybackKeys(p, mode === 'solve');

  useEffect(() => {
    const sync = () => setFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', sync);
    return () => document.removeEventListener('fullscreenchange', sync);
  }, []);

  const toggleFullscreen = () => {
    try {
      if (document.fullscreenElement) void document.exitFullscreen().catch(() => undefined);
      else void document.documentElement.requestFullscreen?.().catch(() => undefined);
    } catch {
      /* Full screen is not available here; the layout already fills the window. */
    }
  };

  const view = useMemo(() => (trace ? buildBoardView(trace, p.index, { depthLabels: true, candidateCounts: false }) : null), [trace, p.index]);
  const event = trace && p.index >= 0 ? trace.events[p.index] : null;
  const x = event && trace ? explainEvent(trace, p.index, kind) : null;
  const stats = trace ? trace.statsAt(p.index) : null;
  const codeLines = event ? (SOURCES[kind].view.steps.get(event.step) ?? []).map((n) => `${String(n).padStart(3)}  ${SOURCES[kind].view.lines[n - 1].trim()}`) : [];

  const act = (action: string | null) => {
    if (!action) return;
    if (action === 'play') {
      selectPuzzle(DEMO_ID);
      setDemoSession(freshDemoSession());
      setMode('play');
      return;
    }
    setMode('solve');
    if (!trace) return;
    const first = (type: string, from = -1) => trace.findNext(from, (e) => e.type === type);
    if (action === 'solve-start') {
      p.setPauseOn(new Set());
      p.setIndex(-1);
      p.setPlaying(true);
    } else if (action === 'first-reject') {
      p.setPlaying(false);
      p.setIndex(first('VALIDATION_FAILED'));
    } else if (action === 'first-accept') {
      p.setPlaying(false);
      p.setIndex(first('VALIDATION_PASSED'));
    } else if (action === 'to-backtrack') {
      p.setPauseOn(new Set(['BACKTRACK']));
      p.setPlaying(true);
    } else if (action === 'show-code') {
      p.setPlaying(false);
      setShowCode(true);
      const at = first('BACKTRACK', p.index - 1);
      p.setIndex(at >= 0 ? at : first('BACKTRACK'));
    } else if (action === 'finish') {
      p.setPauseOn(new Set());
      p.setSpeed(250);
      p.setPlaying(true);
    } else if (action === 'stats') {
      p.setPlaying(false);
      p.setIndex(trace.length - 1);
    }
  };

  return (
    <div className={`${styles.screen} ${guideOpen ? styles.withGuide : ''}`}>
      <div className={styles.bar}>
        <span className={styles.brand}>
          <Logo size={26} /> Under the Hood
        </span>
        <Segmented
          size="lg"
          label="Presentation mode"
          value={mode}
          onChange={setMode}
          options={[
            { value: 'play', label: 'Play' },
            { value: 'solve', label: 'Solve' },
          ]}
        />
        {mode === 'solve' && (
          <Segmented
            label="Solver"
            value={kind}
            onChange={setKind}
            options={[
              { value: 'backtracking', label: 'Plain' },
              { value: 'mrv', label: 'MRV' },
            ]}
          />
        )}
        <span className="label">{puzzle.name}</span>
        <span className={styles.spacer} />
        <Button
          icon="reset"
          onClick={() => {
            selectPuzzle(DEMO_ID);
            setDemoSession(freshDemoSession());
            p.setIndex(-1);
            p.setPlaying(false);
          }}
        >
          Reset demo
        </Button>
        <Button icon="guide" active={guideOpen} onClick={() => setGuideOpen(!guideOpen)}>
          Guide
        </Button>
        <Button icon={fullscreen ? 'collapse' : 'expand'} onClick={toggleFullscreen}>
          {fullscreen ? 'Exit full screen' : 'Full screen'}
        </Button>
        <Button variant="ghost" icon="close" onClick={() => navigate('solve')}>
          Exit
        </Button>
      </div>

      <main className={styles.stage}>
        <div className={styles.boardSide}>
          {mode === 'play' ? (
            <SudokuGrid
              label="Classroom board"
              values={play.view.values}
              givens={play.view.givens}
              notes={play.view.notes}
              marks={play.marks}
              selected={play.selected}
              onSelect={play.setSelected}
              onKey={play.onKey}
              showPeers
              coords="sudoku"
            />
          ) : view ? (
            <SudokuGrid
              label="Solver board"
              values={view.values}
              givens={view.givens}
              marks={view.marks}
              focusCell={view.focusCell}
              units={view.units}
              link={view.link}
              coords="sudoku"
              animKey={p.index}
            />
          ) : (
            <p className={guidedStyles.placeholder}>{running ? 'Recording the solver…' : result?.message}</p>
          )}
        </div>

        <div className={styles.panel}>
          {mode === 'play' ? (
            <>
              <h1 className={styles.eventTitle}>Solve it together</h1>
              <p className={styles.eventText}>
                Every row, column and 3×3 box needs the digits 1 to 9. Ask the room: which cell is the easiest place to start, and why?
              </p>
              <NumberPad c={play} size="lg" />
              <PlayTools c={play} />
              <MessageBar message={play.message} placeholder="Click a cell, then a digit." />
              <div>
                <Button size="lg" variant="primary" icon="arrowRight" onClick={() => setMode('solve')}>
                  Now let the computer try
                </Button>
              </div>
            </>
          ) : (
            <>
              <div className={guidedStyles.explainHead}>
                {event ? (
                  <span className={`${guidedStyles.badge} ${styles.big}`} data-cat={CATEGORY[event.type]}>
                    {event.type}
                  </span>
                ) : (
                  <span className="label">Ready</span>
                )}
                {event && event.callId >= 0 && <span className={guidedStyles.depthTag}>depth {event.depth}</span>}
              </div>
              <h1 className={styles.eventTitle}>{x ? x.title : 'Press Start to replay the solver'}</h1>
              <p className={styles.eventText}>
                {x ? x.concise : 'The run has already been recorded. Every step you will see is a real operation of the recursive solver.'}
              </p>
              {showCode && codeLines.length > 0 && <div className={styles.codeStrip}>{codeLines.join('\n')}</div>}
              {x && (
                <span className={styles.concept}>
                  <span className="label">DSA concept</span> <strong>{x.concept}</strong>
                </span>
              )}
              {trace && <PlaybackControls p={p} size="lg" />}
              {stats && (
                <div className={styles.stats}>
                  <div className={styles.stat}>
                    <span>Recursive calls</span>
                    <strong>{fmt(stats.recursiveCalls)}</strong>
                  </div>
                  <div className={styles.stat}>
                    <span>Digits tried</span>
                    <strong>{fmt(stats.candidateAttempts)}</strong>
                  </div>
                  <div className={styles.stat}>
                    <span>Backtracks</span>
                    <strong>{fmt(stats.backtracks)}</strong>
                  </div>
                  <div className={styles.stat}>
                    <span>Max depth</span>
                    <strong>{fmt(stats.maxDepth)}</strong>
                  </div>
                </div>
              )}
              <label className={guidedStyles.check}>
                <input type="checkbox" checked={showCode} onChange={(e) => setShowCode(e.target.checked)} />
                Show the line of code for each step
              </label>
            </>
          )}
        </div>
      </main>

      {guideOpen && (
        <aside className={styles.guide} aria-label="Presenter guide">
          <div className={styles.guideHead}>
            <span className="label">Suggested flow · optional</span>
            <Button size="sm" variant="ghost" iconOnly icon="close" label="Close guide" onClick={() => setGuideOpen(false)} />
          </div>
          <ol className={styles.guideList}>
            {guide.map((g, i) => (
              <li key={g.title} className={styles.guideItem} data-current={guideStep === i}>
                <span className={styles.guideNo}>{String(i + 1).padStart(2, '0')}</span>
                <div>
                  <strong>{g.title}</strong>
                  <p>{g.say}</p>
                  {g.action && (
                    <Button
                      size="sm"
                      onClick={() => {
                        setGuideStep(i);
                        act(g.action);
                      }}
                    >
                      Set up this step
                    </Button>
                  )}
                </div>
              </li>
            ))}
          </ol>
        </aside>
      )}
    </div>
  );
}
