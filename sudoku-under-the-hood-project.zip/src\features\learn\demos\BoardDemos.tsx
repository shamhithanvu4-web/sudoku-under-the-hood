import { useMemo, useState } from 'react';
import { useApp } from '../../../app/AppState';
import { Button } from '../../../components/Button';
import { SudokuBoard, cellName, type Grid } from '../../../domain/SudokuBoard';
import { selectMRVCell } from '../../../solver/mrvSolver';
import { PuzzlePicker } from '../../board/PuzzlePicker';
import { SudokuGrid, type CellMark, type UnitHighlight } from '../../board/SudokuGrid';
import { MemoryStrip } from '../../guided/MemoryStrip';
import { demoGrid } from './AdtDemos';
import styles from '../Learn.module.css';

/** Lesson 4: indices of a cell in the 2D array, in flat memory and in its box. */
export function IndexingDemo() {
  const cells = demoGrid().flat();
  const givens = cells.map((v) => v !== 0);
  const [sel, setSel] = useState(33);
  const r = Math.floor(sel / 9);
  const c = sel % 9;
  const box = Math.floor(r / 3) * 3 + Math.floor(c / 3);
  return (
    <div className={styles.demo}>
      <div className={styles.demoBoard}>
        <SudokuGrid label="Indexing demo board" values={cells} givens={givens} selected={sel} onSelect={setSel} showPeers coords="sudoku" />
      </div>
      <div className={styles.demoSide}>
        <dl className={styles.facts}>
          <dt>Sudoku name</dt>
          <dd>{cellName({ row: r, col: c })} (row {r + 1}, column {c + 1})</dd>
          <dt>2D array</dt>
          <dd>
            grid[{r}][{c}] = {cells[sel]}
          </dd>
          <dt>row-major index</dt>
          <dd>
            {r} × 9 + {c} = {sel}
          </dd>
          <dt>box number</dt>
          <dd>
            ⌊{r}/3⌋ × 3 + ⌊{c}/3⌋ = {box}
          </dd>
          <dt>box starts at</dt>
          <dd>
            grid[{r} − {r % 3}][{c} − {c % 3}] = grid[{r - (r % 3)}][{c - (c % 3)}]
          </dd>
          <dt>peers</dt>
          <dd>8 in the row + 8 in the column + 4 more in the box = 20</dd>
        </dl>
        <MemoryStrip values={cells} givens={givens} focus={sel} />
      </div>
    </div>
  );
}

/** Lesson 5: a live findConflict() call for any cell and digit. */
export function ConstraintsDemo() {
  const grid = demoGrid();
  const board = useMemo(() => new SudokuBoard(grid), [grid]);
  const cells = grid.flat();
  const [sel, setSel] = useState(2);
  const [digit, setDigit] = useState(1);
  const r = Math.floor(sel / 9);
  const c = sel % 9;
  const conflict = board.findConflict(r, c, digit);
  const box = Math.floor(r / 3) * 3 + Math.floor(c / 3);
  const units: UnitHighlight[] = conflict
    ? [{ ...(conflict.kind === 'row' ? { row: r } : conflict.kind === 'column' ? { col: c } : { box }), tone: 'clash' }]
    : [{ row: r, col: c, box, tone: 'scan' }];
  const marks = new Map<number, CellMark>();
  if (cells[sel] === 0) marks.set(sel, { ghost: digit, ghostTone: conflict ? 'rejected' : 'accepted' });
  if (conflict) marks.set(conflict.at.row * 9 + conflict.at.col, { tone: 'clash-source' });
  return (
    <div className={styles.demo}>
      <div className={styles.demoBoard}>
        <SudokuGrid
          label="Constraint demo board"
          values={cells}
          givens={cells.map((v) => v !== 0)}
          selected={sel}
          onSelect={setSel}
          units={units}
          marks={marks}
          link={conflict ? { from: sel, to: conflict.at.row * 9 + conflict.at.col } : null}
          animKey={sel * 10 + digit}
        />
      </div>
      <div className={styles.demoSide}>
        <div className={styles.controls} role="group" aria-label="Digit to check">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((d) => (
            <Button key={d} size="sm" active={d === digit} onClick={() => setDigit(d)}>
              {d}
            </Button>
          ))}
        </div>
        <div className={styles.console}>
          <div>
            <span className={styles.prompt}>&gt; </span>board.findConflict({r}, {c}, {digit})
          </div>
          <div className={conflict ? styles.err : styles.ok}>
            {conflict
              ? `{ kind: '${conflict.kind}', at: { row: ${conflict.at.row}, col: ${conflict.at.col} } }`
              : 'null'}
          </div>
        </div>
        <p className={styles.eventLine}>
          {conflict
            ? `${digit} cannot go at ${cellName({ row: r, col: c })}: ${cellName(conflict.at)} already holds ${digit} in the same ${conflict.kind}.`
            : `${digit} breaks none of the three rules at ${cellName({ row: r, col: c })}.`}
          {cells[sel] !== 0 && ` (This cell holds ${cells[sel]} in the puzzle; findConflict ignores the cell itself.)`}
        </p>
      </div>
    </div>
  );
}

/** Lesson 8: candidates for every empty cell, and filling forced cells round by round. */
export function CandidatesDemo() {
  const [grid, setGrid] = useState<Grid>(demoGrid);
  const [round, setRound] = useState(0);
  const [lastFilled, setLastFilled] = useState<number[]>([]);
  const board = useMemo(() => new SudokuBoard(grid), [grid]);
  const cells = grid.flat();
  const original = demoGrid().flat();
  const candidates = cells.map((v, i) => (v === 0 ? board.getCandidates(Math.floor(i / 9), i % 9) : []));
  const singles = candidates.map((cs, i) => (cells[i] === 0 && cs.length === 1 ? i : -1)).filter((i) => i >= 0);
  const marks = new Map<number, CellMark>();
  cells.forEach((v, i) => {
    if (v === 0) marks.set(i, { pencil: candidates[i], pencilTone: singles.includes(i) ? 'candidates' : 'notes', tone: singles.includes(i) ? 'placed' : undefined });
    else if (original[i] === 0) marks.set(i, { tone: lastFilled.includes(i) ? 'placed' : 'solver' });
  });
  const empty = cells.filter((v) => v === 0).length;
  const fill = () => {
    const next = grid.map((row) => [...row]);
    singles.forEach((i) => (next[Math.floor(i / 9)][i % 9] = candidates[i][0]));
    setLastFilled(singles);
    setGrid(next);
    setRound((n) => n + 1);
  };
  return (
    <div className={styles.demo}>
      <div className={styles.demoBoard}>
        <SudokuGrid label="Candidates demo board" values={cells} givens={original.map((v) => v !== 0)} marks={marks} animKey={round} />
      </div>
      <div className={styles.demoSide}>
        <dl className={styles.facts}>
          <dt>round</dt>
          <dd>{round}</dd>
          <dt>empty cells</dt>
          <dd>{empty}</dd>
          <dt>forced cells now</dt>
          <dd>{singles.length ? singles.map((i) => `${cellName({ row: Math.floor(i / 9), col: i % 9 })}=${candidates[i][0]}`).join('  ') : 'none'}</dd>
        </dl>
        <div className={styles.controls}>
          <Button size="sm" variant="primary" onClick={fill} disabled={singles.length === 0}>
            Fill {singles.length} forced {singles.length === 1 ? 'cell' : 'cells'}
          </Button>
          <Button size="sm" variant="ghost" icon="reset" onClick={() => { setGrid(demoGrid()); setRound(0); setLastFilled([]); }}>
            Start over
          </Button>
        </div>
        <p className={styles.eventLine}>
          {empty === 0
            ? 'Solved by propagation alone: no guessing was needed.'
            : singles.length === 0
              ? 'No forced cells are left. From here a solver has to guess and be ready to backtrack, or use subtler reasoning.'
              : 'Highlighted cells have a single candidate. Filling them removes that digit from their peers, which may force more cells.'}
        </p>
      </div>
    </div>
  );
}

/** Lesson 10: where each solver would start on the selected puzzle. */
export function MrvDemo() {
  const { puzzle } = useApp();
  const board = useMemo(() => new SudokuBoard(puzzle.grid), [puzzle]);
  const cells = puzzle.grid.flat();
  const first = board.findEmptyCell();
  const choice = selectMRVCell(board);
  const marks = new Map<number, CellMark>();
  cells.forEach((v, i) => {
    if (v === 0) marks.set(i, { corner: String(board.getCandidates(Math.floor(i / 9), i % 9).length) });
  });
  const firstIdx = first ? first.row * 9 + first.col : null;
  const mrvIdx = choice ? choice.cell.row * 9 + choice.cell.col : null;
  if (firstIdx !== null) marks.set(firstIdx, { ...marks.get(firstIdx), tone: 'clash-source' });
  if (mrvIdx !== null) marks.set(mrvIdx, { ...marks.get(mrvIdx), pencil: choice!.candidates, pencilTone: 'candidates', tone: 'placed' });
  return (
    <div className={styles.demo}>
      <div className={styles.demoBoard}>
        <SudokuGrid label="MRV demo board" values={cells} givens={cells.map((v) => v !== 0)} marks={marks} focusCell={mrvIdx} />
      </div>
      <div className={styles.demoSide}>
        <PuzzlePicker id="mrv-puzzle" label="Puzzle" />
        <dl className={styles.facts}>
          <dt>plain picks</dt>
          <dd>
            {first ? `${cellName(first)} (first empty cell, ${board.getCandidates(first.row, first.col).length} candidates)` : 'nothing: board full'}
          </dd>
          <dt>MRV picks</dt>
          <dd>{choice ? `${cellName(choice.cell)} with candidates [${choice.candidates.join(', ')}]` : 'nothing: board full'}</dd>
          <dt>cells scored</dt>
          <dd>{choice ? `${choice.examined} getCandidates() calls to choose` : '0'}</dd>
        </dl>
        <div className={styles.legend}>
          <span>
            <span className={styles.swatch} style={{ outline: '2px solid var(--red)', outlineOffset: -2 }} />
            plain solver's first cell
          </span>
          <span>
            <span className={styles.swatch} style={{ background: 'var(--olive-wash)', outline: '2px solid var(--amber)', outlineOffset: -2 }} />
            MRV's first cell
          </span>
          <span>small numbers: candidate counts</span>
        </div>
      </div>
    </div>
  );
}
