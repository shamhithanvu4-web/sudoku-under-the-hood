// Production build: bundles the app and writes it as a single self-contained HTML file.
//   dist/index.html     complete document, works from file:// or any static host
//   dist/artifact.html  the same page without <html>/<head>/<body>, for hosts that add their own
import * as esbuild from 'esbuild';
import { mkdir, writeFile } from 'node:fs/promises';
import { baseOptions, pageParts, fullDocument } from './shared.mjs';

const result = await esbuild.build({
  ...baseOptions,
  outdir: 'dist/assets',
  minify: true,
  write: false,
  sourcemap: false,
  define: { 'process.env.NODE_ENV': '"production"' },
  metafile: true,
});

const js = result.outputFiles.find((f) => f.path.endsWith('.js')).text;
const css = result.outputFiles.find((f) => f.path.endsWith('.css'))?.text ?? '';
const parts = pageParts({ css, js });

await mkdir('dist', { recursive: true });
await writeFile('dist/index.html', fullDocument(parts));
await writeFile('dist/artifact.html', `${parts.head}\n${parts.body}\n`);

const kb = (n) => `${(n / 1024).toFixed(1)} KB`;
console.log(`dist/index.html  ${kb(Buffer.byteLength(fullDocument(parts)))}  (js ${kb(js.length)}, css ${kb(css.length)})`);
