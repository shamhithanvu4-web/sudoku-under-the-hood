import { useMemo } from 'react';
import { useApp } from '../../app/AppState';
import { countClues } from '../../app/puzzles';
import { MessageBar } from '../../components/MessageBar';
import { PageHeader, pageStyles } from '../../components/PageHeader';
import { Panel } from '../../components/Panel';
import { Segmented } from '../../components/Segmented';
import { useIsNarrow } from '../../hooks/useMediaQuery';
import { useStoredState } from '../../hooks/useStoredState';
import { SOLVER_LABEL } from '../../solver/runSolver';
import type { SolverKind } from '../../solver/types';
import { DifficultyChip, PuzzlePicker } from '../board/PuzzlePicker';
import { SudokuGrid, type CellMark } from '../board/SudokuGrid';
import { puzzleNote } from '../board/puzzleNote';
import { buildBoardView } from './boardView';
import { CallStackPanel } from './CallStackPanel';
import { CodePanel } from './CodePanel';
import { ExplanationPanel, type Detail } from './ExplanationPanel';
import { MemoryStrip } from './MemoryStrip';
import { PlaybackControls, StickyPlayback } from './PlaybackControls';
import { StatsPanel } from './StatsPanel';
import { Timeline } from './Timeline';
import { TraceLog } from './TraceLog';
import { useGuidedRun, usePlaybackKeys, type Source } from './useGuidedRun';
import styles from './Guided.module.css';

export function GuidedPage() {
  const { puzzle } = useApp();
  const [kind, setKind] = useStoredState<SolverKind>('solver', 'backtracking');
  const [source, setSource] = useStoredState<Source>('source', 'original');
  const [detail, setDetail] = useStoredState<Detail>('detail', 'concise');
  const [depthLabels, setDepthLabels] = useStoredState('depthLabels', true);
  const [counts, setCounts] = useStoredState('counts', false);
  const narrow = useIsNarrow();

  const { result, running, trace, playback: p, playerEntries, effectiveSource } = useGuidedRun(kind, source);
  usePlaybackKeys(p);

  const view = useMemo(
    () => (trace ? buildBoardView(trace, p.index, { depthLabels, candidateCounts: counts }) : null),
    [trace, p.index, depthLabels, counts],
  );
  const stats = useMemo(() => (trace ? trace.statsAt(p.index) : null), [trace, p.index]);
  const event = trace && p.index >= 0 ? trace.events[p.index] : null;

  // Invalid puzzles have no trace: show the clashing clues instead.
  const invalidMarks = useMemo(() => {
    const map = new Map<number, CellMark>();
    result?.report?.conflicts.forEach((c) => {
      map.set(c.a.row * 9 + c.a.col, { tone: 'conflict' });
      map.set(c.b.row * 9 + c.b.col, { tone: 'conflict' });
    });
    return map;
  }, [result]);

  const atEnd = trace ? p.index === trace.length - 1 : false;
  const statusMessage =
    result && (result.status !== 'solved' || atEnd || result.alreadySolved)
      ? {
          tone: result.status === 'solved' ? ('success' as const) : result.status === 'limit-reached' ? ('warning' as const) : ('error' as const),
          text: result.message,
        }
      : null;

  const note = puzzleNote(puzzle);

  const toolbar = (
      <div className={styles.toolbar}>
        <PuzzlePicker id="guided-puzzle" />
        <div className={styles.toolGroup}>
          <span className="label">Solver</span>
          <Segmented
            label="Solver"
            value={kind}
            onChange={setKind}
            options={[
              { value: 'backtracking', label: 'Plain backtracking', title: 'First empty cell, digits 1–9' },
              { value: 'mrv', label: 'MRV heuristic', title: 'Most constrained cell first' },
            ]}
          />
        </div>
        {playerEntries > 0 && (
          <div className={styles.toolGroup}>
            <span className="label">Start from</span>
            <Segmented
              label="Starting board"
              value={effectiveSource}
              onChange={setSource}
              options={[
                { value: 'original', label: 'Original clues' },
                { value: 'board', label: `My board (+${playerEntries})` },
              ]}
            />
          </div>
        )}
      </div>
  );
  const messages = (
    <>
      {statusMessage && <MessageBar message={statusMessage} />}
      {effectiveSource === 'board' && (
        <MessageBar message={{ tone: 'info', text: `Your ${playerEntries} entries are treated as fixed clues. If one of them is wrong, the solver will prove there is no solution.` }} />
      )}
    </>
  );

  return (
    <div className={pageStyles.wrap}>
      {/* On phones the board comes first: the title, then the board, then the selectors. */}
      <PageHeader label="Under the Hood · guided solving" title="Watch the algorithm think">
        {narrow
          ? undefined
          : 'The solver below has really run on this puzzle, and every operation it performed was recorded. Replay it at any speed, step backwards, and see each decision explained and traced to its line of code.'}
      </PageHeader>

      {!narrow && toolbar}
      {!narrow && messages}

      <div className={styles.layout}>
        <div className={styles.col}>
          <div className={styles.boardWrap}>
            <div className={styles.boardOptions}>
              <DifficultyChip puzzle={puzzle} />
              <span>{countClues(puzzle.grid)} clues · {SOLVER_LABEL[kind]}</span>
            </div>
            {note && !narrow && <p className={styles.puzzleNote}>{note}</p>}
            {running || !result ? (
              <>
                <SudokuGrid label="Puzzle" values={puzzle.grid.flat()} givens={puzzle.grid.flat().map((v) => v !== 0)} coords="sudoku" />
                <p className={styles.placeholder}>Running the solver and recording every step…</p>
              </>
            ) : view ? (
              <>
                <SudokuGrid
                  label={`Solver board at step ${p.index + 1}`}
                  values={view.values}
                  givens={view.givens}
                  marks={view.marks}
                  focusCell={view.focusCell}
                  units={view.units}
                  link={view.link}
                  coords="sudoku"
                  animKey={p.index}
                />
                {!narrow && trace && (
                  <div className={styles.boardTransport}>
                    <PlaybackControls p={p} part="transport" />
                  </div>
                )}
                <MemoryStrip values={view.values} givens={view.givens} focus={view.focusCell} detailed={detail === 'detailed'} />
              </>
            ) : (
              <SudokuGrid label="Puzzle with clashing clues" values={puzzle.grid.flat()} givens={puzzle.grid.flat().map((v) => v !== 0)} marks={invalidMarks} coords="sudoku" />
            )}
            <div className={styles.boardOptions}>
              <label className={styles.check}>
                <input type="checkbox" checked={depthLabels} onChange={(e) => setDepthLabels(e.target.checked)} />
                Depth labels
              </label>
              <label className={styles.check}>
                <input type="checkbox" checked={counts} onChange={(e) => setCounts(e.target.checked)} />
                Candidate counts
              </label>
            </div>
            {note && narrow && <p className={styles.puzzleNote}>{note}</p>}
          </div>
          {narrow && toolbar}
          {narrow && messages}
          {narrow && trace && <ExplanationPanel trace={trace} index={p.index} kind={kind} detail={detail} onDetail={setDetail} />}
          {trace && (
            <Panel label="Playback">
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.9rem' }}>
                <PlaybackControls p={p} part="options" />
                <Timeline trace={trace} p={p} />
              </div>
            </Panel>
          )}
          {trace && stats && result && <StatsPanel stats={stats} result={result} index={p.index} collapsible={narrow} defaultOpen={!narrow} />}
        </div>

        <div className={styles.col}>
          {trace ? (
            <>
              {!narrow && <ExplanationPanel trace={trace} index={p.index} kind={kind} detail={detail} onDetail={setDetail} />}
              <CodePanel kind={kind} event={event} collapsible={narrow} defaultOpen={!narrow} />
            </>
          ) : (
            result && (
              <Panel label="Why the solver did not start">
                <p>{result.message}</p>
              </Panel>
            )
          )}
        </div>

        {trace && (
          <div className={styles.colRight}>
            <CallStackPanel trace={trace} index={p.index} onSeek={(i) => { p.setPlaying(false); p.setIndex(i); }} collapsible={narrow} defaultOpen={!narrow} />
            <TraceLog trace={trace} index={p.index} onSeek={(i) => { p.setPlaying(false); p.setIndex(i); }} collapsible={narrow} defaultOpen={false} />
          </div>
        )}
      </div>
      {narrow && trace && <StickyPlayback p={p} />}
    </div>
  );
}
