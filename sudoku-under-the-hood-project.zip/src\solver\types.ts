/**
 * Structured trace events produced by the solvers.
 *
 * Every event is emitted by a real line of solver code at the moment that
 * operation happens. The UI never invents events; it only replays them.
 */
import type { Coord, Conflict } from '../domain/SudokuBoard';

export type TraceEventType =
  | 'RECURSION_ENTERED'
  | 'CELL_SELECTED'
  | 'CANDIDATES_COMPUTED'
  | 'CANDIDATE_TRIED'
  | 'VALIDATION_PASSED'
  | 'VALIDATION_FAILED'
  | 'VALUE_PLACED'
  | 'RECURSION_RETURNED'
  | 'BACKTRACK'
  | 'DEAD_END'
  | 'SOLUTION_FOUND'
  | 'NO_SOLUTION';

/**
 * A step id names the exact place in the solver source that emitted an event.
 * The same string appears as the first argument of the recorder call, which
 * is how the code panel finds and highlights the line.
 */
export type StepId = string;

/** The board ADT operation an event is about (shown in the code panel). */
export type BoardOperation =
  | 'findEmptyCell'
  | 'getCandidates'
  | 'findConflict'
  | 'placeCandidate'
  | 'undoPlacement'
  | 'isSolved';

export interface Placement {
  readonly cell: Coord;
  readonly digit: number;
}

export interface TraceEvent {
  /** Position in the trace, starting at 0. */
  readonly index: number;
  readonly type: TraceEventType;
  readonly step: StepId;
  /** Id of the recursive call that emitted the event (-1 for the final verdict). */
  readonly callId: number;
  /** Recursion depth of that call: the root call is depth 0. */
  readonly depth: number;
  readonly op: BoardOperation | null;
  readonly cell?: Coord;
  readonly digit?: number;
  /** Cell value before and after the event, for events that change the board. */
  readonly before?: number;
  readonly after?: number;
  readonly candidates?: readonly number[];
  /** For VALIDATION_FAILED: the clue or placement that blocks the digit. */
  readonly conflict?: Conflict;
  /** For RECURSION_RETURNED: the boolean the call returned. */
  readonly result?: boolean;
  /** For RECURSION_ENTERED: the placement that led to this call (absent for the root). */
  readonly via?: Placement;
  /** For CANDIDATES_COMPUTED (MRV): how many empty cells were scored to choose this one. */
  readonly examined?: number;
}

/** Work counters. Both solvers update them through the same Recorder, so the categories match. */
export interface SolverStats {
  /** Times solve() was entered, including the first call. */
  recursiveCalls: number;
  /** Digits considered for the selected cell. */
  candidateAttempts: number;
  /** Digits that failed the row/column/box check. */
  rejected: number;
  /** Tentative placements made with placeCandidate(). */
  placements: number;
  /** Placements undone with undoPlacement() after their branch failed. */
  backtracks: number;
  /** Calls that ran out of options and returned false. */
  deadEnds: number;
  /** Deepest recursion level reached (root = 0). */
  maxDepth: number;
  /** Row/column/box scans: one per findConflict() or getCandidates() call. */
  peerScans: number;
}

export function emptyStats(): SolverStats {
  return {
    recursiveCalls: 0,
    candidateAttempts: 0,
    rejected: 0,
    placements: 0,
    backtracks: 0,
    deadEnds: 0,
    maxDepth: 0,
    peerScans: 0,
  };
}

export type SolverKind = 'backtracking' | 'mrv';
