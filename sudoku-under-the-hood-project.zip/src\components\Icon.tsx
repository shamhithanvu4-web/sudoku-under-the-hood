/** Small line icons drawn on a 24×24 grid. Decorative unless a label is given. */
const PATHS = {
  play: 'M8 5.5v13l10.5-6.5z',
  pause: 'M8 5v14M16 5v14',
  stepForward: 'M6 6l8 6-8 6zM17 6v12',
  stepBack: 'M18 6l-8 6 8 6zM7 6v12',
  toStart: 'M19 6l-7 6 7 6zM12 6l-7 6 7 6',
  toEnd: 'M5 6l7 6-7 6zM12 6l7 6-7 6',
  undo: 'M9 7L5 11l4 4M5 11h9a5 5 0 010 10h-3',
  redo: 'M15 7l4 4-4 4M19 11h-9a5 5 0 000 10h3',
  erase: 'M16 4l5 5-10 10H6l-3-3zM9 11l5 5M11 19h10',
  pencil: 'M4 20l1-4L16 5l3 3L8 19zM14 7l3 3',
  bulb: 'M9 18h6M10 21h4M12 3a6 6 0 00-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0012 3z',
  check: 'M4 12.5l5 5L20 6.5',
  reset: 'M4 4v6h6M4.5 10a8 8 0 111.5 6.5',
  expand: 'M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5',
  collapse: 'M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5',
  copy: 'M9 9h10v11H9zM5 15V4h10',
  chevron: 'M9 6l6 6-6 6',
  chevronDown: 'M6 9l6 6 6-6',
  close: 'M6 6l12 12M18 6L6 18',
  arrowRight: 'M4 12h15M13 6l6 6-6 6',
  info: 'M12 11v6M12 7.5v.5M12 21a9 9 0 110-18 9 9 0 010 18z',
  branch: 'M6 4v16M6 8h6a4 4 0 014 4v8M6 14h4',
  guide: 'M5 4h11l3 3v13H5zM9 9h6M9 13h6M9 17h3',
  gauge: 'M4 16a8 8 0 1116 0M12 16l4-5',
  layers: 'M12 4l9 5-9 5-9-5zM3 14l9 5 9-5',
  grid: 'M4 4h16v16H4zM4 9.3h16M4 14.6h16M9.3 4v16M14.6 4v16',
} as const;

export type IconName = keyof typeof PATHS;

export function Icon({ name, size = 18, label }: { name: IconName; size?: number; label?: string }) {
  const filled = name === 'play';
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill={filled ? 'currentColor' : 'none'}
      stroke="currentColor"
      strokeWidth={filled ? 1.2 : 1.75}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden={label ? undefined : true}
      role={label ? 'img' : undefined}
      aria-label={label}
      focusable="false"
      style={{ flex: 'none' }}
    >
      <path d={PATHS[name]} />
    </svg>
  );
}
