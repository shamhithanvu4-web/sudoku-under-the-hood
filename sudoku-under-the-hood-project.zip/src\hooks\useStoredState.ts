import { useEffect, useState } from 'react';

/** useState that remembers a small preference in localStorage when it is available. */
export function useStoredState<T extends string | boolean | number>(key: string, initial: T): [T, (v: T) => void] {
  const [value, setValue] = useState<T>(() => {
    try {
      const raw = window.localStorage.getItem(`suh:${key}`);
      return raw === null ? initial : (JSON.parse(raw) as T);
    } catch {
      return initial;
    }
  });
  useEffect(() => {
    try {
      window.localStorage.setItem(`suh:${key}`, JSON.stringify(value));
    } catch {
      /* storage unavailable: keep the value in memory only */
    }
  }, [key, value]);
  return [value, setValue];
}
