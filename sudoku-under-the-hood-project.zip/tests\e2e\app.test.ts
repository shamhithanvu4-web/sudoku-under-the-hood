/**
 * Browser tests: drive the built app (dist/index.html) with Playwright and
 * compare what it shows with an independent run of the same solver here.
 *
 *   npm run test:e2e
 */
import { after, before, describe, test } from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { chromium, type Browser, type Page } from 'playwright';
import puzzles from '../../src/data/puzzles.json';
import { gridFromString } from '../../src/domain/puzzleFormat';
import { runSolver } from '../../src/solver/runSolver';

const APP = pathToFileURL(fileURLToPath(new URL('../../dist/index.html', import.meta.url))).href;
const demo = puzzles.puzzles.find((p) => p.id === puzzles.demoId)!;
const demoGrid = gridFromString(demo.givens);
const expected = runSolver(demoGrid, 'backtracking', { record: true });
const trace = expected.trace!;

let browser: Browser;
const errors: string[] = [];

async function open(hash: string, width = 1280, height = 900): Promise<Page> {
  const page = await browser.newPage({ viewport: { width, height } });
  page.on('pageerror', (e) => errors.push(String(e)));
  // Everything, fonts included, is bundled: the page must not touch the network.
  page.on('request', (r) => {
    if (!/^(file|data|blob):/.test(r.url())) errors.push(`network request: ${r.url()}`);
  });
  await page.goto(`${APP}#${hash}`);
  return page;
}

const cell = (page: Page, index: number) => page.locator(`[role="grid"] [data-index="${index}"]`).first();
/** The digit in a cell as announced to screen readers ('' when empty). */
const cellText = async (page: Page, index: number) => {
  const label = (await cell(page, index).getAttribute('aria-label')) ?? '';
  return label.match(/: (?:clue )?(\d)/)?.[1] ?? '';
};

async function boardDigits(page: Page): Promise<number[]> {
  return page.$$eval('[role="grid"] [role="gridcell"]', (cells) =>
    cells.slice(0, 81).map((c) => {
      const label = c.getAttribute('aria-label') ?? '';
      const m = label.match(/: (?:clue )?(\d)/);
      return m ? Number(m[1]) : 0;
    }),
  );
}

before(async () => {
  browser = await chromium.launch();
});
after(async () => {
  await browser.close();
  assert.deepEqual(errors, [], 'the page threw errors');
});

describe('home', () => {
  test('Start Challenge opens Play mode', async () => {
    const page = await open('');
    await page.getByRole('button', { name: 'Start Challenge' }).click();
    await page.getByRole('heading', { name: 'Solve it yourself first' }).waitFor();
    assert.match(page.url(), /#play$/);
    await page.close();
  });
});

describe('play mode', () => {
  test('keyboard entry, clue protection, conflicts, undo and redo', async () => {
    const page = await open('play');
    // r1c1 is empty in the demo puzzle; r1c2 is the clue 7.
    assert.equal(demoGrid[0][0], 0);
    assert.equal(demoGrid[0][1], 7);

    await cell(page, 0).click();
    await page.keyboard.press('2');
    assert.equal(await cellText(page, 0), '2');

    // Arrow keys move the selection.
    await page.keyboard.press('ArrowRight');
    assert.equal(await cell(page, 1).getAttribute('aria-selected'), 'true');

    // The clue cannot be changed.
    await page.keyboard.press('9');
    assert.equal(await cellText(page, 1), '7');
    await page.getByText('is a starting clue and cannot be changed').waitFor();

    // A rule conflict is reported and marked.
    await cell(page, 0).click();
    await page.keyboard.press('7');
    await page.getByText('7 already appears in the same row at r1c2').waitFor();
    assert.match((await cell(page, 0).getAttribute('aria-label')) ?? '', /breaks a rule/);

    // Undo returns to 2, redo brings 7 back.
    await page.keyboard.press('Control+z');
    assert.equal(await cellText(page, 0), '2');
    await page.keyboard.press('Control+y');
    assert.equal(await cellText(page, 0), '7');

    // Erase.
    await page.keyboard.press('Backspace');
    assert.equal(await cellText(page, 0), '');
    await page.close();
  });

  test('pencil notes and hints', async () => {
    const page = await open('play');
    await cell(page, 2).click();
    await page.keyboard.press('n');
    await page.keyboard.press('4');
    await page.keyboard.press('8');
    assert.match((await cell(page, 2).textContent()) ?? '', /4.*8/);
    await page.keyboard.press('n');
    await page.getByRole('button', { name: 'Hint' }).click();
    await page.getByText(/^Hint:/).waitFor();
    await page.close();
  });

  test('a contradictory custom puzzle is explained, not solved', async () => {
    const page = await open('play');
    await page.getByText('Load your own puzzle').click();
    const bad = puzzles.lab.find((p) => p.id === 'lab-contradictory')!.givens;
    await page.locator('#custom-puzzle').fill(bad);
    await page.getByRole('button', { name: 'Check and load' }).click();
    await page.getByText(/starting clues break a rule/).first().waitFor();
    await page.locator('#custom-puzzle').fill('123');
    await page.getByRole('button', { name: 'Check and load' }).click();
    await page.getByText('A puzzle needs exactly 81 cells; this one has 3.').waitFor();
    await page.close();
  });
});

describe('under the hood', () => {
  test('the replay matches an independent run of the solver, forwards and backwards', async () => {
    const page = await open('solve');
    const badge = page.locator('[data-event-type]').first();
    await page.getByText('step', { exact: false }).first().waitFor();
    await page.getByRole('button', { name: 'Start', exact: true }).waitFor();

    for (let i = 0; i < 6; i++) await page.keyboard.press('ArrowRight');
    assert.equal((await badge.textContent())?.trim(), trace.events[5].type);
    await page.keyboard.press('ArrowLeft');
    await page.keyboard.press('ArrowLeft');
    assert.equal((await badge.textContent())?.trim(), trace.events[3].type);
    assert.deepEqual(await boardDigits(page), Array.from(trace.boardAt(3)));

    // Shift+→ jumps to the first real backtrack.
    await page.keyboard.press('Shift+ArrowRight');
    assert.equal((await badge.textContent())?.trim(), 'BACKTRACK');
    await page.getByText(`step ${(trace.backtracks[0] + 1).toLocaleString('en-US')} /`).waitFor();
    assert.deepEqual(await boardDigits(page), Array.from(trace.boardAt(trace.backtracks[0])));

    // The highlighted source line is the undo.
    const active = await page.locator('[data-active="true"]').allTextContents();
    assert.ok(active.some((t) => t.includes('undoPlacement')), `active lines: ${active.join(' | ')}`);

    // End shows the solved board.
    await page.keyboard.press('End');
    assert.deepEqual(await boardDigits(page), expected.solution!.flat());
    await page.getByText('Solved. Every row, column and box').waitFor();
    await page.close();
  });

  test('switching to MRV records a different, shorter run', async () => {
    const page = await open('solve');
    await page.getByRole('radio', { name: 'MRV heuristic' }).click();
    const mrv = runSolver(demoGrid, 'mrv', { record: true }).trace!;
    await page.getByText(`/ ${mrv.length.toLocaleString('en-US')}`).waitFor();
    await page.close();
  });
});

describe('learn and analyze', () => {
  test('encapsulation demo shows the real error from the board', async () => {
    const page = await open('learn.encapsulation');
    await page.getByRole('button', { name: 'Run' }).first().click();
    await page.getByText(/GIVEN_CELL/).first().waitFor();
    await page.close();
  });

  test('quiz gives feedback', async () => {
    const page = await open('learn.arrays-2d');
    await page.getByLabel('47').check();
    await page.getByRole('button', { name: 'Check answer' }).click();
    await page.getByText('Correct.').waitFor();
    await page.close();
  });

  test('analyze reports the counts the solvers really produce', async () => {
    const page = await open('analyze');
    const plain = runSolver(demoGrid, 'backtracking', { record: false }).stats.recursiveCalls;
    const mrv = runSolver(demoGrid, 'mrv', { record: false }).stats.recursiveCalls;
    await page.getByText(`${plain.toLocaleString('en-US')} calls`).waitFor();
    await page.getByText(`${mrv.toLocaleString('en-US')} calls`).waitFor();
    await page.close();
  });
});

describe('responsive layout', () => {
  for (const hash of ['', 'play', 'solve', 'learn', 'analyze', 'present']) {
    test(`#${hash || 'home'} has no horizontal scroll at 375px`, async () => {
      const page = await open(hash, 375, 800);
      await page.waitForTimeout(250);
      const [scroll, width] = await page.evaluate(() => [document.documentElement.scrollWidth, window.innerWidth]);
      assert.ok(scroll <= width, `scrollWidth ${scroll} > ${width}`);
      await page.close();
    });
  }
});

describe('polish pass', () => {
  test('bundled fonts load without the network', async () => {
    const page = await open('');
    const status = await page.evaluate(async () => {
      await document.fonts.load('16px Archivo');
      await document.fonts.load('12px "JetBrains Mono"');
      return [...document.fonts].map((f) => `${f.family.replace(/"/g, '')}:${f.status}`);
    });
    assert.ok(status.includes('Archivo:loaded'), status.join(', '));
    assert.ok(status.includes('JetBrains Mono:loaded'), status.join(', '));
    await page.close();
  });

  test('boards are labelled r1–r9 and c1–c9; grid[r][c] appears only in detailed mode', async () => {
    for (const hash of ['', 'play', 'solve', 'learn.arrays-2d', 'present']) {
      const page = await open(hash);
      await page.locator('[role="grid"]').first().waitFor();
      const text = (await page.locator('[role="grid"]').first().locator('xpath=..').innerText()).replace(/\s+/g, ' ');
      assert.match(text, /c1 c2 c3 c4 c5 c6 c7 c8 c9/, `#${hash} column labels`);
      assert.match(text, /r1 .*r9/, `#${hash} row labels`);
      await page.close();
    }
    const page = await open('solve');
    await page.getByRole('button', { name: 'Start', exact: true }).waitFor();
    // Step 6 is a digit check on r1c1, so the board, the memory strip and the operation all refer to a cell.
    for (let i = 0; i < 6; i++) await page.keyboard.press('ArrowRight');
    assert.equal(await page.locator('[data-event-type]').first().textContent(), trace.events[5].type);
    const main = page.locator('main');
    assert.ok(!(await main.innerText()).includes('grid['), 'concise mode shows array notation');
    await page.getByRole('radio', { name: 'Detailed' }).click();
    await page.getByText('0-based in code: r1c1 is grid[0][0]').waitFor();
    await page.getByText(/cells\[\d+\] ⇔ grid\[\d\]\[\d\]/).waitFor();
    await page.close();
  });

  test('desktop: playback controls sit directly under the board', async () => {
    const page = await open('solve');
    const start = page.getByRole('button', { name: 'Start', exact: true });
    await start.waitFor();
    const board = await page.locator('[role="grid"]').first().boundingBox();
    const button = await start.boundingBox();
    assert.ok(board && button);
    assert.ok(button!.y > board!.y + board!.height && button!.y - (board!.y + board!.height) < 40, `gap ${button!.y - (board!.y + board!.height)}px`);
    await page.close();
  });

  test('phones: board first, and a sticky bar steps through the run', async () => {
    const page = await open('solve', 375, 740);
    const bar = page.locator('[role="group"][aria-label="Playback"]').last();
    await bar.getByRole('button', { name: 'Start' }).waitFor();
    const board = await page.locator('[role="grid"]').first().boundingBox();
    const picker = await page.locator('#guided-puzzle').boundingBox();
    assert.ok(board!.y < picker!.y, 'the board comes before the puzzle picker');
    await bar.getByRole('button', { name: 'Next step' }).click();
    await bar.getByRole('button', { name: 'Next step' }).click();
    await bar.getByText(`step 2 / ${trace.length.toLocaleString('en-US')}`).waitFor();
    await bar.getByRole('button', { name: 'Previous step' }).click();
    await bar.getByText('step 1 /').waitFor();
    // Pinned to the bottom of the viewport while the page scrolls.
    await page.mouse.wheel(0, 500);
    await page.waitForTimeout(150);
    const box = await bar.boundingBox();
    assert.ok(Math.abs(box!.y + box!.height - 740) < 2, `bar bottom at ${box!.y + box!.height}`);
    const play = await open('play', 375, 740);
    const playBoard = await play.locator('[role="grid"]').first().boundingBox();
    const playPicker = await play.locator('#puzzle-picker').boundingBox();
    assert.ok(playBoard!.y < playPicker!.y, 'Play: board before picker');
    await play.close();
    await page.close();
  });

  test('the demo description shows the measured step count', async () => {
    const page = await open('solve');
    await page.getByText(`recorded run has ${trace.length.toLocaleString('en-US')} steps, and its first backtrack is step ${(trace.backtracks[0] + 1).toLocaleString('en-US')}`).first().waitFor();
    await page.close();
  });

  test('Analyze shows n/a with an explanation instead of an infinite ratio', async () => {
    const page = await open('analyze');
    await page.getByText(/warm-up run that is not counted/).first().waitFor();
    const row = page.locator('tr', { hasText: 'Rejected by rules' });
    const na = row.getByText('n/a');
    await na.waitFor();
    assert.ok(!(await page.locator('main').innerText()).includes('∞'));
    await na.focus();
    const tip = page.getByRole('tooltip').filter({ hasText: 'MRV only tries digits that getCandidates() has already allowed' });
    await tip.waitFor({ state: 'visible' });
    assert.equal(await na.getAttribute('aria-describedby'), await tip.getAttribute('id'));
    await page.close();
  });

  test('Present opens on a fresh demo board and leaves Play progress alone', async () => {
    const page = await open('play');
    await cell(page, 0).click();
    await page.keyboard.press('2');
    assert.equal(await cellText(page, 0), '2');
    await page.getByRole('button', { name: 'Present' }).click();
    await page.getByRole('heading', { name: 'Solve it together' }).waitFor();
    assert.equal(await cellText(page, 0), '', 'Present board should start from the clues');
    assert.deepEqual(await boardDigits(page), demoGrid.flat());
    await page.getByRole('button', { name: 'Exit' }).click();
    await page.getByRole('link', { name: 'Skip to content' }).waitFor({ state: 'attached' });
    await page.getByRole('button', { name: 'Play', exact: true }).click();
    assert.equal(await cellText(page, 0), '2', 'Play progress is kept');
    await page.close();
  });

  test('the complexity lesson measures both solvers after a warm-up', async () => {
    const page = await open('learn.complexity');
    await page.getByRole('button', { name: 'Measure this puzzle' }).click();
    const plain = expected.stats.recursiveCalls.toLocaleString('en-US');
    await page.locator('div', { hasText: /^Plain: recursive calls/ }).getByText(plain, { exact: true }).first().waitFor();
    await page.getByText(/after an uncounted warm-up run/).waitFor();
    await page.close();
  });

  test('long code lines wrap instead of scrolling sideways', async () => {
    const page = await open('solve', 1024, 800);
    const box = page.locator('[aria-label="Source code listing"]');
    await box.waitFor();
    const [scroll, client] = await box.evaluate((el) => [el.scrollWidth, el.clientWidth]);
    assert.ok(scroll <= client, `code scrolls sideways: ${scroll} > ${client}`);
    await page.close();
  });
});
