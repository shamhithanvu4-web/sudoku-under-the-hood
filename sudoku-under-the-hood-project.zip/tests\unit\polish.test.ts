import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { measure } from '../../src/features/analyze/measure';
import { puzzleNote } from '../../src/features/board/puzzleNote';
import { BUNDLED, DEMO_ID } from '../../src/app/puzzles';
import { explainEvent } from '../../src/explain/explain';
import texts from '../../src/data/explanations.json';
import { runSolver, type RunResult } from '../../src/solver/runSolver';
import type { SolverKind } from '../../src/solver/types';
import { puzzle } from './helpers';

describe('timing runs', () => {
  test('one warm-up run happens first and is not counted', () => {
    const real = runSolver(puzzle('demo'), 'mrv', { record: false });
    const durations = [500, 3, 1, 2]; // the 500 ms warm-up must be ignored
    let calls = 0;
    const fake = (): RunResult => ({ ...real, durationMs: durations[calls++] });
    const m = measure(puzzle('demo'), 'mrv', 3, 1000, fake);
    assert.equal(calls, 4);
    assert.deepEqual(m.times, [3, 1, 2]);
    assert.equal(m.median, 2);
    assert.equal(m.max, 3);
    assert.equal(m.warmUpRuns, 1);
  });

  test('an invalid puzzle is not timed repeatedly', () => {
    let calls = 0;
    const real = runSolver(puzzle('lab-contradictory'), 'backtracking', { record: false });
    const m = measure(puzzle('lab-contradictory'), 'backtracking', 5, 1000, () => (calls++, real));
    assert.equal(calls, 2);
    assert.equal(m.times.length, 1);
    assert.equal(m.result.status, 'invalid-puzzle');
  });
});

describe('demo description', () => {
  test('states the step count measured from a real run', () => {
    const demo = BUNDLED.find((p) => p.id === DEMO_ID)!;
    const trace = runSolver(demo.grid, 'backtracking', { record: true }).trace!;
    const note = puzzleNote(demo)!;
    assert.ok(note.includes(`${trace.length.toLocaleString('en-US')} steps`), note);
    assert.ok(note.includes(`first backtrack is step ${(trace.backtracks[0] + 1).toLocaleString('en-US')}`), note);
  });

  test('other puzzles keep their written description', () => {
    const lab = BUNDLED.find((p) => p.id === 'lab-unsolvable')!;
    assert.equal(puzzleNote(lab), lab.description);
  });
});

describe('concise explanations use 1-based cell names only', () => {
  test('no array notation in concise text, titles or operation names', () => {
    for (const [key, entry] of Object.entries(texts)) {
      assert.ok(!/\{(index|row|col)\}|grid\[/.test(entry.concise + entry.title), key);
    }
    for (const kind of ['backtracking', 'mrv'] as SolverKind[]) {
      const trace = runSolver(puzzle('demo'), kind, { record: true }).trace!;
      for (let i = 0; i < trace.length; i++) {
        const x = explainEvent(trace, i, kind);
        assert.ok(!x.concise.includes('grid['), `${x.key}: ${x.concise}`);
        assert.ok(!/\d/.test(x.name.replace(/return (true|false)/, '')), `${x.key}: operation name "${x.name}" shows indices`);
      }
    }
  });
});
