/**
 * Timing runs for Analyze mode. Each solver first runs once untimed (a
 * warm-up, so the JavaScript engine has compiled the hot code before the
 * clock matters), then `repeats` timed runs with tracing off. Work counters
 * must be identical across runs (the algorithm is deterministic), and the
 * time is reported as the median with its range.
 */
import type { Grid } from '../../domain/SudokuBoard';
import { runSolver, type RunOptions, type RunResult } from '../../solver/runSolver';
import type { SolverKind } from '../../solver/types';

export interface Measurement {
  readonly kind: SolverKind;
  readonly result: RunResult;
  /** Timed runs only; the warm-up run is not included. */
  readonly times: readonly number[];
  readonly median: number;
  readonly min: number;
  readonly max: number;
  readonly warmUpRuns: number;
}

export function median(values: readonly number[]): number {
  const s = [...values].sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
}

type Runner = (grid: Grid, kind: SolverKind, options: RunOptions) => RunResult;

export const WARM_UP_RUNS = 1;

export function measure(grid: Grid, kind: SolverKind, repeats: number, maxCalls = 3_000_000, run: Runner = runSolver): Measurement {
  const options: RunOptions = { record: false, maxCalls };
  const warmUp = run(grid, kind, options); // not timed, not counted
  const stopped = warmUp.status === 'invalid-puzzle' || warmUp.status === 'malformed' || warmUp.status === 'limit-reached';

  const times: number[] = [];
  let first: RunResult | null = null;
  for (let i = 0; i < (stopped ? 1 : repeats); i++) {
    const result = run(grid, kind, options);
    times.push(result.durationMs);
    if (!first) first = result;
    else if (result.stats.recursiveCalls !== first.stats.recursiveCalls) {
      throw new Error('Solver work changed between identical runs.');
    }
  }
  return { kind, result: first!, times, median: median(times), min: Math.min(...times), max: Math.max(...times), warmUpRuns: WARM_UP_RUNS };
}

/** Lets the browser paint between heavy runs. */
export const nextFrame = () => new Promise<void>((resolve) => window.setTimeout(resolve, 16));
