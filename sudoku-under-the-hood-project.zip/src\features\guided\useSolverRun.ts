import { useEffect, useState } from 'react';
import type { Grid } from '../../domain/SudokuBoard';
import { runSolver, type RunResult } from '../../solver/runSolver';
import type { SolverKind } from '../../solver/types';

/** Recorded runs keep at most this many events (about 6,000 recursive calls of the plain solver). */
export const GUIDED_MAX_EVENTS = 150_000;

/**
 * Runs the solver with tracing on, after the browser has painted, so the page
 * can show "Recording…" first. `key` identifies the input; a new key re-runs.
 */
export function useSolverRun(grid: Grid, kind: SolverKind, key: string): { result: RunResult | null; running: boolean } {
  const [state, setState] = useState<{ key: string; result: RunResult } | null>(null);
  useEffect(() => {
    let cancelled = false;
    const timer = window.setTimeout(() => {
      const result = runSolver(grid, kind, { record: true, maxEvents: GUIDED_MAX_EVENTS });
      if (!cancelled) setState({ key, result });
    }, 20);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
    // grid and kind are captured by key
  }, [key]);
  const fresh = state && state.key === key ? state.result : null;
  return { result: fresh, running: fresh === null };
}
