import { useApp } from '../../app/AppState';
import { DEMO_ID } from '../../app/puzzles';
import { Button } from '../../components/Button';
import { MessageBar } from '../../components/MessageBar';
import { SudokuGrid } from '../board/SudokuGrid';
import { NumberPad } from '../play/PlayControls';
import { usePlayController } from '../play/usePlayController';
import styles from './HomePage.module.css';

const STEPS = [
  {
    title: 'Play',
    text: 'Attempt the puzzle on your own. Notice which cell you pick, how you rule digits out, and what you do when every option seems wrong.',
  },
  {
    title: 'Watch the solver',
    text: 'A recursive backtracking solver attacks the same board. Step forwards and backwards through every check, placement, call and undo.',
  },
  {
    title: 'Read the code',
    text: 'Each step highlights the exact lines of TypeScript that produced it, with the call stack, the board ADT operation and live work counters.',
  },
  {
    title: 'Measure',
    text: 'Run plain backtracking and the MRV heuristic on the same puzzle, compare the measured work, and connect it to O(9ᵐ).',
  },
];

const CONCEPTS: { id: string; label: string; text: string }[] = [
  { id: 'adt', label: 'Abstract Data Type', text: 'The board is used only through operations like getCell and findConflict.' },
  { id: 'arrays-2d', label: '2D array', text: 'Behind those operations: grid[row][col], 81 numbers, 0 for empty.' },
  { id: 'encapsulation', label: 'Encapsulation', text: 'The array is a private field. Clues cannot be overwritten.' },
  { id: 'constraints', label: 'Constraints', text: 'One digit per row, column and 3×3 box: 27 units to check.' },
  { id: 'recursion', label: 'Recursion', text: 'Fill one cell, then solve the smaller puzzle that remains.' },
  { id: 'backtracking', label: 'Backtracking', text: 'When a branch dies, undo the last choice and try the next.' },
  { id: 'complexity', label: 'Complexity', text: 'Exponential in the worst case; real cost depends on the puzzle.' },
  { id: 'optimization', label: 'MRV heuristic', text: 'Fill the most constrained cell first and fail early.' },
];

export function HomePage() {
  const { navigate, selectPuzzle, puzzle } = useApp();
  const c = usePlayController();
  const sel = c.selected;
  const start = () => {
    if (puzzle.group === 'lab') selectPuzzle(DEMO_ID);
    navigate('play');
  };

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className={styles.heroText}>
          <span className="label">A data structures lab disguised as a puzzle</span>
          <h1>
            Play the puzzle.
            <br />
            Discover the algorithm.
          </h1>
          <p className={styles.lede}>
            Try this Sudoku for a few minutes. Then watch a recursive solver work on the same board, one recorded decision at a
            time: every rule check, every recursive call, every backtrack, tied to the line of code that made it.
          </p>
          <div className={styles.ctas}>
            <Button variant="primary" size="lg" icon="arrowRight" onClick={start}>
              Start Challenge
            </Button>
            <Button size="lg" variant="ghost" onClick={() => document.getElementById('how')?.scrollIntoView({ behavior: 'smooth' })}>
              How it works
            </Button>
          </div>
          <p className={styles.small}>No sign-in, nothing to install. The algorithm is revealed after you have had a go.</p>
          <Schematic />
        </div>

        <div className={styles.preview}>
          <div className={styles.previewHead}>
            <span className="label">Live board · {puzzle.name}</span>
            <span className={styles.readout} aria-live="polite">
              {sel === null
                ? 'click a cell'
                : `r${Math.floor(sel / 9) + 1}c${(sel % 9) + 1} = ${c.view.values[sel] || 'empty'}${c.view.givens[sel] ? ' (clue)' : ''}`}
            </span>
          </div>
          <SudokuGrid
            label="Preview Sudoku board"
            values={c.view.values}
            givens={c.view.givens}
            notes={c.view.notes}
            marks={c.marks}
            selected={c.selected}
            onSelect={c.setSelected}
            onKey={c.onKey}
            showPeers
            coords="sudoku"
          />
          <NumberPad c={c} />
          <MessageBar message={c.message} placeholder="Your entries here carry over to Play mode." />
        </div>
      </section>

      <section id="how" className={styles.section} aria-labelledby="how-title">
        <div className={styles.sectionHead}>
          <span className="label">How it works</span>
          <h2 id="how-title">Experience the problem, then the solution</h2>
        </div>
        <ol className={styles.steps}>
          {STEPS.map((s, i) => (
            <li key={s.title} className={styles.step}>
              <span className={styles.stepNo}>{String(i + 1).padStart(2, '0')}</span>
              <h3>{s.title}</h3>
              <p>{s.text}</p>
            </li>
          ))}
        </ol>
        <div className={styles.ctaRow}>
          <Button variant="primary" onClick={start}>
            Start with the puzzle
          </Button>
          <Button onClick={() => navigate('solve')}>Go straight to the solver</Button>
          <Button variant="ghost" icon="expand" onClick={() => navigate('present')}>
            Classroom presentation mode
          </Button>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="concepts-title">
        <div className={styles.sectionHead}>
          <span className="label">What is inside</span>
          <h2 id="concepts-title">Eight ideas, one program</h2>
          <p>
            The board, the solvers and the trace engine are ordinary TypeScript modules with automated tests. The code you read in
            this app is the code that runs.
          </p>
        </div>
        <ul className={styles.concepts}>
          {CONCEPTS.map((k) => (
            <li key={k.id}>
              <button type="button" className={styles.concept} onClick={() => navigate('learn', k.id)}>
                <span className={styles.conceptLabel}>{k.label}</span>
                <span>{k.text}</span>
              </button>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

/** Faint drawing of a search tree with one failed branch, behind the hero text. */
function Schematic() {
  return (
    <svg className={styles.schematic} viewBox="0 0 260 120" aria-hidden="true">
      <g fill="none" stroke="currentColor" strokeWidth="1">
        <path d="M130 12 L70 52 M130 12 L190 52 M70 52 L40 92 M70 52 L100 92 M190 52 L170 92 M190 52 L220 92" />
        <path d="M100 92 L100 112" strokeDasharray="3 3" />
      </g>
      <g fill="#fff" stroke="currentColor" strokeWidth="1">
        <circle cx="130" cy="12" r="5" />
        <circle cx="70" cy="52" r="5" />
        <circle cx="190" cy="52" r="5" />
        <circle cx="40" cy="92" r="5" />
        <circle cx="100" cy="92" r="5" />
        <circle cx="170" cy="92" r="5" />
        <circle cx="220" cy="92" r="5" />
      </g>
      <path d="M36 88l8 8M44 88l-8 8" stroke="#a8433a" strokeWidth="1.2" />
      <circle cx="190" cy="52" r="5" fill="#657451" stroke="none" />
      <text x="138" y="15" fontSize="8" fontFamily="var(--font-mono)" fill="currentColor">solve()</text>
      <text x="198" y="55" fontSize="8" fontFamily="var(--font-mono)" fill="currentColor">depth 1</text>
      <text x="8" y="112" fontSize="8" fontFamily="var(--font-mono)" fill="#a8433a">backtrack</text>
    </svg>
  );
}
