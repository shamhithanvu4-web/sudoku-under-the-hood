/**
 * Recorder — collects trace events and work counters while a solver runs.
 *
 * Solvers call enter()/exit() around each recursive call and emit() at each
 * interesting operation. Counters are updated from the event type, in one
 * place, so the plain and MRV solvers are always counted the same way.
 *
 * With `record: false` the recorder only counts (used for timing runs);
 * the solver code is identical either way.
 */
import type { Coord, Conflict } from '../domain/SudokuBoard';
import {
  emptyStats,
  type BoardOperation,
  type Placement,
  type SolverStats,
  type StepId,
  type TraceEvent,
  type TraceEventType,
} from './types';

export interface Frame {
  readonly id: number;
  readonly parentId: number | null;
  readonly depth: number;
  /** The most recent digit this call placed; it becomes the child's `via`. */
  lastPlacement: Placement | null;
}

export interface EventPayload {
  cell?: Coord;
  digit?: number;
  before?: number;
  after?: number;
  candidates?: readonly number[];
  conflict?: Conflict;
  result?: boolean;
  examined?: number;
  op?: BoardOperation;
}

export interface RecorderOptions {
  /** Store events (true) or only count them (false). */
  record: boolean;
  /** Stop with a SearchLimitError after this many stored events. */
  maxEvents?: number;
  /** Stop with a SearchLimitError after this many recursive calls. */
  maxCalls?: number;
}

export class SearchLimitError extends Error {
  readonly limit: 'events' | 'calls';
  constructor(limit: 'events' | 'calls', amount: number) {
    super(limit === 'events' ? `Trace limit of ${amount.toLocaleString('en-US')} events reached.` : `Search limit of ${amount.toLocaleString('en-US')} calls reached.`);
    this.name = 'SearchLimitError';
    this.limit = limit;
  }
}

const DEFAULT_OP: Record<TraceEventType, BoardOperation | null> = {
  RECURSION_ENTERED: null,
  CELL_SELECTED: 'findEmptyCell',
  CANDIDATES_COMPUTED: 'getCandidates',
  CANDIDATE_TRIED: null,
  VALIDATION_PASSED: 'findConflict',
  VALIDATION_FAILED: 'findConflict',
  VALUE_PLACED: 'placeCandidate',
  RECURSION_RETURNED: null,
  BACKTRACK: 'undoPlacement',
  DEAD_END: null,
  SOLUTION_FOUND: 'isSolved',
  NO_SOLUTION: null,
};

export class Recorder {
  readonly stats: SolverStats = emptyStats();
  readonly events: TraceEvent[] = [];
  readonly record: boolean;
  readonly #maxEvents: number;
  readonly #maxCalls: number;
  #nextCallId = 0;

  constructor(options: RecorderOptions) {
    this.record = options.record;
    this.#maxEvents = options.maxEvents ?? Infinity;
    this.#maxCalls = options.maxCalls ?? Infinity;
  }

  /** Opens a new recursive call one level below `parent` and emits RECURSION_ENTERED. */
  enter(step: StepId, parent: Frame | null): Frame {
    if (this.#nextCallId >= this.#maxCalls) throw new SearchLimitError('calls', this.#maxCalls);
    const frame: Frame = {
      id: this.#nextCallId++,
      parentId: parent === null ? null : parent.id,
      depth: parent === null ? 0 : parent.depth + 1,
      lastPlacement: null,
    };
    const via = parent?.lastPlacement ?? undefined;
    this.emit(step, frame, 'RECURSION_ENTERED', via ? { cell: via.cell, digit: via.digit } : {});
    return frame;
  }

  /** Emits RECURSION_RETURNED for `frame` and passes `result` through, so callers can `return rec.exit(...)`. */
  exit(step: StepId, frame: Frame, result: boolean): boolean {
    this.emit(step, frame, 'RECURSION_RETURNED', { result });
    return result;
  }

  emit(step: StepId, frame: Frame | null, type: TraceEventType, payload: EventPayload = {}): void {
    if (this.record && this.events.length >= this.#maxEvents) {
      throw new SearchLimitError('events', this.#maxEvents);
    }
    countEvent(this.stats, type, frame === null ? 0 : frame.depth, payload.examined);
    if (type === 'VALUE_PLACED' && frame && payload.cell && payload.digit !== undefined) {
      frame.lastPlacement = { cell: payload.cell, digit: payload.digit };
    }
    if (!this.record) return;
    const { op, ...rest } = payload;
    const event: TraceEvent = {
      index: this.events.length,
      type,
      step,
      callId: frame === null ? -1 : frame.id,
      depth: frame === null ? 0 : frame.depth,
      op: op ?? DEFAULT_OP[type],
      ...rest,
      ...(type === 'RECURSION_ENTERED' && payload.cell && payload.digit !== undefined
        ? { via: { cell: payload.cell, digit: payload.digit } }
        : {}),
    };
    this.events.push(event);
  }
}

/**
 * Updates work counters for one event. Shared by the Recorder (while solving)
 * and the Trace (while replaying), so both always agree.
 */
export function countEvent(s: SolverStats, type: TraceEventType, depth: number, examined?: number): void {
  switch (type) {
    case 'RECURSION_ENTERED':
      s.recursiveCalls++;
      if (depth > s.maxDepth) s.maxDepth = depth;
      break;
    case 'CANDIDATES_COMPUTED':
      s.peerScans += examined ?? 1;
      break;
    case 'CANDIDATE_TRIED':
      s.candidateAttempts++;
      break;
    case 'VALIDATION_PASSED':
      s.peerScans++;
      break;
    case 'VALIDATION_FAILED':
      s.peerScans++;
      s.rejected++;
      break;
    case 'VALUE_PLACED':
      s.placements++;
      break;
    case 'BACKTRACK':
      s.backtracks++;
      break;
    case 'DEAD_END':
      s.deadEnds++;
      break;
    default:
      break;
  }
}
