import { useApp } from '../../app/AppState';
import { countClues, DIFFICULTY_LABEL, DIFFICULTY_NOTE, type PuzzleDef } from '../../app/puzzles';
import styles from './PuzzlePicker.module.css';

const GROUPS: { label: string; match: (p: PuzzleDef) => boolean }[] = [
  { label: 'Classroom', match: (p) => p.group === 'demo' },
  { label: 'Easy', match: (p) => p.group === 'puzzle' && p.difficulty === 'easy' },
  { label: 'Medium', match: (p) => p.group === 'puzzle' && p.difficulty === 'medium' },
  { label: 'Hard', match: (p) => p.group === 'puzzle' && p.difficulty === 'hard' },
  { label: 'Expert', match: (p) => p.group === 'puzzle' && p.difficulty === 'expert' },
  { label: 'Error-handling lab', match: (p) => p.group === 'lab' },
  { label: 'Your puzzles', match: (p) => p.group === 'custom' },
];

export function PuzzlePicker({ id = 'puzzle-picker', label = 'Puzzle', exclude }: { id?: string; label?: string; exclude?: (p: PuzzleDef) => boolean }) {
  const { puzzles, puzzle, selectPuzzle } = useApp();
  return (
    <label className={styles.picker} htmlFor={id}>
      <span className="label">{label}</span>
      <select id={id} className={styles.select} value={puzzle.id} onChange={(e) => selectPuzzle(e.target.value)}>
        {GROUPS.map((g) => {
          const items = puzzles.filter((p) => g.match(p) && !exclude?.(p));
          if (!items.length) return null;
          return (
            <optgroup key={g.label} label={g.label}>
              {items.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} · {countClues(p.grid)} clues
                </option>
              ))}
            </optgroup>
          );
        })}
      </select>
    </label>
  );
}

const LEVELS = ['easy', 'medium', 'hard', 'expert'];

export function DifficultyChip({ puzzle }: { puzzle: PuzzleDef }) {
  const level = LEVELS.indexOf(puzzle.difficulty);
  if (puzzle.group === 'lab') return <span className={styles.chip}>Lab</span>;
  if (level < 0) return <span className={styles.chip}>Custom</span>;
  return (
    <span className={styles.chip} data-level={puzzle.difficulty} title={DIFFICULTY_NOTE[puzzle.difficulty]}>
      <span className={styles.pips} aria-hidden="true">
        {LEVELS.map((l, i) => (
          <i key={l} data-on={i <= level} />
        ))}
      </span>
      {DIFFICULTY_LABEL[puzzle.difficulty]}
    </span>
  );
}
