import { useEffect } from 'react';
import { Button } from '../components/Button';
import { AnalyzePage } from '../features/analyze/AnalyzePage';
import { GuidedPage } from '../features/guided/GuidedPage';
import { HomePage } from '../features/home/HomePage';
import { LearnPage } from '../features/learn/LearnPage';
import { PlayPage } from '../features/play/PlayPage';
import { PresentPage } from '../features/present/PresentPage';
import { useApp } from './AppState';
import { Logo } from './Logo';
import type { Route } from './router';
import styles from './App.module.css';

const NAV: { route: Route; label: string }[] = [
  { route: 'play', label: 'Play' },
  { route: 'solve', label: 'Under the Hood' },
  { route: 'learn', label: 'Learn' },
  { route: 'analyze', label: 'Analyze' },
];

const TITLES: Record<Route, string> = {
  home: 'Sudoku: Under the Hood',
  play: 'Play · Sudoku: Under the Hood',
  solve: 'Under the Hood · Sudoku: Under the Hood',
  learn: 'Learn · Sudoku: Under the Hood',
  analyze: 'Analyze · Sudoku: Under the Hood',
  present: 'Present · Sudoku: Under the Hood',
};

export function App() {
  const { route, navigate } = useApp();

  useEffect(() => {
    try {
      document.title = TITLES[route];
    } catch {
      /* ignore */
    }
  }, [route]);

  if (route === 'present') return <PresentPage />;

  return (
    <div className={styles.app}>
      <a className={styles.skip} href="#main" onClick={(e) => { e.preventDefault(); document.getElementById('main')?.focus(); }}>
        Skip to content
      </a>
      <header className={styles.header}>
        <div className={styles.headerInner}>
          <button type="button" className={styles.brand} onClick={() => navigate('home')} aria-label="Sudoku: Under the Hood, home">
            <Logo />
            <span className={styles.wordmark}>
              <strong>Sudoku</strong>
              <span>Under the Hood</span>
            </span>
          </button>
          <nav className={styles.nav} aria-label="Modes">
            {NAV.map((n) => (
              <button
                key={n.route}
                type="button"
                className={styles.navItem}
                aria-current={route === n.route ? 'page' : undefined}
                onClick={() => navigate(n.route)}
              >
                {n.label}
              </button>
            ))}
          </nav>
          <Button className={styles.present} size="sm" icon="expand" onClick={() => navigate('present')}>
            Present
          </Button>
        </div>
      </header>
      <main id="main" className={styles.main} tabIndex={-1}>
        {route === 'home' && <HomePage />}
        {route === 'play' && <PlayPage />}
        {route === 'solve' && <GuidedPage />}
        {route === 'learn' && <LearnPage />}
        {route === 'analyze' && <AnalyzePage />}
      </main>
      <footer className={styles.footer}>
        <div className={styles.footerInner}>
          <span>Sudoku: Under the Hood · an interactive Data Structures and Algorithms project.</span>
          <span>Every solver step shown in this app comes from a real run in your browser.</span>
        </div>
      </footer>
    </div>
  );
}
