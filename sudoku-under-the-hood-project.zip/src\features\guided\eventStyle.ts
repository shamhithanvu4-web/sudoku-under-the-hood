import type { TraceEventType } from '../../solver/types';

export type EventCategory = 'call' | 'decision' | 'success' | 'failure';

export const CATEGORY: Record<TraceEventType, EventCategory> = {
  RECURSION_ENTERED: 'call',
  RECURSION_RETURNED: 'call',
  CELL_SELECTED: 'decision',
  CANDIDATES_COMPUTED: 'decision',
  CANDIDATE_TRIED: 'decision',
  VALIDATION_PASSED: 'success',
  VALUE_PLACED: 'success',
  SOLUTION_FOUND: 'success',
  VALIDATION_FAILED: 'failure',
  BACKTRACK: 'failure',
  DEAD_END: 'failure',
  NO_SOLUTION: 'failure',
};

export const JUMP_TARGETS: { type: TraceEventType; label: string }[] = [
  { type: 'BACKTRACK', label: 'backtrack' },
  { type: 'VALIDATION_FAILED', label: 'rejected digit' },
  { type: 'VALIDATION_PASSED', label: 'accepted digit' },
  { type: 'VALUE_PLACED', label: 'placement' },
  { type: 'DEAD_END', label: 'dead end' },
  { type: 'RECURSION_ENTERED', label: 'new recursive call' },
  { type: 'CANDIDATES_COMPUTED', label: 'candidate list (MRV)' },
];
